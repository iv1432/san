= 2.4.0 =
    * RESTful API. Read document below for more details:
      http://www.iredmail.org/docs/iredadmin-pro.restful.api.html

    * Improvements:
        + Able to set limits of mail user/alias accounts while creating new
          domain.
        + Able to search user alias address (name and email address).
        + Able to manage per-domain and per-user sender dependent relayhost.
        + Able to enable/disable SOGo service for a single user in user
          profile page.
        + Bring back option 'Relay without verifying local recipients' for
          per-domain relay setting.
        + Show progress bar in domain list page to indicate percentage of used
          quota (and allocated quota).
        + Show a small icon as indicator:
            - on domain list page: indicate certain domain has alias domain(s).
            - on user list page: indicate current account has alias and
              forwarding addresses.
          Moving cursor on the icon will show more details like
          alias/forwarding addresses.

    * Fixed issues:
        - Not remove email address which contains invalid character while
          updating alias members/moderators.
        - Cannot convert invalid date/time to local time.
        - Not add required header (Content-Type: text/html) for web pages.
        - Not correctly handle submitted alias moderators.
        - tools/cleanup_amavisd_db.py: Not correctly delete unreferred sql
          records in Amavisd database, this bug may incorrectly delete some
          whitelists/blacklists.
        - Cannot correctly sort mail users by used quota of mailbox with
          PostgreSQL backend.
          Thanks Andris Vasers <andris.vasers _at_ rigasvilni.lv> for the report.
        - Updating per-domain and per-user greylisting setting will delete
          greylisting whitelisted domains.

    * Updated translations:
        + Spain (es_ES).
          Thanks Juan Bou Riquer <jbou@cancun.com.mx>.

= 2.3.1 =
    * Fixed issues:
        + Not correctly strip email addresses which contains delimiter.

= 2.3.0 =
    * Completely remove support for Policyd and Cluebringer.
      iRedMail shipped Policyd in very early releases, THANK YOU. GOODBYE.
    * tools/wblist_admin.py has been removed, it's available in iRedAPD-1.8.0.

    * Improvements:
        + Able to manage greylisting whitelist domains.
        + New option of 'Disabled self-service preferences' in domain profile
          page, under tab 'Advanced': View basic info of received mails.
        + Better spam policy control: able to control bypassing or
          quarantining detected spam/virus/banned/bad-header email.

    * Fixed issues:
        - Cannot release quarantined email on some Linux distributions.
        - Cannot add email address like 'user+ext@domain.com' as alias member.
        - Improper maildir path if username contains more than 3 characters.
          Thanks bardzotrudny <bardzotrudnymail _at_ gmail> for the report in
          forum.
        - Cannot update throttle settings.
          Thanks ketan.aagja <ketan.aagja _at_ gmail> for the report in forum.
        - Self-service is not working.
        - Not correctly set greylisting priorities.
          Thanks Animatrix <kurt6459 _at_ gmail> for the report in forum.
        - Incorrect regular expressions of email address and domain name, cause
          several '404 page not found' errors, and cannot access user profile
          page whose email address contains a dot like 'abc.def@domain.com'.

    * Updated translations:
        + Spain (es_ES).
          Thanks Juan Bou Riquer <jbou@cancun.com.mx>.
        + Bulgarian (bg_BG).
          Thanks Пламен Василев <p.vasileff _at_ gmail.com>.

= 2.2.0 =
    NOTE: Greylisting and throttling offered by iRedAPD conflict with
          Policyd/Cluebringer, so if you want to use Policyd/Cluebringer,
          please disable iRedAPD integration in config file `settings.py` with
          setting `iredapd_enabled = False`.

          We have greylisting and throttling support in iRedAPD as replacement,
          and here's tutorial to help you migrate from Cluebringer to iRedAPD:
          http://www.iredmail.org/docs/cluebringer.to.iredapd.html

    * Improvements:
        - Able to restrict user to login from specified IP addresses or network.
          (under user profile page, tab "Advanced".)
        - Able to manage global, per-domain and per-user greylisting and
          throttle settings implemented with iRedAPD.
        - Able to list disabled domain/user/mailing list/alias accounts.
        - Allow to store mail user's plain password in additional column in
          `vmail.mailbox` table.
        - Able to bypass bad-header checking in spam policy setting page.
        - Able to manage per-user alias addresses.
        - Show iRedMail version number stored in /etc/iredmail-release.
        - Able to manage white/blacklists for outbound message.
        - tools/cleanup_amavisd_db.py won't cause lock issue or performance
          issue anymore.
        - New scripts:
            + tools/update_mailbox_quota.py: update mailbox quota for one user
              (specified on command line) or bulk users (read from a plain text
              file).

    * Fixed issues:
        + Not correctly update spam subject text (spam_subject_tag3).
          Thanks rafaelr <rafaelr _at_ icctek.com> for the report in forum.
        + Cannot correctly handle improper unicode string in mail headers
          while viewing quarantined mail.
        + Not correctly submit per-domain white/blacklists while submitting
          from 'Quarantined Mails' page as normal domain admin.
        + Cannot set empty time zone and preferred language.
        + Not generate proper maildir path when first 3 characters in
          username part of email address contains dot.
        - Cannot verify BCRYPT password hash with '{BLF-CRYPT}' prefix.
        - Not correctly set access restriction to account profile page.
        - Not correctly set domain as backup mx.

    * Updated translations:
        + Germany (de_DE).
          Thanks Joachim Buthe <buthe _at_ gugw.tu-darmstadt.de> and
          Martin Hofheiz <m.hofheinz _at_ netzwerk-design.net>.
        + Spain (es_ES).
          Thanks informatica _at_ ttu.es.
        + Simplified Chinese (zh_CN).

= 2.1.3 =
    * Improvements:
        - Command line tool to manage white/blacklists: tools/wblist_admin.py.
          Supported operations: add/delete/list whitelists or blacklists for
          server-wide, per-domain, per-user. Run the script without any
          arguments to get a help message.
          Note: tools/submit_wblist.py was removed.

    * Fixed issues:
        - Not correctly assign default mail group(s) to newly created mail user.
          Thanks <alex.ab.travel _at_ gmail.com> for the report.

= 2.1.2 =
    * Fixed issues:
        - Not correctly update `alias` table while changing user's mail address.
        - Cannot delete user in search page.
          Thanks Grzegorz Leśkiewicz <mstgeo _at_ yes.pl> for the report.

    * Updated translations:
        + Germany (de_DE).
          Thanks Joachim Buthe <buthe _at_ gugw.tu-darmstadt.de>.
        + Spain (es_ES).
          Thanks informatica _at_ ttu.es.

= 2.1.1 =
    * Fixed issues:
        - Normal admin cannot update alias profile.
          Thanks Hilario Ortigosa Monteoliva <hortigosa _at_ octanio.es> for
          the feedback.

= 2.1 =
    * Improvements:
        - Able to white/blacklist senders or recipients in System -> Mail Logs
          -> Sent Mails (or Received Mails).

    * Fixed issues:
        - Improperly checking per-admin time zone for separate admin account.
        - Cannot set mail forwarding in self-service page.
        - Incorrect function arguments when calling simple_profile() defined
          in libs/sqllib/user.py.
        - Always set per-user preferred language to system default value.
        - Cannot delete/enable/disable mail alias account.
        - Incorrect variable name in controllers/panel/log.py causes
          'internal server error' while accessing Admin Log page.

= 2.0 =
    Note: iRedAdmin-Pro-MySQL is now merged into iRedAdmin-Pro-SQL.

    * Improvements:
        - Able to set per-domain and per-user time zone.
        - Allow to specify amavisd server address if amavisd and sql database
          are not running on the same host.
        - Able to filter out accounts by first character in email address or
          domain name.
        - Self-service is now a per-domain setting, not more global setting.
          Global admin can enable/disable self-service in domain profile page,
          under tab 'Advanced'.
        - New script: tools/notify_quarantined_recipients.py. Used to query
          quarantined mails and notify local recipients (via email) they
          have emails quarantined on server and not delivered to their
          mailbox.
          It's ok to setup a cron job to run this script every, for example,
          6 or 12 hours, it's up to you.
        - Able to white/blacklist senders on Quarantined Mails page.
        - Able to change email address of mail user/alias account in place.
        - Log profile update operations.
        - Show per-user mailbox quota in self-service preference page.
        - Pulling out plain text of HTML email while displaying quarantined
          email. NOTE: this feature requies Python module BeautifulSoup.
        - New script: tools/submit_wblist.py, used to submit white/blacklist
          from command line. Sample usage:
          python tools/submit_wblist.py --blacklist 192.168.1.10 user@test.com
        - Able to use 'user@*' as white/blacklist sender.

    * Fixed issues:
        - Cannot disable global throttling.
        - Cannot correctly redirect to page of certain type of quarantined
          mails after release/delete emails.
        - Not verify members in same domain while updating user forwarding.
        - Cannot list IPv6 address(es) assigned on network interface(s) on
          Dashboard page.
        - Cannot blacklist top-level domain name (e.g. @.com).
        - Cannot delete alias account.


= 1.9.2 =
    * Improvements:
        - Log message after updated mail list members/moderators.
        - Able to use '*@domain.com' as moderator of mail alias account.
          Note: this requires iRedAPD-1.4.5.
        - New script tool: migrate_cluebringer_wblist_to_amavisd.py.
          Used to migrate Cluebringer white/blacklists to Amavisd database.

          Note: Don't forget to enable iRedAPD plugin `amavisd_wblist` in
          /opt/iredapd/settings.py.

    * Fixed issues:
        - Cannot delete mail alias account.
        - Cannot display all domains in user profile page.
        - Not wrap subject/sender/recipient in Sent/Received Mails page.
        - Cannot correctly delete all Sent/Received mails in SQL database.
        - Not correctly handle SQL column `policy.spam_subject_tag3` while
          updating spam policy. This column doesn't exist in Amavisd-new-2.6.x.
        - Cannot remove existing white/blacklists.
        - Upgrading script (tools/upgrade_iredadmin.sh) should restart uwsgi
          sesrvice instead of nginx if Nginx is running as web server.
        - Not save 'Always insert X-Spam-* headers' setting in 'Global Spam
          Policy' page.
        - Show improper links in self-service spam policy page.
        - 'INNER JOIN' in tools/cleanup_amavisd_db.py causes performance
          issue while removing old records in amavisd database.

    * Updated translations:
        + Spain (es_ES).
          Thanks informatica _at_ ttu.es.

= 1.9.1 =
    * Fixed issues:
        - Not handle msg 'WBLIST_UPDATED' in self-service page.
        - Not correctly save per-user wblist in self-service page.
        - Remove existing wblist after adding new ones.
        - Raise 'internal server error' if login username/password is wrong.
        - Cannot delete all quarantined mails.

= 1.9.0 =
    * New features:
        - Better Amavisd integration:

          o Able to set max size of single incoming email.
            Note: it requires iRedAPD plugin `amavisd_message_size_limit`.

          o Able to manage per-domain, per-user white/blacklists, and it's
            integrated with Amavisd.

              + Although this white/blacklists works with Amavisd after-queue,
                but you'd better enable iRedAPD plugin `amavisd_wblist` to
                reject blacklisted senders during smtp session to save system
                resource.

              + It replaces white/blacklists provided by Cluebringer, but
                Cluebringer wblist also works.

            o Able to set global, per-domain and per-user (basic) spam policy.

        - self-service. Normal user can login to manage their own profile
          (name, password), forwarding, per-user white/blacklist, quarantined
          mails, and check received mails.

          o Self-service is disabled by default. Please set below parameter
            in iRedAdmin config file 'settings.py' then reload/restart Apache
            web service or uwsgi service if you're running Nginx.

            ENABLE_SELF_SERVICE = True

          o Domain admin can restrict allowed self-service preferences in
            domain profile page, under tab 'Advanced'.

          o Server admin is able to set which self-service page should be
            displayed after user login. Sample setting in iRedAdmin config
            file:

              SELF_SERVICE_DEFAULT_PAGE = 'preferences'  # Default setting
              SELF_SERVICE_DEFAULT_PAGE = 'quarantined'  # Quarantined Mails
              SELF_SERVICE_DEFAULT_PAGE = 'received'     # Received Mails

          o User is able to white/blacklist sender or sender domain in
            'Quarantined Mails' page.

          o User is able to blacklist sender or sender domain in
            'Received Mails' page.

    * Improvements:
        + Able to sort quarantined mails by spam score.
        + Able to generate 'CRAM-MD5' password hash with command `doveadm pw`.
        + Able to generate bcrypt password hash with Python module 'bcrypt' or
          'py-bcrypt'.

          It works on BSD systems, but not Linux. Since libc shpped in most
          Linux distributions doesn't support bcrypt, Dovecot cannot verify
          bcrypt hash on Linux.

        + Able to sort mail users by mailbox quota usage percentage.
        + Able to restrict IP addresses where global admin are allowed to login
          from (new setting parameter: GLOBAL_ADMIN_IP_LIST).
        + Show spam score in quarantined page and received mail log page.
        + Able to filter quarantined emails by quarantined type: bad header.
        + Able to set default per-user sender/recipient bcc address for newly
          created mail user.

    * Fixed issues:
        - Not escape random password in account creation page. this bug causes
          iRedAdmin displays an incomplete password.
        - Cannot set domain quota to unlimited with radio checkbox.
          Thanks Dinis D <dueldanov _at_ gmail> for the report.
        - Incorrect regular expression which not support IDN domain name.
        - Cannot white/blacklist some IP addresses due to incorrect regular
          expression.
        - Not correctly show domain status (active/inactive) in domain list
          page when domain is inactive but has custom relay.
        - Not sync 'mailbox.enablelda' and 'mailbox.enablelmtp' while updating
          'mailbox.enabledeliver'.
        - Not show `mailbox.employeeid` in search result.
        - Not correctly mark user as normal admin or global admin.
        - Use removed SQL columns while searching accounts.
        - Cannot set per-user mailbox quota.
          Thanks Kim Gardner <ferrisxb9r _at_ gmail.com> for the report.
        - Generated random password is longer than max password length.
          Thanks labasus <labas _at_ gmx dot co.uk> for the report.
        - Not detect openSUSE in script tools/upgrade_iredadmin.sh.
        - Duplicate value of 'Received' header while rendering quarantined mail
          headers.

    * Updated translations:
        + Spain (es_ES).
          Thanks informatica _at_ ttu.es.
        + Portuguese (Brazil), (pt_BR).
          Thanks Douglas Medeiros <douglasmedeiros@tic.ufrj.br>.

= 1.8.2 =
    * Improvements:
        + New script used to help upgrade iRedAdmin open source edition or
          old version of iRedAdmin-Pro.
        + Able to filter quarantined emails by quarantined type: clean.
        + Enhanced password restrictions. New password must has at least
            - one letter
            - one uppercase letter
            - one digit number
            - one special characters
        + Set default time (15 mintues) of inactivity before session expires.
        + Normal admin is now able to manage multiple domains, and mark other
          mail user as domain admin.
        + Able to add record of sub-domain for Cluebringer whitelist/blacklist.

    * Fixed issues:
        + Not render pages in selected language in drop-down list in Login page
          after logged in.
        + Not delete global admin record in `vmail.domain_admins` while
          deleting mail domain.
          Thanks sergiocesar <sergio _at_ winc dot net> for the report.
        + Not allow to use longer top domain name in regular expression used to
          verify domain name and email address.
        + Incorrect URL handle in Amavisd quarantined mail list.
          Thanks Adrian Schurr <Adrian.Schurr _at_ siag.ch> for the report.
        + Incorrectly paged list of quarantined mails.
          Thanks Michael <michaelchong2005 _at_ gmail> and Kyle Harris
          <kyle _at_ theharrishome.com> for the report.
        + Not verify permission while searching mail log.
          Thanks Khanb <balajikhan13 _at_ gmail> for the report.
        + Incorrect function name in libs/policyd/greylist.py.
          Thanks <mail _at_ mensmaximus.de> for the report.

= 1.8.1 =
    * Fixed issues:
        + Cannot detect or switch to language on login page.
          Thanks Robert <robert-kuehn _at_ gmx.de> for the report.
        + Not correctly count number of in/out mails.
          Thanks Robert <robert-kuehn _at_ gmx.de> for the report.
        + Not correctly disable Policyd/Cluebringer status.
          Thanks spango <spango _at_ ecentral.com> for the report.

= 1.8.0 =
    * Cluebringer support:
        + Server-wide, per-domain and per-user inbound/outbound throttling.
          NOTE: Throttling does NOT apply to emails sent from internal
          domains to internal domains.
        + Add domain as internal domains while creating new mail domain.
        + Remove domain from internal domains while removing mail domain.
        + Greylisting:
            o Able to enable/disable per-domain and per-user greylisting.
            o Able to list/remove accounts which has greylisting disabled.
            o Able to update basic greylisting settings for 'Default Inbound'.
        + White/Blacklist:
            o View, add, delete white/blacklist records.

    * Improvements:
        + Detect non-ascii character in password and raise error message.
          Thanks Chris <chris _at_ chrispyfur.net> for the feedback in forum.
        + Able to filter quarantined emails by quarantined type: spam, virus,
          banned.
        + Switch config file from ini format to Python source file, this makes
          programming and upgrading easier.

    * Fixed:
        + Mail user which marked as global admin but not domain admin cannot
          create new mail user/alias account.
          Thanks Hugo Ferreira <hferreira _at_ pontoc.pt> for the report.
        + Mail user which marked as global admin but not domain admin cannot
          view Sent/Received mail log.
          Thanks Hugo Ferreira <hferreira _at_ pontoc.pt> for the report.
        + Normal admin cannot search quarantined mail log.
          Thanks Hugo Ferreira <hferreira _at_ pontoc.pt> for the report.
        + Explicitly tell Amavisd to release quarantined mail stored in SQL
          database with addition release command 'quar_type=Q'.
          Thanks cts.cobra _at_ gmail for the report and help in our forum.
        + Not delete SQL record in 'vmail.domain_admins' while removing
          mail user which is domain admin.
          Thanks Atendimento GrupoW <atendimento _at_ grupow.com.br> for the
          report.
        + Not return correct allocated quota size while creating new user
          for newly created domain.
          Thanks Simon Kulessa <kulessa _at_ mediaproject.de> for the report.
        + Use HTTP_PROXY defined in settings.py first, if empty try proxy
          server defined in environment variable 'http_proxy'.
          Thanks Bernhard Roth <broth _at_ roth-itk.de> for the report and
          propose.
        + Not correctly get number of per-admin managed alias accounts while
          logging in as normal admin.
          Thanks Bryan and Neil in NetEasy Inc. for the report.

    * New or updated translations:
        + Russia (ru_RU). Thanks Андрей Бережков <kidhtc _at_ gmail>.

= 1.7.0 =
    * New features:
        + Log maildir path of deleted mail domain or user in table
          'vmail.deleted_mailboxes'. Maildir path is concatenate with 3 columns:
          CONCAT(storagebasedirectory, '/', storagenode, '/', maildir).
        + Global admin can set per-domain disabled domain/user profiles in
          domain profile page. Normal admin cannot view and update disabled
          profiles.

    * Improvements:
        + Mark/Unmark users as domain admin or global admin in user list page.
        + List internal domain admins in separate page: /admins/[domain].
        + Redirect from admin profile page (/profile/admin/general/xx) to user
          profile page (/profile/user/general/xxx) if admin is a mail user.
        + Able to delete admin accounts from Admins page (/admins) if admin
          is a mail user.
        + Link to account profile page for account name in search page.
        + Able to set addition settings in domain creation page:
          domain quota, default quota/language for new user.
        + Set per-domain default language for newly created mail users.

    * Fixed:
        + Not list mail admin which are mail user in "System -> Admin Log".
        + Not show correct used mailbox quota in domain list page.
          Thanks Ivo Schindler <ivo.schindler _at_ i-web.ch> for the report.
        + Cannot limit user mailbox quota in user profile page.
        + Searching full email address returns empty result.
          Thanks our forum user "tonyd" <tonydema _at_ gmail> for the report.
        + Not check new version of iRedAdmin-Pro.
        + Cannot show top 10 recipients in Dashboard page.
          Thanks melaleuca5 <info _at_ divertido.ca> for the report in forum.

    * New or updated translations:
        + Korean (ko_KR). Thanks Bosung Lee <gotocloud _at_ gotocloud.co.kr>

= 1.6.0 =
    * Improvements:
        + Show content type (spam/virus/banned) of quarantined mails.
        + Able to set relay without verifying local recipients.
        + New password schemes: SSHA, SSHA512.
          Note: SSHA512 requires Dovecot-2.0 (and later), Python-2.5 (or
          later).
        + Show breadcrumb links in account creation pages.
        + Don't show duplicate tabs in Users/Lists/Aliases list pages.

    * Fixed:
        - Can use primary domain as alias domain.
        - Script tools/cleanup_amavisd_db.py cannot read local settings in
          libs/settings_local.py.
          Thanks Bruce MacKay <bmackay _at_ razyr.net> for the report.
        - Not update greylisting opt-in/out for alias domains.
          Thanks gleenj <glenn _at_ neondigital.com> for the report.
        - Not update account status in `alias` table while updating account
          status of mail user.
          Thanks Mickey Everts <mickey.everts _at_ otcorp.com> for the report.
        - Script tools/cleanup_amavisd_db.py cannot delete older SQL records
          in Amavisd database.
          Thanks broth <broth _at_ roth-itk.de> for the report in forum.
        - Cannot store default domain transport setting if user submits empty
          value in domain profile (relay) page.
        - Not assign new user to default mail groups.
          Thanks Matteo Fracassetti <info _at_ drgiorgini.it> for the report.
        - Not show number of existing alias accounts in domain profile.
          Thanks thatday <win3c _at_ 126.com> for the report.
        - Not update domain/user bcc records while adding/removing alias domains.
        - Not update mailbox.enablesieve, mailbox.enablesievesecured correctly.
          Thanks thatday <win3c _at_ 126.com> for the report.
        - Incorrectly unset domainGlobalAdmin status in session after updating
          admin profile.
          Thanks Tue <tt _at_ atorbital.com> and escu <cosmin.necula@gmail> for
          the report.

    * New or updated translations:
        + Traditional Chinese (zh_TW). Thanks Ho ho <ho.iredmail _at_ gmail.com>.
        + Polish (pl_PL). Thanks Adrian Grygier <adi _at_ zwami.pl>.
        + Spain (es_ES). Thanks Luis Armando Perez Marin.
        + Russian (ru_RU). Thanks Taylor D <hoper.me _at_ gmail.com>.
        + Serbian (Cyrillic, sr_CS). Thanks Robert Bogdan <rbogdan _at_ color.rs>.
        + Slovenian (sl_SI). Thanks Marko Kobal <marko.kobal _at_ arctur.si>.
        + French (fr_FR). Thanks Shafeek Sumser <shafeeks _at_ gmail.com>.
        + Portuguese (Brazilian, pt_BR). Thanks Wendell Martins Borges <perlporter
          _at_ gmail.com>.
        + Finnish (fi_FI). Thanks Teemu Harjula <teemu.harjula _at_ tietovirta.fi>.
        + Itilian (it_IT). Thanks Nicolas Cauchie <nicolas _at_
          franceoxygene.fr>, Riccardo Raggi <riccardo _at_ raggi.eu>, and Alberto
          Baudacci <a.baudacci _at_ me.com>.
        + Netherlands (nl_NL). Thanks Luc Verhoeven <lverhoeven _at_ vcn.nl>
        + German (de_DE). Thanks Ivo Schindler <ivo.schindler _at_ i-web.ch>,
          and Martin <info _at_ netzwerk-design.net>.
        + Czech (cs_CZ). Thanks Roman Pudil <roman _at_ webhosting.fm>.

= 1.5.1 =
    * Fixed:
        + List normal users in Admins page.

    * New and updated translations:
        + Update German translation (de_DE). Thanks "Sascha Wolski | cognitics
          GmbH" <wolski _at_ cognitics.de>.
        + Update Brazilian (pt_BR).
          Thanks "Julio C. Oliveira" <julioc _at_ paranet.com.br>.

= 1.5.0 =
    * New features:
        + Mark domain as backup MX.
        + New cron script: tools/cleanup_amavisd_db.py.
          Used to remove old records of incoming/outgoing/quarantined mails.
        + Mark mail user as admin of its domain and/or global admin.

    * Improvements:
        + Cron script tools/dump_disclaimer.py was rewritten, no need to
          edit it anymore, just specify the directory used to store disclaimer
          file. e.g. python tools/dump_disclaimer.py /etc/postfix/disclaimer/.
        + Allow to redirect to domain list page instead of Dashboard page
          after login: REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN (libs/settings.py).
        + Show search box on top-right corner.
        + Show more domain status in domain list page: relay, backupmx.
        + Add some sample relay settings as reference.
        + Set http proxy server address in libs/settings.py (HTTP_PROXY)
          if iRedAdmin cannot access internet (iredmail.org) directly.
          Thanks Bernhard Roth <broth _at_ roth-itk.de> for helping test.
        + Oops, don't allow normal domain admin to manage both per-domain and
          per-user throttling.

    * Fixed:
        + Cannot delete all per-user activities with one-click.
          Thanks melaleuca5 <info _at_ divertido.ca> for the report.
        + Incorrect real-time quota in user list page with unlimited quota.
          Thanks HV <jan _at_ volesak.com> for the report.
        + Didn't remove SQL records of real-time mailbox quota while deleting 
          mail domain or user.
        + Cannot delete all records of received mails with one-click.
        + Not convert timestamp of admin logs to LOCAL_TIMEZONE.

    * New and updated translations:
        + Update Brazilian (pt_BR). Thanks "Julio C. Oliveira"
          <julioc _at_ paranet.com.br>.
        + Czech (cs_CZ). Thanks Roman Pudil <roman _at_ webhosting.fm>.

= 1.4.0 =
    * Improvements:
        + Show basic license info.
        + Allow to use plain MD5 password.
        + Manage quarantined banned emails.
        + Per-domain and per-user greylisting control in account profile
          page, under tab Advanced.
        + Show search string in search result page.
        + Verify email address for per-domain bcc settings if mail domain is
          a local domain.
        + Allow normal domain admin to manage both per-domain and per-user
          throttling.

    * Fixed:
        + Add missed msg handlers in account list pages.
          Thanks Jure Pečar <jure.pecar _at_ arctur.si> for the report.
        + Cannot delete all quarantined mails with one click.
        + Cannot perform search.
        + Get realtime mailbox quota from incorrect SQL table.
          Thanks Edgaras Dagilis <e.dagilis@lku> for the report and fix.
        + Cannot handle timezones with minutes. e.g. GMT+5:45.

    * New and updated translations:
        + Slovenian (sl_SI). Thanks Marko Kobal <marko.kobal _at_ arctur.si>.
        + Polish (pl_PL). Thanks Adrian (adi _at_ zwami.pl)

= 1.3.1 =
    * Improvements:
        + Able to search mail domains.
        + Read used mailbox quota from separate table 'used_quota'.
        + Save password last change date in column: mailbox.passwordlastchange.
        + Able to set global timezone in libs/settings.py: LOCAL_TIMEZONE.
        + Allow to store user password in plain text in libs/settings.py:
          STORE_PASSWORD_IN_PLAIN.
          Thanks brothner <bryan.orthner@kcdc.ca>.

    * Fixed:
        + Show quarantined emails of all domains instead of specified domain.
          Thanks mmh@forum for the report.
        + Not completely delete user related records while removing user from
          search result page.
          Thanks wangning_wang@staff.easou.com for the report.
        + Cannot assign alias as member of another alias account.

    * New and updated translations:
        + Polish (pl_PL). Thanks Krzysztof Skurzyński <k.skurzynski@kospel.pl>.
        + Finnish (fi_FI). Thanks Teemu Harjula <teemu.harjula@tietovirta.fi>.

= 1.3.0 =
    * New features:
        + Sender and recipient throttling, available as per-user and per-domain
          settings.

    * Improvements:
        + Show used quota percentage in user profile page. Thanks atros <christian@eol.co.nz>.
        + Assign user to aliases in user profile page.
        + Remove deleted user from mail aliases (member).
        + Delete all sent/received logs with one-click.
        + Better SQL performance while listing all domains.
          Thanks atros <christian@eol.co.nz>.

    * Fixed:
        + Cannot delete some records of sent/received mail log. Caused by
          incorrect mail_id, secret_id character set.
          Thanks Michael <zhongjh@jamestextile.com>.
        + Typo error in alias member list. Thanks John Hannawin <john@i-next.co.uk>.
        + Not allow '+' in email address. Thanks <wayneliao38@gmail>.

    * New and updated translations:
        + Brazilian Portuguese (pt_BR). Thanks Fabricio Caseiro <fcaseiro@tic.ufrj.br>.
        + Itilian (it_IT). Thanks Alberto <alberto@graphite.eu>.
        + Russian (ru_RU). Thanks Dmitry Sukharev <suds77@gmail.com>.
        + German (de_DE). Thanks info@netzwerk-design.net <info@netzwerk-design.net>.
        + Traditional Chinese (zh_TW). Thanks Wayne <wayneliao38@gmail.com>.
        + Spanish (es_ES). Thanks Lucas <lucas@landm.net>.

= 1.2.1 =
    * Fixed:
        + Cannot delete quarantined VIRUS mails when try to delte all
          quarantined mails with one click. Thanks beez <jason@indo.net.id>.
        + Cannot list per-domain and per-user activities.
          Thanks Chris Ip <chris.ip@efaith.com.hk>.
        + Incorrect count of Sent, Received mails with normal admin.
          Thanks Chris Ip <chris.ip@efaith.com.hk>.

= 1.2.0 =
    * Improvements:
        + CSRF protect.
        + Able to delete all admin logs with one click.

    * Fixed:
        + Cannot view quarantined VIRUS mails. Thanks beez@forum
          <jason@indo.net.id>.
        + Incorrect links of pages in per-user and per-domain activity list.
        + Allow to use domain names which end with 2-6 chars.
          Thanks Julian P. <@consistency.at>.
        + Fix EXCEEDED_DOMAIN_ACCOUNT_LIMIT issue while creating new user.
          Thanks Emidio Reggiani <emidio.reggiani@...it>, Tecnologia - PLUGNET
          <tecno@plugnet.com.br>
        + Allow normal admin to update catch-all address of domain.
          Thanks Chris Ip (chris.ip@...hk).
        + Some possible XSS, XSRF vulnerabilities.

= 1.1.0 =
    * New features:
        - Search log of sent/received/quarantined mails based on domain name
          or email address.
        - Able to view per-user and per-domain sent/received/quarantined mail
          logs.
        - Able to set mail deliver restriction for mail alias, add moderators.
          Note: This feature requires iRedAPD-1.3.4 or later.
        - Able to disable for creating mail user/list/alias.
        - Store passwords in plain text.

    * Improvements:
        - Seperate bcc/relay tab in user profile page.
        - Generate a random password while setting/resetting password.
        - Show spam level (score) in quarantined page.
        - Able to delete all quarantined mails with one click.
        - Show mail size in received/sent mail logs.
        - Sortable sent/received/quarantined mail log pages.
        - Delete old amavisd records only once in each login session.
        - Better unicode handle in quarantined/sent/received mail logs.
        - Show admin type (global/normal) in admin list page.
        - Delete alias from 'domain.defaultuseraliases' while deleting alias
          account.
        - List user email in 'domain.defaultuseraliases' which is not exist.

    * Fixed:
        - Permission denied if normal admin create user/alias from main
          navigation bar: Add account -> User/Alias.
          Thanks Chris Ip <chris.ip@>.
        - Incorrect SQL queries which use unindexed content (column 'time_num'
          in table 'amavisd.msgs'.
        - Incorrect mail forwarding address list in user profile page.
          Thanks Alexandre Silva <asilva@> for bug report and testing.
        - Do not add exist domain name as alias domain.
        - Use specified MySQL host instead of 'localhost'.
          Thanks atros@forum <christian@>.
        - Add alias account for new users: address=goto. So that catch-all
          account will work as expected.
        - Incorrect SQL command used to query catch-all address in domain
          profile.
        - Allow normal admin to release/delete their quarantined mails.
        - Incorrect count of quarantined mails.
        - Unable to expand quarantined mails which has '+' in mail_id.


    * Translations:
        - Update French (fr_FR). Thanks Olivier PLOIX <olivier.ploix _at_
          isma-fr.com>

= 1.0.0 =
    * Initial release.
        - List all accounts (domains/admins/users/aliases).
        - Add/delete/enable/disable account (domain/admin/user/alias).
        - View/update account profile (domain/admin/user/alias).
        - Show number of total domains, users, alias in dashboard.
        - User authentication against MySQL (MD5).
        - Log major operations in database.
        - Amavisd integration.
        - Policyd integration.
