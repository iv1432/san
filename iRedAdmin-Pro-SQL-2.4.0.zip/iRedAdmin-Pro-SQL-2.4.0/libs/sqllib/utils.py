# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from libs import iredutils

from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import user as sql_lib_user
from libs.sqllib import alias as sql_lib_alias

session = web.config.get('_session', {})


def set_account_status(conn,
                       accounts,
                       account_type,
                       enable_account=False):
    '''Set account status.

    accounts -- an iterable object (list/tuple) filled with accounts.
    account_type -- possible value: domain, admin, user, alias
    enable_account -- possible value: True, False
    '''
    if account_type in ['admin', 'user', 'alias']:
        # email
        accounts = [str(v).lower() for v in accounts if iredutils.is_email(v)]
    else:
        # domain name
        accounts = [str(v).lower() for v in accounts if iredutils.is_domain(v)]

    if not accounts:
        return (True, )

    # 0: disable, 1: enable
    account_status = 0
    action = 'Disable'
    if enable_account:
        account_status = 1
        action = 'Active'

    if account_type == 'domain':
        sql_table = 'domain'
        sql_where_column = 'domain'
    elif account_type == 'admin':
        sql_table = 'admin'
        sql_where_column = 'username'
    elif account_type == 'user':
        sql_table = 'mailbox'
        sql_where_column = 'username'
    else:
        # account_type == 'alias'
        sql_table = 'alias'
        sql_where_column = 'address'

    sql_where = '%s IN %s' % (sql_where_column, web.sqlquote(accounts))
    try:
        conn.update(sql_table,
                    where=sql_where,
                    active=account_status)

        web.logger(event=action.lower(),
                   msg="%s %s: %s." % (action, account_type, ', '.join(accounts)))

        return (True, )
    except Exception, e:
        return (False, str(e))


def delete_accounts(conn, accounts, account_type):
    # accounts must be a list/tuple.
    # account_type in ['domain', 'user', 'admin', 'alias']
    if not accounts:
        return (True, )

    if account_type == 'domain':
        sql_lib_domain.delete_domains(conn=conn, domains=accounts)
    elif account_type == 'user':
        sql_lib_user.delete_users(conn=conn, accounts=accounts)
    elif account_type == 'admin':
        sql_lib_admin.delete_admins(conn=conn, accounts=accounts)
    elif account_type == 'alias':
        sql_lib_alias.delete_aliases(conn=conn, accounts=accounts)

    return (True, )


# Search accounts with display name, email.
def search(conn, search_string, account_type=[], account_status=[]):
    """Return search result in dict.

    (True, {
            'domain': sql_query_result,
            'user': sql_query_result,
            ...
            }
    )
    """

    sql_vars = {
        'search_str': '%%' + search_string + '%%',
        'search_str_exclude_domain': '%%' + search_string + '%%@%%',
    }

    if not account_type:
        account_type = ['domain', 'user', 'alias']

    sql_append_status = ''
    sql_append_domains = ''
    if len(account_status) == 1:
        if 'active' in account_status:
            sql_append_status = ' AND active=1'
        elif 'disabled' in account_status:
            sql_append_status = ' AND active=0'

    # Get managed domains.
    if not session.get('is_global_admin'):
        managed_domains = []
        qr = sql_lib_admin.get_managed_domains(
            conn=conn,
            admin=session.get('username'),
            domain_name_only=True,
            listed_only=True)

        if qr[0] is True:
            managed_domains = qr[1]
            sql_append_domains = ' AND domain IN %s' % web.sqlquote(managed_domains)
        else:
            raise web.seeother('/search?msg=%s' % web.urlquote(qr[1]))

    result = {'domain': [],
              'admin': [],
              'user': [],
              'alias': [],
              # List of email addresses of global admins.
              'allGlobalAdmins': []}

    if session.get('is_global_admin'):
        if 'domain' in account_type:
            qr_domain = conn.select(
                'domain',
                vars=sql_vars,
                what='domain,description,aliases,mailboxes,maxquota,active',
                where='(domain LIKE $search_str OR description LIKE $search_str) %s' % (sql_append_status),
                order='domain',
            )

            if qr_domain:
                result['domain'] = iredutils.convert_sql_records_to_unicode(qr_domain)

        if 'admin' in account_type:
            qr_admin = conn.select(
                'admin',
                vars=sql_vars,
                what='username,name,active',
                where='(username LIKE $search_str OR name LIKE $search_str) %s' % (sql_append_status),
                order='username',
            )

            if qr_admin:
                result['admin'] = iredutils.convert_sql_records_to_unicode(qr_admin) or []

                # Get all global admin accounts.
                qr = sql_lib_admin.get_all_global_admins(conn=conn)
                if qr[0] is True:
                    result['allGlobalAdmins'] = qr[1]

    # Search user accounts.
    if 'user' in account_type:
        search_str_user = sql_vars['search_str_exclude_domain']
        if '@' in sql_vars['search_str']:
            search_str_user = sql_vars['search_str']
        sql_vars['search_str_user'] = search_str_user

        qr_user = conn.select(
            'mailbox',
            vars=sql_vars,
            what='username,name,quota,employeeid,active',
            where='(username LIKE $search_str_user OR name LIKE $search_str) %s %s' % (
                sql_append_status, sql_append_domains,
            ),
            order='username')

        # Query user alias address.
        qr_user_alias = conn.select(
            ['alias', 'mailbox'],
            vars=sql_vars,
            what='mailbox.username, mailbox.name, mailbox.quota, mailbox.employeeid, mailbox.active',
            where='(alias.address LIKE $search_str_user OR alias.name LIKE $search_str) AND alias.goto=mailbox.username AND alias.is_alias=1',
            group='mailbox.username',
            order='mailbox.username')

        if qr_user:
            result['user'] += iredutils.convert_sql_records_to_unicode(qr_user) or []

        if qr_user_alias:
            _user_alias = iredutils.convert_sql_records_to_unicode(qr_user_alias) or []

            # Remove duplicate records.
            for i in _user_alias:
                if not (i in result['user']):
                    result['user'] += [i]

    # Search alias accounts.
    if 'alias' in account_type:
        search_str_alias = sql_vars['search_str_exclude_domain']
        if '@' in sql_vars['search_str']:
            search_str_alias = sql_vars['search_str']
        sql_vars['search_str_alias'] = search_str_alias

        qr_alias = conn.select(
            'alias',
            vars=sql_vars,
            what='address,name,accesspolicy,domain,active',
            where='(address LIKE $search_str_alias OR name LIKE $search_str) AND islist=1 %s %s' % (
                sql_append_status, sql_append_domains,
            ),
            order='address',
        )

        if qr_alias:
            result['alias'] = iredutils.convert_sql_records_to_unicode(qr_alias) or []

    if result:
        return (True, result)
    else:
        return (False, [])


def get_account_used_quota(conn, accounts):
    '''Return dict of account/quota size pairs.

    accounts -- must be list/tuple of email addresses.
    '''
    if not accounts:
        return {}

    # Pre-defined dict of used quotas.
    #   {'user@domain.ltd': {'bytes': INTEGER, 'messages': INTEGER,}}
    used_quota = {}

    # Get used quota.
    try:
        qr = conn.select('used_quota',
                         vars={'accounts': accounts},
                         where='username IN $accounts',
                         what='username,bytes,messages')

        for uq in qr:
            used_quota[uq.username] = {'bytes': uq.get('bytes', 0),
                                       'messages': uq.get('messages', 0)}
    except:
        pass

    return used_quota
