# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from controllers import decorators as base_decorators
from controllers.utils import tuple_to_api_render
from libs import iredutils
from settings import LOG_PERMISSION_DENIED
from libs.sqllib import SQLWrap
from libs.sqllib import admin as sql_lib_admin

session = web.config.get('_session', {})

#require_api_auth_token = base_decorators.require_api_auth_token
require_login = base_decorators.require_login
require_admin_login = base_decorators.require_admin_login
require_global_admin = base_decorators.require_global_admin
require_user_login = base_decorators.require_user_login
csrf_protected = base_decorators.csrf_protected

require_auth_token = base_decorators.require_auth_token
api_require_global_admin = base_decorators.api_require_global_admin


def require_domain_access(func):
    def proxyfunc(*args, **kw):
        if not session.get('username'):
            raise web.seeother('/login?msg=LOGIN_REQUIRED')

        # Check domain global admin.
        if session.get('is_global_admin'):
            return func(*args, **kw)
        else:
            username = session.get('username')
            # admin/user is viewing its own data
            if username == kw.get('mail') \
               or username.endswith('@' + kw.get('domain', 'NONE')):
                return func(*args, **kw)

            if 'domain' in kw and iredutils.is_domain(kw.get('domain')):
                domain = web.safestr(kw['domain'])
            elif 'mail' in kw and iredutils.is_email(kw.get('mail')):
                domain = web.safestr(kw['mail']).split('@')[-1]
            elif 'admin' in kw and iredutils.is_email(kw.get('admin')):
                domain = web.safestr(kw['admin']).split('@')[-1]
            else:
                # Try to use the first valid domain name or email address as
                # key, it's passed from controllers/*.
                for arg in args:
                    if iredutils.is_domain(arg):
                        domain = arg
                        break
                    elif iredutils.is_email(arg):
                        domain = arg.split('@', 1)[-1]
                        break

                if not domain:
                    if LOG_PERMISSION_DENIED:
                        web.log_error('PERMISSION_DENIED (1) raised in @require_domain_access, triggered in module: %s.py, function: %s(). No target domain for accessing.' % (func.__module__, func.__name__))

                    raise web.seeother('/domains?msg=PERMISSION_DENIED')

            # Check whether is domain admin.
            sql_wrap = SQLWrap()
            is_admin = sql_lib_admin.is_domain_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     admin=username)
            if is_admin:
                return func(*args, **kw)
            else:
                if LOG_PERMISSION_DENIED:
                    web.log_error('PERMISSION_DENIED (2) raised in @require_domain_access, triggered in module: %s.py, function: %s(), accessing data: admin=%s, domain=%s' % (func.__module__, func.__name__, username, domain))

                raise web.seeother('/domains?msg=PERMISSION_DENIED')
    return proxyfunc


def api_require_domain_access(func):
    if not iredutils.is_allowed_api_client(web.ctx.ip):
        return tuple_to_api_render((False, 'NOT_AUTHORIZED'))

    def proxyfunc(*args, **kw):
        if not session.get('username'):
            return tuple_to_api_render((False, 'LOGIN_REQUIRED'))

        # Check domain global admin.
        if session.get('is_global_admin'):
            return func(*args, **kw)
        else:
            username = session.get('username')
            # admin/user is viewing its own data
            if username == kw.get('mail') \
               or username.endswith('@' + kw.get('domain', 'NONE')):
                return func(*args, **kw)

            if 'domain' in kw and iredutils.is_domain(kw.get('domain')):
                domain = web.safestr(kw['domain'])
            elif 'mail' in kw and iredutils.is_email(kw.get('mail')):
                domain = web.safestr(kw['mail']).split('@')[-1]
            elif 'admin' in kw and iredutils.is_email(kw.get('admin')):
                domain = web.safestr(kw['admin']).split('@')[-1]
            else:
                # Try to use the first valid domain name or email address as
                # key, it's passed from controllers/*.
                for arg in args:
                    if iredutils.is_domain(arg):
                        domain = arg
                        break
                    elif iredutils.is_email(arg):
                        domain = arg.split('@', 1)[-1]
                        break

                if not domain:
                    if LOG_PERMISSION_DENIED:
                        web.log_error('PERMISSION_DENIED (1) raised in @require_domain_access, triggered in module: %s.py, function: %s(). No target domain for accessing.' % (func.__module__, func.__name__))

                    return tuple_to_api_render((False, 'PERMISSION_DENIED'))

            # Check whether is domain admin.
            sql_wrap = SQLWrap()
            is_admin = sql_lib_admin.is_domain_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     admin=username)
            if is_admin:
                return func(*args, **kw)
            else:
                if LOG_PERMISSION_DENIED:
                    web.log_error('PERMISSION_DENIED (2) raised in @require_domain_access, triggered in module: %s.py, function: %s(), accessing data: admin=%s, domain=%s' % (func.__module__, func.__name__, username, domain))

                return tuple_to_api_render((False, 'PERMISSION_DENIED'))
    return proxyfunc
