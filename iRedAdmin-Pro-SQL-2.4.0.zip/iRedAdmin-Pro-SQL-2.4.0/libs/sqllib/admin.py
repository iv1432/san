# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils, iredpwd, form_utils
from libs.sqllib import auth

session = web.config.get('_session', {})


def is_global_admin(conn, admin):
    if not admin:
        return False

    if admin == session.get('username'):
        if session.get('is_global_admin'):
            return True
        else:
            return False

    # Not logged admin.
    try:
        qr = conn.select('domain_admins',
                         vars={'username': admin, 'domain': 'ALL'},
                         what='username',
                         where='username=$username AND domain=$domain',
                         limit=1)
        if qr:
            return True
        else:
            return False
    except:
        return False


def is_domain_admin(conn, domain, admin=session.get('username')):
    if not iredutils.is_domain(domain) or not iredutils.is_email(admin):
        return False

    if admin == session.get('username') \
       and session.get('is_global_admin') is True:
        return True

    try:
        qr = conn.select(
            'domain_admins',
            vars={'domain': domain, 'username': admin},
            what='username',
            where='domain=$domain AND username=$username AND active=1',
            limit=1,
        )
        if qr:
            return True
        else:
            return False
    except:
        return False


def is_admin_exists(conn, admin):
    # Return True if account is invalid or exist.
    admin = str(admin).lower()
    if not iredutils.is_email(admin):
        return True

    try:
        qr = conn.select(
            'admin',
            vars={'username': admin},
            what='username',
            where='username=$username',
            limit=1,
        )

        if qr:
            # Exists.
            return True

        return False
    except:
        # Return True as exist to not allow to create new domain/account.
        return True


def num_admins(conn):
    # Count separated admin accounts
    num = 0
    qr = conn.select('admin', what='COUNT(username) AS total')
    if qr:
        num = qr[0].total or 0

    return num


def num_user_admins(conn):
    # Count number of users which are marked as admins
    num = 0
    qr = conn.select(
        'mailbox',
        what='COUNT(username) AS total',
        where='isadmin=1 OR isglobaladmin=1',
    )
    if qr:
        num = qr[0].total or 0

    return num


def get_all_admins(conn, columns=None):
    """List all admins. Return (True, [records])."""
    sql_what = '*'
    if columns:
        sql_what = ','.join(columns)

    all_admins = []
    try:
        qr1 = conn.select('admin', what=sql_what)
        qr2 = conn.select('mailbox',
                          what=sql_what,
                          where='isadmin=1 OR isglobaladmin=1')

        for i in qr1:
            all_admins += [i]

        for i in qr2:
            all_admins += [i]

        return (True, all_admins)
    except Exception, e:
        return (False, str(e))


def get_paged_admins(conn, cur_page=1):
    total = 0

    # Get current page.
    cur_page = int(cur_page)

    sql_limit = ''
    if cur_page > 0:
        sql_limit = 'LIMIT %d OFFSET %d' % (
            settings.PAGE_SIZE_LIMIT,
            (cur_page - 1) * settings.PAGE_SIZE_LIMIT,
        )

    try:
        # Get number of total accounts
        total = num_admins(conn) + num_user_admins(conn)

        # Get records
        # Separate admins
        qr_admins = conn.query(
            """
            SELECT name, username, language, active
            FROM admin
            ORDER BY username ASC
            %s
            """ % (sql_limit)
        )

        qr_user_admins = conn.query(
            """
            SELECT name, username, language, active, isadmin, isglobaladmin
            FROM mailbox
            WHERE (isadmin=1 OR isglobaladmin=1)
            ORDER BY username ASC
            %s
            """ % (sql_limit)
        )
        return (True, {'total': total, 'records': list(qr_admins) + list(qr_user_admins)})
    except Exception, e:
        return (False, str(e))


def get_paged_domain_admins(conn, domain, columns=None, current_page=1, first_char=None):
    """Get all admins who have privilege to manage specified domain."""
    if columns:
        sql_what = ','.join(columns)
    else:
        sql_what = '*'

    sql_where = """username IN (
                   SELECT username FROM domain_admins
                   WHERE domain IN ('%s', 'ALL'))""" % domain

    if first_char:
        sql_where += ' AND username LIKE %s' % web.sqlquote(first_char.lower() + '%')

    total = 0
    all_admins = []
    try:
        qr_total = conn.select('mailbox',
                               what='COUNT(username) AS total',
                               where=sql_where)

        if qr_total:
            total = qr_total[0].total or 0
            qr = conn.select('mailbox',
                             what=sql_what,
                             where=sql_where,
                             limit=settings.PAGE_SIZE_LIMIT,
                             offset=(current_page - 1) * settings.PAGE_SIZE_LIMIT)

            for i in qr:
                all_admins += [i]

        return (True, {'total': total, 'records': all_admins})
    except Exception, e:
        return (False, str(e))


def get_all_global_admins(conn):
    admins = []
    try:
        qr = conn.select(
            'domain_admins',
            what='username,domain',
            where="domain='ALL'",
        )
        for r in qr:
            admins += [str(r.username).lower()]

        return (True, admins)
    except Exception, e:
        return (False, str(e))


# Get domains under control.
def get_managed_domains(conn, admin, domain_name_only=False, listed_only=False):
    admin = web.safestr(admin)

    if not iredutils.is_email(admin):
        return (False, 'INCORRECT_USERNAME')

    sql_left_join = ''
    if listed_only is False:
        sql_left_join = """OR domain_admins.domain='ALL'"""

    try:
        result = conn.query(
            """
            SELECT domain.domain
            FROM domain
            LEFT JOIN domain_admins ON (domain.domain=domain_admins.domain %s)
            WHERE domain_admins.username=$admin
            ORDER BY domain_admins.domain
            """ % (sql_left_join),
            vars={'admin': admin},
        )

        if domain_name_only is True:
            domains = []
            for i in result:
                if iredutils.is_domain(i.domain):
                    domains += [str(i.domain).lower()]

            return (True, domains)
        else:
            return (True, list(result))
    except Exception, e:
        return (False, str(e))


def num_managed_domains(conn, disabled_only=False):
    num = 0

    try:
        if session.get('is_global_admin'):
            if disabled_only:
                qr = conn.select('domain', what='COUNT(domain) AS total', where='active=0')
            else:
                qr = conn.select('domain', what='COUNT(domain) AS total')
        else:
            sql_where = ''
            if disabled_only is True:
                sql_where = 'AND active=0'

            qr = conn.query(
                """
                SELECT COUNT(domain.domain) AS total
                FROM domain
                LEFT JOIN domain_admins ON (domain.domain=domain_admins.domain)
                WHERE domain_admins.username=$admin %s
                """ % (sql_where),
                vars={'admin': session.get('username')},
            )

        num = qr[0].total or 0
    except Exception:
        pass

    return num


def num_managed_users(conn, domains=None):
    num = 0

    admin = session.get('username')

    if domains:
        domains = [str(d).lower() for d in domains if iredutils.is_domain(d)]
    else:
        qr = get_managed_domains(conn=conn,
                                 admin=admin,
                                 domain_name_only=True)
        if qr[0] is True:
            domains = qr[1]

    if not domains:
        return num

    sql_vars = {'admin': admin, 'domains': domains}

    try:
        if is_global_admin(conn=conn, admin=admin):
            if domains:
                qr = conn.select(
                    'mailbox',
                    vars=sql_vars,
                    what='COUNT(username) AS total',
                    where='domain IN $domains',
                )
            else:
                qr = conn.select('mailbox', what='COUNT(username) AS total')
        else:
            sql_append_where = ''
            if domains:
                sql_append_where = 'AND mailbox.domain IN %s' % web.sqlquote(domains)

            qr = conn.query(
                """
                SELECT COUNT(mailbox.username) AS total
                FROM mailbox
                LEFT JOIN domain_admins ON (mailbox.domain = domain_admins.domain)
                WHERE domain_admins.username=$admin %s
                """ % (sql_append_where),
                vars=sql_vars,
            )

        num = qr[0].total or 0
    except:
        pass

    return num


def num_managed_aliases(conn, domains=None):
    num = 0

    admin = session.get('username')

    if domains:
        domains = [str(d).lower() for d in domains if iredutils.is_domain(d)]
    else:
        qr = get_managed_domains(conn=conn,
                                 admin=admin,
                                 domain_name_only=True)
        if qr[0] is True:
            domains = qr[1]

    if not domains:
        return num

    sql_vars = {'admin': admin, 'domains': domains}

    try:
        if is_global_admin(conn=conn, admin=admin):
            if domains:
                qr = conn.select(
                    'alias',
                    what='COUNT(address) AS total',
                    where='islist=1',
                )
            else:
                qr = conn.select(
                    'alias',
                    vars=sql_vars,
                    what='COUNT(address) AS total',
                    where='islist=1 AND domain IN $domains',
                )
        else:
            sql_append_where = ''
            if domains:
                sql_append_where = 'AND alias.domain IN %s' % web.sqlquote(domains)

            qr = conn.query("""
                -- Get number of mail aliases
                SELECT COUNT(alias.address) AS total
                FROM alias
                LEFT JOIN domain_admins ON (alias.domain = domain_admins.domain)
                WHERE
                    domain_admins.username=$admin
                    AND alias.address <> alias.domain
                    AND alias.address <> alias.goto
                        %s
                """ % (sql_append_where),
                vars=sql_vars)

        num = qr[0].total or 0
    except:
        pass

    return num


def sum_all_used_quota(conn):
    """Return (messages, bytes)"""
    sum = (0, 0)

    admin = session.get('username')
    if is_global_admin(conn, admin):
        qr = conn.query(
            '''
            SELECT SUM(messages) AS messages, SUM(bytes) AS bytes
            FROM used_quota
            '''
        )
        counter = qr[0]
        sum = (counter.messages, counter.bytes)

    return sum


def add_admin_from_form(conn, form):
    cn = form.get('cn', '')
    mail = web.safestr(form.get('mail')).strip().lower()

    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    # Check admin exist.
    if is_admin_exists(conn=conn, admin=mail):
        return (False, 'ALREADY_EXISTS')

    is_global_admin = False
    if 'domainGlobalAdmin' in form:
        is_global_admin = True

    # Get language setting.
    lang = form_utils.get_language(form)

    # Get new password.
    newpw = web.safestr(form.get('newpw'))
    confirmpw = web.safestr(form.get('confirmpw'))

    result = iredpwd.verify_new_password(newpw, confirmpw)

    if result[0] is True:
        passwd = result[1]
    else:
        return result

    try:
        conn.insert('admin',
                    username=mail,
                    name=cn,
                    password=iredpwd.generate_password_hash(passwd),
                    language=lang,
                    created=iredutils.get_gmttime(),
                    active='1')

        if is_global_admin:
            conn.insert('domain_admins',
                        username=mail,
                        domain='ALL',
                        created=iredutils.get_gmttime(),
                        active='1')

        web.logger(msg="Create admin: %s." % (mail), event='create')
        return (True, )
    except Exception, e:
        return (False, str(e))


def profile(conn, mail):
    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    try:
        qr = conn.select(
            'admin',
            vars={'username': mail},
            where='username=$username',
            limit=1,
        )
        if qr:
            return (True, list(qr)[0])
        else:
            return (False, 'INVALID_MAIL')
    except Exception, e:
        return (False, str(e))


def delete_admins(conn, accounts):
    accounts = [str(v) for v in accounts if iredutils.is_email(v)]

    if not accounts:
        return (True, )

    sql_vars = {'accounts': accounts}

    try:
        # Standalone mail admins
        conn.delete('admin',
                    vars=sql_vars,
                    where='username IN $accounts')

        conn.delete('domain_admins',
                    vars=sql_vars,
                    where='username IN $accounts')

        # Unmark globa/domain admin which is mail user
        conn.update('mailbox',
                    vars=sql_vars,
                    where='username IN $accounts AND (isadmin=1 OR isglobaladmin=1)',
                    isadmin=0,
                    isglobaladmin=0)

        web.logger(event='delete', msg="Delete admin(s): %s." % ', '.join(accounts))

        return (True, )
    except Exception, e:
        return (False, str(e))


# Domain administration relationship in sql table `domain_admins`:
#   username=admin_email, domain='domain.com'
# Global admin will have ADDITIONAL record:
#   username=admin_email, domain='ALL'
def update(conn, mail, profile_type, form):
    mail = str(mail).lower()

    # Don't allow to view/update other admins' profile.
    if mail != session.get('username') and not session.get('is_global_admin'):
        return (False, 'PERMISSION_DENIED')

    sql_vars = {'username': mail}

    if profile_type == 'general':
        # Name, preferred language
        cn = form.get('cn', '')
        lang = form_utils.get_language(form)

        try:
            conn.update('admin',
                        vars=sql_vars,
                        where='username=$username',
                        name=cn,
                        language=lang)

            # Update language immediately.
            if session.get('username') == mail and session.get('lang') != lang:
                session['lang'] = lang

        except Exception, e:
            return (False, str(e))

        if session.get('is_global_admin') is True:
            # Update account status
            sql_account_status = 0    # Disabled
            if 'accountStatus' in form:
                sql_account_status = 1    # Active

            try:
                conn.update('admin',
                            vars=sql_vars,
                            where='username=$username',
                            active=sql_account_status)
            except Exception, e:
                return (False, str(e))

            # Check and set global admin type.
            is_global_admin = False
            if 'domainGlobalAdmin' in form:
                is_global_admin = True

            if is_global_admin:
                try:
                    conn.delete('domain_admins',
                                vars=sql_vars,
                                where='username=$username')

                    conn.insert('domain_admins',
                                username=mail,
                                created=iredutils.get_gmttime(),
                                domain='ALL',
                                active=sql_account_status)
                except Exception, e:
                    return (False, str(e))
            else:
                try:
                    conn.delete('domain_admins',
                                vars=sql_vars,
                                where="""username=$username AND domain='ALL'""")
                except Exception, e:
                    return (False, str(e))

            # Update managed domains.
            # Get domains from web form.
            newmds = form_utils.get_domain_names(form)

            if newmds:
                try:
                    # Delete old managed domains.
                    conn.delete('domain_admins',
                                vars=sql_vars,
                                where="""username=$username AND domain <> 'ALL'""")

                    # Insert new managed domains.
                    sql_inserts = []
                    for d in newmds:
                        sql_inserts += [{'username': mail,
                                         'domain': d,
                                         'created': iredutils.get_gmttime(),
                                         'active': sql_account_status}]
                    conn.multiple_insert('domain_admins', values=sql_inserts)
                    del sql_inserts
                except Exception, e:
                    return (False, str(e))

            # Update domain admin type in session immediately.
            if session.get('is_global_admin') \
               and not is_global_admin \
               and session['username'] == mail:
                session['is_global_admin'] = False

    elif profile_type == 'password':
        cur_passwd = web.safestr(form.get('oldpw', ''))
        newpw = web.safestr(form.get('newpw', ''))
        confirmpw = web.safestr(form.get('confirmpw', ''))

        # Verify new passwords.
        qr = iredpwd.verify_new_password(newpw, confirmpw)
        if qr[0] is True:
            passwd = iredpwd.generate_password_hash(qr[1])
        else:
            return qr

        if not session.get('is_global_admin'):
            # Verify old password.
            qr = auth.auth(username=mail,
                           password=cur_passwd,
                           account_type='admin',
                           verify_password=True)

            if not qr[0]:
                return qr

        # Hash/Encrypt new password.
        try:
            conn.update('admin',
                        vars=sql_vars,
                        where='username=$username',
                        password=passwd,
                        passwordlastchange=iredutils.get_gmttime())
        except Exception, e:
            raise web.seeother('/profile/admin/password/%s?msg=%s' % (mail, web.urlquote(e)))

    return (True, )
