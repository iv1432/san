# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils, form_utils

from libs.sqllib import sqlutils, decorators
from libs.sqllib import general as sql_lib_general
from libs.sqllib import domain as sql_lib_domain


def _strip_delimiter_in_emails(mails, delimiters=None):
    stripped_mails = {}

    for m in mails:
        new_mail = iredutils.strip_mail_ext_address(mail=m, delimiters=delimiters)

        if new_mail in stripped_mails:
            stripped_mails[new_mail].append(m)
        else:
            stripped_mails[new_mail] = [m]

    return stripped_mails


@decorators.require_domain_access
def change_email(conn, mail, new_mail):
    if not (iredutils.is_email(mail) and iredutils.is_email(new_mail)):
        return (False, 'INVALID_MAIL')

    (old_username, old_domain) = mail.split('@', 1)
    (new_username, new_domain) = new_mail.split('@', 1)

    if old_domain != new_domain:
        return (False, 'PERMISSION_DENIED')

    if sql_lib_general.is_email_exists(conn=conn, mail=new_mail):
        return (False, 'ALREADY_EXISTS')

    # Change email address
    try:
        sql_vars = {'mail': mail, 'new_mail': new_mail}

        conn.update('alias',
                    vars=sql_vars,
                    address=new_mail,
                    where='address=$mail')

        remove_member_from_all_aliases(conn=conn,
                                       member=mail,
                                       replaced_by=new_mail)

        return (True, )
    except Exception, e:
        return (False, str(e))


def add_alias_from_form(conn, domain, form):
    # Get domain name, username, cn.
    form_domain = form_utils.get_domain_name(form)
    username = web.safestr(form.get('listname')).strip().lower()
    mail = username + '@' + form_domain

    if domain != form_domain:
        return (False, 'PERMISSION_DENIED')

    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    # Define columns and values used to insert.
    columns = {'domain': domain,
               'address': mail,
               'goto': '',
               'created': iredutils.get_gmttime(),
               'islist': 1,
               'active': 1}

    # Check account existing.
    if sql_lib_general.is_email_exists(conn=conn, mail=mail):
        return (False, 'ALREADY_EXISTS')

    # Get domain profile.
    qr_profile = sql_lib_domain.profile(conn=conn, domain=domain)

    if qr_profile[0] is True:
        domain_profile = qr_profile[1]
    else:
        return qr_profile

    # Check account limit.
    num_exist = num_aliases_under_domain(conn=conn, domain=domain)

    if domain_profile.aliases == -1:
        return (False, 'NOT_ALLOWED')
    elif domain_profile.aliases > 0:
        if domain_profile.aliases <= num_exist:
            return (False, 'EXCEEDED_DOMAIN_ACCOUNT_LIMIT')

    # Get display name
    columns['name'] = form.get('cn', '')

    try:
        conn.insert('alias', **columns)

        web.logger(msg="Create mail alias: %s." % (mail),
                   domain=domain,
                   event='create')
        return (True, )
    except Exception, e:
        return (False, str(e))


def delete_aliases(conn, accounts):
    if not accounts:
        return (True, )

    # Get domain from first account
    domain = accounts[0].split('@', 1)[-1]

    sql_vars = {'domain': domain, 'accounts': accounts}

    try:
        conn.delete('alias',
                    vars=sql_vars,
                    where='address IN $accounts')

        web.logger(event='delete',
                   domain=accounts[0].split('@', 1)[-1],
                   msg="Delete alias: %s." % ', '.join(accounts))
    except Exception, e:
        return (False, str(e))

    # Remove alias from domain.settings: default_groups
    # Get domain profile.
    qr = sql_lib_domain.simple_profile(conn=conn,
                                       domain=domain,
                                       columns=['settings'])

    if qr[0] is True:
        domain_profile = qr[1]
        domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings'])
    else:
        return qr

    default_groups = domain_settings.get('default_groups', [])

    new_default_groups = [str(v).lower()
                          for v in default_groups
                          if v not in accounts]

    if default_groups != new_default_groups:
        if new_default_groups:
            domain_settings['default_groups'] = new_default_groups
        else:
            if 'default_groups' in domain_settings:
                domain_settings.pop('default_groups')

        new_domain_settings = sqlutils.account_settings_dict_to_string(domain_settings)

        try:
            conn.update('domain',
                        vars=sql_vars,
                        settings=new_domain_settings,
                        modified=iredutils.get_gmttime(),
                        where='domain = $domain')
        except Exception, e:
            return (False, str(e))

    return (True, )


@decorators.require_domain_access
def num_aliases_under_domain(conn, domain, disabled_only=False):
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    num = 0
    sql_vars = {'domain': domain}

    sql_where = ''
    if disabled_only:
        sql_where = ' AND active=0'

    try:
        qr = conn.select('alias',
                         vars=sql_vars,
                         what='COUNT(address) AS total',
                         where='islist=1 AND domain=$domain %s' % sql_where)
        num = qr[0].total or 0
    except:
        pass

    return num


@decorators.require_domain_access
def get_all_aliases(conn,
                    domain,
                    columns=None,
                    first_char=None,
                    page=0,
                    disabled_only=False):
    """Get all aliases under domain. Return (True, [records])."""
    domain = web.safestr(domain).lower()
    if not iredutils.is_domain(domain):
        raise web.seeother('/domains?msg=INVALID_DOMAIN_NAME')

    sql_columns = '*'
    if columns:
        sql_columns = ','.join(columns)

    sql_vars = {'domain': domain}

    additional_sql_where = ''
    if first_char:
        additional_sql_where = ' AND alias.address LIKE %s' % web.sqlquote(first_char.lower() + '%')

    if disabled_only:
        additional_sql_where = ' AND alias.active=0'

    try:
        if page:
            result = conn.select('alias',
                                 vars=sql_vars,
                                 what=sql_columns,
                                 where='islist=1 AND domain=$domain %s' % additional_sql_where,
                                 order='address ASC',
                                 limit=settings.PAGE_SIZE_LIMIT,
                                 offset=(page - 1) * settings.PAGE_SIZE_LIMIT)
        else:
            result = conn.select('alias',
                                 vars=sql_vars,
                                 what=sql_columns,
                                 where='islist=1 AND domain=$domain %s' % additional_sql_where,
                                 order='address ASC')

        return (True, list(result))
    except Exception, e:
        return (False, str(e))


@decorators.require_domain_access
def profile(conn, domain, mail):
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    if not mail.endswith('@' + domain):
        raise web.seeother('/domains?msg=PERMISSION_DENIED')

    try:
        qr = conn.select('alias',
                         vars={'address': mail},
                         where='address = $address AND islist=1')

        if qr:
            return (True, list(qr)[0])
        else:
            return (False, 'INVALID_MAIL')
    except Exception, e:
        return (False, str(e))


@decorators.require_domain_access
def update(conn, mail, profile_type, form):
    mail = web.safestr(mail).lower()
    domain = mail.split('@', 1)[-1]

    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    # change email address
    if profile_type == 'rename':
        # new email address
        new_mail = web.safestr(form.get('new_mail_username')).strip().lower() + '@' + domain
        qr = change_email(conn=conn, mail=mail, new_mail=new_mail)
        if qr[0]:
            raise web.seeother('/profile/alias/general/%s?msg=EMAIL_CHANGED' % new_mail)
        else:
            raise web.seeother('/profile/alias/general/%s?msg=%s' % (new_mail, web.urlquote(qr[1])))

    # Pre-defined.
    values = {'modified': iredutils.get_gmttime()}

    # Get cn.
    cn = form.get('cn', '')
    values['name'] = cn

    # check account status.
    values['active'] = 0
    if 'accountStatus' in form:
        # Enabled.
        values['active'] = 1

    # Get access policy.
    access_policy = str(form.get('accessPolicy'))
    if access_policy in settings.SQL_ALIAS_ACCESS_POLICIES:
        values['accesspolicy'] = access_policy

    # Get members & moderators from web form.
    form_members = [str(v).lower()
                    for v in form.get('mailForwardingAddress', [])
                    if iredutils.is_email(str(v))]

    form_moderators = [str(v).lower()
                       for v in form.get('moderators', [])
                       if iredutils.is_email(str(v)) or iredutils.is_domain(str(v).split('*@', 1)[-1])]

    # Get mail forwarding addresses & moderators from form.
    _addrs = form.get('newMailForwardingAddresses', '').splitlines()
    new_members = set()
    for addr in _addrs:
        try:
            # Avoid invalid string and email address
            v = str(addr).lower()
            if iredutils.is_email(v):
                new_members.add(v)
        except:
            pass

    _addrs = form.get('newModerators', '').splitlines()
    new_moderators = set()
    for addr in _addrs:
        try:
            # Avoid invalid string and email address
            v = str(addr).lower()
            if iredutils.is_email(v) or iredutils.is_domain(v.split('*@', 1)[-1]):
                new_moderators.add(v)
        except:
            pass

    # Get union set of old/new alias members.
    all_members = set(form_members) | new_members
    all_moderators = set(form_moderators) | new_moderators

    # Remove non-exist accounts in same domain.
    # Get alias members & moderators which in same domain.
    members_in_domain = [v for v in all_members if v.endswith('@' + domain)]
    members_not_in_domain = [v for v in all_members if not v.endswith('@' + domain)]
    moderators_in_domain = [v for v in all_moderators if v.endswith('@' + domain) and not v.startswith('*@')]
    moderators_not_in_domain = [v for v in all_moderators if not v.endswith('@' + domain)]

    # Verify internal members.
    if members_in_domain:
        # Remove '+extension' in email address
        stripped_members = _strip_delimiter_in_emails(members_in_domain)

        qr = conn.select(
            'alias',
            vars={'address': stripped_members.keys(), 'domain': domain},
            what='address',
            where='address IN $address AND domain = $domain',
        )
        members_in_domain = []
        for i in qr:
            members_in_domain += stripped_members[i.address]

    values['goto'] = ','.join(members_in_domain + members_not_in_domain)

    # Verify internal moderators.
    if moderators_in_domain:
        # Remove '+extension' in email address
        stripped_moderators = _strip_delimiter_in_emails(moderators_in_domain)
        qr = conn.select(
            'mailbox',
            vars={'username': stripped_moderators.keys(), 'domain': domain},
            what='username',
            where='username IN $username AND domain = $domain',
        )
        moderators_in_domain = []
        for i in qr:
            moderators_in_domain += stripped_moderators[i.username]

    values['moderators'] = ','.join(moderators_in_domain + moderators_not_in_domain)

    try:
        conn.update(
            'alias',
            vars={'address': mail},
            where='address=$address',
            **values
        )

        # Log changes.
        msg = "Update alias profile (%s)." % (mail)

        if access_policy:
            msg += " Access policy: %s." % (access_policy)

        if new_members:
            msg += " New members: %s." % (', '.join(new_members))

        if new_moderators:
            msg += " New moderators: %s." % (', '.join(new_moderators))

        web.logger(msg=msg, username=mail, domain=domain, event='update')

        return (True, )
    except Exception, e:
        return (False, str(e))


def remove_member_from_all_aliases(conn, member, replaced_by=None):
    if not iredutils.is_email(member):
        return (False, 'INVALID_MAIL')

    if replaced_by:
        if not iredutils.is_email(replaced_by):
            replaced_by = None

    # Remove/replace alias members
    try:
        qr = conn.select('alias',
                         what='address, goto',
                         where="""goto LIKE '%%%s%%' AND islist=1""" % member)

        if qr:
            for d in qr:
                addr = d.address
                goto = d.goto.split(',')
                if member in goto:
                    goto.remove(member)

                    if replaced_by:
                        goto.append(replaced_by)

                    conn.update('alias',
                                vars={'addr': addr},
                                goto=','.join(goto),
                                where='address=$addr')

        return (True, )
    except Exception, e:
        return (False, str(e))
