# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings


session = web.config.get('_session', {})


class MYSQLWrap(object):
    def __del__(self):
        try:
            self.conn.ctx.db.close()
        except:
            pass

    def __init__(self):
        # Initial DB connection and cursor.
        try:
            self.conn = web.database(
                dbn='mysql',
                host=settings.vmail_db_host,
                port=int(settings.vmail_db_port),
                db=settings.vmail_db_name,
                user=settings.vmail_db_user,
                pw=settings.vmail_db_password,
                charset='utf8',
            )
            self.conn.supports_multiple_insert = True
        except:
            return False


class PGSQLWrap(object):
    def __del__(self):
        try:
            self.conn.ctx.db.close()
        except:
            pass

    def __init__(self):
        # Initial DB connection and cursor.
        try:
            self.conn = web.database(
                dbn='postgres',
                host=settings.vmail_db_host,
                port=int(settings.vmail_db_port),
                db=settings.vmail_db_name,
                user=settings.vmail_db_user,
                pw=settings.vmail_db_password,
            )
            self.conn.supports_multiple_insert = True
        except:
            return False


if settings.backend == 'mysql':
    SQLWrap = MYSQLWrap
elif settings.backend == 'pgsql':
    SQLWrap = PGSQLWrap
