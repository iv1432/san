# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils, form_utils
from libs.languages import get_language_maps, TIMEZONES

from libs.sqllib import sqlutils, decorators
from libs.sqllib import general as sql_lib_general

from libs.amavisd import get_wblist_from_form, wblist as wblistlib

session = web.config.get('_session', {})

if session.get('enable_iredapd'):
    from libs.iredapd import throttle as iredapd_throttle
    from libs.iredapd import greylist as iredapd_greylist

if session.get('amavisd_enable_policy_lookup'):
    from libs.amavisd.core import AmavisdWrap
    from libs.amavisd.utils import delete_policy_accounts


def is_domain_exists(conn, domain):
    # Return True if account is invalid or exist.
    if not iredutils.is_domain(domain):
        return True

    sql_vars = {'domain': domain}

    try:
        # Query normal mail domain
        qr = conn.select('domain',
                         vars=sql_vars,
                         what='domain',
                         where='domain=$domain',
                         limit=1)

        if qr:
            return True

        # Query alias domain
        qr = conn.select('alias_domain',
                         vars=sql_vars,
                         what='alias_domain',
                         where='alias_domain=$domain',
                         limit=1)

        if qr:
            return True

        # Domain not exist
        return False
    except:
        # Return True as exist to not allow to create new domain/account.
        return True


# Get used quota of domains.
def get_domain_used_quota(conn, domains=None):
    used_quota = {}

    if not domains:
        return used_quota

    domains = [str(d).lower() for d in domains if iredutils.is_domain(d)]
    try:
        qr = conn.select(
            'used_quota',
            vars={'domains': domains},
            where='domain IN $domains',
            what='domain,SUM(bytes) AS size, SUM(messages) AS messages',
            group='domain',
            order='domain',
        )

        for r in qr:
            used_quota[str(r.domain)] = {'size': r.size, 'messages': r.messages}
    except:
        pass

    return used_quota


def get_all_domains(conn, columns=None, name_only=False):
    """Get all domains. Return (True, [records])."""
    if name_only:
        columns = ['domain']

    sql_what = '*'
    if columns:
        sql_what = ','.join(columns)

    if name_only:
        sql_what = 'domain'

    try:
        result = conn.select('domain', what=sql_what, order='domain ASC')

        if name_only:
            domain_names = [str(r.domain).lower() for r in result]
            return (True, domain_names)
        else:
            return (True, list(result))
    except Exception, e:
        return (False, str(e))


@decorators.require_domain_access
def get_primary_and_alias_domains(conn, domain, with_primary_domain=True):
    # Get list of alias domains and primary domain by quering domain name.
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    all_domains = []

    try:
        qr = conn.select('alias_domain',
                         vars={'domain': domain},
                         what='alias_domain',
                         where='target_domain = $domain')
        for i in qr:
            all_domains.append(str(i.alias_domain).lower())

        if with_primary_domain:
            all_domains.append(domain)

        all_domains.sort()

        return (True, all_domains)
    except Exception, e:
        return (False, str(e))


def delete_domains(conn, domains):
    domains = [str(v) for v in domains if iredutils.is_domain(v)]

    if not domains:
        return (True, )

    sql_vars = {'domains': domains, 'admin': session.get('username')}

    # Log maildir paths of existing users
    try:
        if settings.backend == 'mysql':
            sql_raw = '''
                INSERT INTO deleted_mailboxes (username, maildir, domain, admin)
                SELECT username, \
                       CONCAT(storagebasedirectory, '/', storagenode, '/', maildir) AS maildir, \
                       domain, \
                       $admin
                  FROM mailbox
                 WHERE domain IN $domains'''
        elif settings.backend == 'pgsql':
            sql_raw = '''
                INSERT INTO deleted_mailboxes (username, maildir, domain, admin)
                SELECT username, \
                       CONCAT(storagebasedirectory || '/' || storagenode || '/' || maildir), \
                       domain, \
                       $admin
                  FROM mailbox
                 WHERE domain IN $domains'''

        conn.query(sql_raw, vars=sql_vars)
    except:
        pass

    try:
        # Delete domain name
        for tbl in ['domain', 'alias', 'domain_admins', 'mailbox',
                    'recipient_bcc_domain', 'recipient_bcc_user',
                    'sender_bcc_domain', 'sender_bcc_user',
                    'used_quota']:
            conn.delete(tbl,
                        vars=sql_vars,
                        where='domain IN $domains')

        # Delete alias domain
        conn.delete('alias_domain',
                    vars=sql_vars,
                    where='alias_domain IN $domains OR target_domain IN $domains')

        # Delete domain admins
        for d in domains:
            conn.delete('domain_admins',
                        vars={'domain': '%%@' + d},
                        where='username LIKE $domain')
    except Exception, e:
        return (False, str(e))

    # Delete domains in Amavisd database: users, policy.
    if session.get('amavisd_enable_policy_lookup'):
        amavisd_wrap = AmavisdWrap()
        pdomains = ['@' + d for d in domains]
        try:
            delete_policy_accounts(conn=amavisd_wrap.lookup_db, accounts=pdomains)
        except:
            pass

    for d in domains:
        web.logger(event='delete',
                   domain=d,
                   msg="Delete domain: %s." % d)

    return (True, )


@decorators.require_domain_access
def simple_profile(conn, domain, columns=None):
    domain = str(domain).lower()
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    sql_what = '*'
    if columns:
        sql_what = ','.join(columns)

    try:
        qr = conn.select('domain',
                         vars={'domain': domain},
                         what=sql_what,
                         where='domain=$domain',
                         limit=1)

        if qr:
            p = list(qr)[0]
            return (True, p)
        else:
            return (False, 'INVALID_DOMAIN_NAME')
    except Exception, e:
        return (False, str(e))


@decorators.require_domain_access
def profile(conn, domain):
    domain = str(domain).lower()

    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    try:
        if settings.backend == 'mysql':
            sql_raw = '''
            SELECT domain.*,
                   sbcc.bcc_address AS sbcc_addr,
                   sbcc.active AS sbcc_active,
                   rbcc.bcc_address AS rbcc_addr,
                   rbcc.active AS rbcc_active,
                   alias.goto AS catchall,
                   alias.active AS catchall_active,
                   COUNT(DISTINCT mailbox.username) AS mailbox_count
              FROM domain
              LEFT JOIN sender_bcc_domain AS sbcc ON (sbcc.domain=domain.domain)
              LEFT JOIN recipient_bcc_domain AS rbcc ON (rbcc.domain=domain.domain)
              LEFT JOIN domain_admins ON (domain.domain = domain_admins.domain)
              LEFT JOIN mailbox ON (domain.domain = mailbox.domain)
              LEFT JOIN alias ON (domain.domain = alias.address
                                  AND alias.address <> alias.goto)
             WHERE domain.domain=$domain
          GROUP BY domain.domain, domain.description, domain.aliases,
                   domain.mailboxes, domain.maxquota, domain.quota,
                   domain.transport, domain.backupmx, domain.active
          ORDER BY domain.domain
             LIMIT 1
            '''
        elif settings.backend == 'pgsql':
            sql_raw = '''
                SELECT domain.domain, domain.description, domain.aliases,
                       domain.mailboxes, domain.maxquota, domain.quota,
                       domain.transport, domain.backupmx, domain.active,
                       domain.settings,
                       sbcc.bcc_address AS sbcc_addr,
                       sbcc.active AS sbcc_active,
                       rbcc.bcc_address AS rbcc_addr,
                       rbcc.active AS rbcc_active,
                       alias.goto AS catchall,
                       alias.active AS catchall_active,
                       COUNT(DISTINCT mailbox.username) AS mailbox_count
                  FROM domain
                       LEFT JOIN sender_bcc_domain AS sbcc ON (sbcc.domain=domain.domain)
                       LEFT JOIN recipient_bcc_domain AS rbcc ON (rbcc.domain=domain.domain)
                       LEFT JOIN domain_admins ON (domain.domain = domain_admins.domain)
                       LEFT JOIN mailbox ON (domain.domain = mailbox.domain)
                       LEFT JOIN alias ON (domain.domain = alias.address
                                           AND alias.address <> alias.goto)
                 WHERE domain.domain=$domain
              GROUP BY domain.domain, domain.description, domain.aliases,
                       domain.mailboxes, domain.maxquota, domain.quota,
                       domain.transport, domain.backupmx, domain.active,
                       domain.settings,
                       sbcc.bcc_address, sbcc.active,
                       rbcc.bcc_address, rbcc.active,
                       alias.goto, alias.active
              ORDER BY domain.domain
                 LIMIT 1
            '''

        qr = conn.query(sql_raw, vars={'domain': domain})

        if qr:
            # Return first element of query result.
            p = list(qr)[0]
            return (True, p)
        else:
            return (False, 'NO_SUCH_OBJECT')
    except Exception, e:
        return (False, str(e))


# Do not apply @decorators.require_domain_access
def get_domain_settings(conn, domain):
    try:
        qr = conn.select('domain',
                         vars={'domain': domain},
                         what='settings',
                         where='domain=$domain',
                         limit=1)
    except Exception, e:
        return (False, str(e))

    if qr:
        profile = qr[0]
        return (True, sqlutils.account_settings_string_to_dict(profile.settings))
    else:
        return (True, {})


# Do not apply @decorators.require_domain_access
def get_domain_enabled_services(conn, domain):
    qr = get_domain_settings(conn=conn, domain=domain)
    if qr[0] is True:
        domain_settings = qr[1]
        enabled_services = domain_settings.get('enabled_services', [])
        return (True, enabled_services)
    else:
        return qr


@decorators.require_domain_access
def sum_allocated_domain_quota(conn, domain):
    num = 0

    try:
        qr = conn.select('mailbox',
                         vars={'domain': domain},
                         what='SUM(quota) AS total',
                         where='domain = $domain')

        if qr:
            num = qr[0].total or 0
    except:
        pass

    return num


@decorators.require_domain_access
def num_users_under_domain(conn, domain):
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    num = 0
    sql_vars = {'domain': domain}

    try:
        qr = conn.select('mailbox',
                         vars=sql_vars,
                         what='COUNT(username) AS total',
                         where='domain=$domain')
        if qr:
            num = qr[0].total or 0
    except:
        pass

    return num


@decorators.require_domain_access
def get_all_alias_domains(conn, domain, name_only=False):
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    try:
        qr = conn.select('alias_domain',
                         vars={'domain': domain},
                         where='target_domain=$domain')

        if name_only is True:
            target_domains = [str(r.alias_domain).lower()
                              for r in qr
                              if iredutils.is_domain(r.alias_domain)]
            return (True, target_domains)
        else:
            return (True, list(qr))
    except Exception, e:
        return (False, str(e))


def add(conn, form):
    domain = form_utils.get_domain_name(form)

    # Check domain name.
    if not iredutils.is_domain(domain):
        return (False, 'INVALID_DOMAIN_NAME')

    # Check whether domain name already exist (domainName, domainAliasName).
    if is_domain_exists(conn=conn, domain=domain):
        return (False, 'ALREADY_EXISTS')

    # Get company/organization name.
    cn = form.get('cn', '')
    domain_quota = form_utils.get_domain_quota_and_unit(form)['quota']

    domain_settings = {}
    domain_settings['default_language'] = form_utils.get_language(form)
    domain_settings['default_user_quota'] = form_utils.get_quota(form, input_name='defaultQuota')
    domain_settings['max_user_quota'] = form_utils.get_quota(form, input_name='maxUserQuota')

    # Get numberOfUsers, numberOfAliases
    num_users = form_utils.get_single_value(form,
                                            input_name='numberOfUsers',
                                            is_integer=True,
                                            default_value=0)
    num_aliases = form_utils.get_single_value(form,
                                              input_name='numberOfAliases',
                                              is_integer=True,
                                              default_value=0)

    # Add domain in database.
    try:
        conn.insert('domain',
                    domain=domain,
                    description=cn,
                    transport=settings.default_mta_transport,
                    maxquota=domain_quota,
                    mailboxes=num_users,
                    aliases=num_aliases,
                    settings=sqlutils.account_settings_dict_to_string(domain_settings),
                    created=iredutils.get_gmttime(),
                    active='1')

        web.logger(msg="Create domain: %s." % (domain),
                   domain=domain,
                   event='create')
    except Exception, e:
        return (False, str(e))

    return (True, )


@decorators.require_domain_access
def update(conn, domain, profile_type, form):
    profile_type = str(profile_type)
    domain = str(domain)
    sql_vars = {'domain': domain}

    # Get current domain profile
    qr = simple_profile(conn=conn, domain=domain)
    if qr[0]:
        domain_profile = qr[1]
    del qr

    # Get domain settings
    domain_settings = sqlutils.account_settings_string_to_dict(domain_profile.get('settings', ''))

    # Check disabled domain profiles
    if not session.get('is_global_admin'):
        disabled_domain_profiles = domain_settings.get('disabled_domain_profiles', [])
        if profile_type in disabled_domain_profiles:
            return (False, 'PERMISSION_DENIED')

    # Pre-defined update key:value.
    updates = {'modified': iredutils.get_gmttime()}

    if profile_type == 'general':
        # Get name
        cn = form.get('cn', '')
        updates['description'] = cn

        # Get default quota for new user.
        defaultQuota = str(form.get('defaultQuota'))
        if defaultQuota.isdigit():
            domain_settings['default_user_quota'] = int(defaultQuota)
        else:
            domain_settings['default_user_quota'] = 0

        if session.get('is_global_admin'):
            # Get account status
            updates['active'] = 0
            if 'accountStatus' in form:
                updates['active'] = 1

            # Get domain quota size.
            domainQuota = str(form.get('domainQuota', 0))
            if domainQuota.isdigit():
                domainQuota = int(domainQuota)
            else:
                domainQuota = 0

            if domainQuota > 0:
                domainQuotaUnit = str(form.get('domainQuotaUnit', 'MB'))
                if domainQuotaUnit == 'GB':
                    domainQuota = domainQuota * 1024
                elif domainQuotaUnit == 'TB':
                    domainQuota = domainQuota * 1024 * 1024

            updates['maxquota'] = domainQuota

            # Get max user quota
            max_user_quota = str(form.get('maxUserQuota', '0'))
            if max_user_quota.isdigit():
                max_user_quota = int(max_user_quota)
            else:
                max_user_quota = 0

            if max_user_quota >= 0:
                max_user_quota_unit = str(form.get('maxUserQuotaUnit', 'MB'))
                if max_user_quota_unit == 'GB':
                    max_user_quota = max_user_quota * 1024
                elif max_user_quota_unit == 'TB':
                    max_user_quota = max_user_quota * 1024 * 1024

                if domainQuota > 0:
                    if max_user_quota <= domainQuota:
                        domain_settings['max_user_quota'] = max_user_quota
                    else:
                        domain_settings['max_user_quota'] = domainQuota
                else:
                    domain_settings['max_user_quota'] = max_user_quota

    elif profile_type == 'bcc':
        # BCC must handle alias domains.
        # Get all alias domains.
        bcc_alias_domains = [domain]
        qr = get_all_alias_domains(conn=conn,
                                   domain=domain,
                                   name_only=True)
        if qr[0] is True:
            bcc_alias_domains += qr[1]

        # Delete old records first.
        try:
            for d in bcc_alias_domains:
                conn.delete('sender_bcc_domain', where='domain=%s' % web.sqlquote(d))
                conn.delete('recipient_bcc_domain', where='domain=%s' % web.sqlquote(d))

                conn.delete('sender_bcc_user', where='domain=%s' % web.sqlquote(d))
                conn.delete('recipient_bcc_user', where='domain=%s' % web.sqlquote(d))
        except Exception, e:
            return (False, str(e))

        # Get bcc status
        rbcc_status = '0'
        if 'recipientbcc' in form:
            rbcc_status = '1'

        sbcc_status = '0'
        if 'senderbcc' in form:
            sbcc_status = '1'

        senderBccAddress = str(form.get('senderBccAddress', None))
        recipientBccAddress = str(form.get('recipientBccAddress', None))

        if iredutils.is_email(senderBccAddress):
            address_domain = senderBccAddress.split('@', -1)[-1]
            if is_domain_exists(conn=conn, domain=address_domain):
                # Is a hosted internal domain
                if not sql_lib_general.is_email_exists(conn=conn, mail=senderBccAddress):
                    senderBccAddress = None

            if senderBccAddress:
                for d in bcc_alias_domains:
                    try:
                        # Add domain bcc
                        conn.insert('sender_bcc_domain',
                                    domain=d,
                                    bcc_address=senderBccAddress,
                                    created=iredutils.get_gmttime(),
                                    modified=iredutils.get_gmttime(),
                                    active=sbcc_status)
                    except Exception, e:
                        return (False, str(e))

        if iredutils.is_email(recipientBccAddress):
            address_domain = recipientBccAddress.split('@', -1)[-1]
            if is_domain_exists(conn=conn, domain=address_domain):
                # Is a hosted internal domain
                if not sql_lib_general.is_email_exists(conn=conn, mail=recipientBccAddress):
                    recipientBccAddress = None

            if recipientBccAddress:
                for d in bcc_alias_domains:
                    try:
                        conn.insert('recipient_bcc_domain',
                                    domain=d,
                                    bcc_address=recipientBccAddress,
                                    created=iredutils.get_gmttime(),
                                    modified=iredutils.get_gmttime(),
                                    active=rbcc_status)
                    except Exception, e:
                        return (False, str(e))

    elif profile_type == 'relay':
        new_transport = str(form.get('mtaTransport', settings.default_mta_transport))
        updates['transport'] = new_transport

        if 'relay_without_verify_local_recipient' in form:
            if new_transport.startswith('smtp:') or new_transport.startswith(':'):
                updates['backupmx'] = 1

        # Get sender dependent relayhost
        relayhost = str(form.get('relayhost', ''))

        # Update relayhost
        _qr = sql_lib_general.update_sender_relayhost(conn=conn,
                                                      sender='@' + domain,
                                                      relayhost=relayhost)
        if not _qr[0]:
            return _qr

    elif profile_type == 'catchall':
        # Delete old records first.
        try:
            conn.delete('alias', vars=sql_vars, where='address=$domain')
        except Exception, e:
            return (False, str(e))

        # Get list of destination addresses.
        catchallAddress = set([str(v).lower()
                               for v in form.get('catchallAddress', '').split(',')
                               if iredutils.is_email(v)])

        # Get enable/disable status.
        enableCatchall = 0
        if 'enableCatchall' in form:
            enableCatchall = 1

        if len(catchallAddress) > 0:
            try:
                conn.insert('alias',
                            address=domain,
                            goto=','.join(catchallAddress),
                            domain=domain,
                            islist=0,
                            created=iredutils.get_gmttime(),
                            active=enableCatchall)
            except Exception, e:
                return (False, str(e))

    elif profile_type == 'aliases':
        # Get old alias domains
        old_alias_domains = []
        qr = get_all_alias_domains(conn=conn,
                                   domain=domain,
                                   name_only=True)
        if qr[0] is True:
            old_alias_domains = qr[1]

        # Delete old records first.
        try:
            conn.delete('alias_domain',
                        vars=sql_vars,
                        where='target_domain=$domain')
        except Exception, e:
            return (False, str(e))

        # Get domain aliases from web form and store in LDAP.
        all_alias_domains = [
            str(d).lower()
            for d in form.get('domainAliasName', [])
            if d != domain and not is_domain_exists(conn=conn, domain=d)
        ]

        removed_alias_domains = [d for d in old_alias_domains if d not in all_alias_domains]
        for d in removed_alias_domains:
            # Delete all records in bcc tables.
            d_in_sql = web.sqlquote(d)
            conn.delete('sender_bcc_domain', where='domain=%s' % d_in_sql)
            conn.delete('recipient_bcc_domain', where='domain=%s' % d_in_sql)
            conn.delete('sender_bcc_user', where='domain=%s' % d_in_sql)
            conn.delete('recipient_bcc_user', where='domain=%s' % d_in_sql)

        if all_alias_domains:
            v = []
            for ad in all_alias_domains:
                v += [{'alias_domain': ad,
                       'target_domain': domain,
                       'created': iredutils.get_gmttime(),
                       'active': 1}]

            # Add alis domains.
            try:
                conn.multiple_insert('alias_domain', values=v)
            except Exception, e:
                return (False, str(e))

            # Update bcc records for existing accounts
            try:
                # Domain bcc
                for domain_bcc_table in ['sender_bcc_domain', 'recipient_bcc_domain']:
                    # Get all bcc records of mail users, then add same bcc for alias domains
                    qr = conn.select(domain_bcc_table,
                                     vars=sql_vars,
                                     what='domain,bcc_address,active',
                                     where='domain=$domain')

                    new_bcc_records = []
                    for ad in all_alias_domains:
                        for r in qr:
                            new_bcc_records += [{
                                'domain': ad,
                                'bcc_address': r.bcc_address,
                                'active': r.active,
                                'domain': ad,
                                'created': iredutils.get_gmttime(),
                            }]

                    if new_bcc_records:
                        conn.multiple_insert(domain_bcc_table, values=new_bcc_records)
                        del new_bcc_records

                # User bcc
                for user_bcc_table in ['sender_bcc_user', 'recipient_bcc_user']:
                    qr = conn.select(user_bcc_table,
                                     vars=sql_vars,
                                     what='username,bcc_address,active',
                                     where='domain=$domain')

                    new_bcc_records = []
                    for ad in all_alias_domains:
                        for r in qr:
                            new_bcc_records += [{
                                'username': r.username.split('@', 1)[0] + '@' + ad,
                                'bcc_address': r.bcc_address,
                                'active': r.active,
                                'domain': ad,
                                'created': iredutils.get_gmttime(),
                            }]

                    if new_bcc_records:
                        conn.multiple_insert(user_bcc_table, values=new_bcc_records)
                        del new_bcc_records
            except Exception, e:
                pass

    elif profile_type == 'wblist':
        if session.get('is_global_admin') or 'wblist' not in disabled_domain_profiles:
            if session.get('amavisd_enable_policy_lookup'):
                wl_senders = get_wblist_from_form(form, 'wl_sender')
                bl_senders = get_wblist_from_form(form, 'bl_sender')
                wl_rcpts = get_wblist_from_form(form, 'wl_rcpt')
                bl_rcpts = get_wblist_from_form(form, 'bl_rcpt')

                wblist_lib = wblistlib.WBList()
                qr = wblist_lib.add_wblist(account='@'+domain,
                                           wl_senders=wl_senders,
                                           bl_senders=bl_senders,
                                           wl_rcpts=wl_rcpts,
                                           bl_rcpts=bl_rcpts,
                                           flush_before_import=True)
                return qr

    elif profile_type == 'throttle':
        if session.get('enable_iredapd'):
            t_account = '@' + domain

            inbound_setting = form_utils.get_throttle_setting(form, account=t_account, inout_type='inbound')
            outbound_setting = form_utils.get_throttle_setting(form, account=t_account, inout_type='outbound')

            lib_trot = iredapd_throttle.Throttle()

            lib_trot.add_throttle(account=t_account,
                                  setting=inbound_setting,
                                  inout_type='inbound')

            lib_trot.add_throttle(account=t_account,
                                  setting=outbound_setting,
                                  inout_type='outbound')

    elif profile_type == 'greylisting':
        if session.get('enable_iredapd'):
            qr = iredapd_greylist.update_greylist_settings_from_form(account='@' + domain, form=form)
            return qr

    elif profile_type == 'advanced':
        # Update min/max password length
        min_pw_len = str(form.get('minPasswordLength', 0))
        max_pw_len = str(form.get('maxPasswordLength', 0))

        if min_pw_len.isdigit():
            min_pw_len = int(min_pw_len)
        else:
            min_pw_len = 0

        if min_pw_len > 0:
            domain_settings['min_passwd_length'] = min_pw_len

        if max_pw_len.isdigit():
            max_pw_len = int(max_pw_len)
        else:
            max_pw_len = 0

        if max_pw_len > 0:
            domain_settings['max_passwd_length'] = max_pw_len

        # Update default groups of newly created mail user
        default_groups = [str(v).lower()
                          for v in form.get('defaultList', [])
                          if iredutils.is_email(v)]

        if default_groups:
            domain_settings['default_groups'] = default_groups
        else:
            if 'default_groups' in domain_settings:
                domain_settings.pop('default_groups')

        # Update default language for new user
        default_language = form_utils.get_language(form)
        if default_language in get_language_maps():
            domain_settings['default_language'] = default_language

        tz_name = str(form.get('timezone', ''))
        if tz_name in TIMEZONES:
            domain_settings['timezone'] = tz_name
        else:
            domain_settings['timezone'] = ''

        # Default per-user bcc address
        if session.get('is_global_admin') or not 'bcc' in disabled_domain_profiles:
            rbcc = web.safestr(form.get('recipientBccAddress', ''))
            sbcc = web.safestr(form.get('senderBccAddress', ''))

            for (addr, name) in [(rbcc, 'default_recipient_bcc'), (sbcc, 'default_sender_bcc')]:
                if name in domain_settings:
                    domain_settings.pop(name)

                if iredutils.is_email(addr):
                    rbcc_domain = addr.split('@', 1)[-1]
                    # Verify existence before saving
                    if is_domain_exists(conn=conn, domain=rbcc_domain):
                        if sql_lib_general.is_email_exists(conn=conn, mail=addr):
                            domain_settings[name] = addr
                    else:
                        domain_settings[name] = addr

        # Get enabled_services.
        if form.get('enabledService', []):
            domain_settings['enabled_services'] = [str(v).lower() for v in form.get('enabledService', [])]
        else:
            if 'enabled_services' in domain_settings:
                domain_settings.pop('enabled_services')

        # Get disabled user preferences.
        if form.get('disabledUserPreference', []):
            domain_settings['disabled_user_preferences'] = [str(v).lower() for v in form.get('disabledUserPreference', [])]
        else:
            if 'disabled_user_preferences' in domain_settings:
                domain_settings.pop('disabled_user_preferences')

        if session.get('is_global_admin'):
            numberOfUsers = str(form.get('numberOfUsers'))
            numberOfAliases = str(form.get('numberOfAliases'))

            if numberOfUsers.isdigit() or numberOfUsers == '-1':
                updates['mailboxes'] = int(numberOfUsers)
            else:
                updates['mailboxes'] = 0

            if numberOfAliases.isdigit() or numberOfAliases == '-1':
                updates['aliases'] = int(numberOfAliases)
            else:
                updates['aliases'] = 0

            # Get disabled domain profiles.
            if form.get('disabledDomainProfile', []):
                domain_settings['disabled_domain_profiles'] = [str(v).lower() for v in form.get('disabledDomainProfile', [])]
            else:
                if 'disabled_domain_profiles' in domain_settings:
                    domain_settings.pop('disabled_domain_profiles')

            # Get disabled user profiles.
            if form.get('disabledUserProfile', []):
                domain_settings['disabled_user_profiles'] = [str(v).lower() for v in form.get('disabledUserProfile', [])]
            else:
                if 'disabled_user_profiles' in domain_settings:
                    domain_settings.pop('disabled_user_profiles')
    elif profile_type == 'backupmx':
        is_backupmx = False
        if 'backupmx' in form:
            is_backupmx = True

        primary_mx_ip = form_utils.get_single_value(form,
                                                    input_name='primary_mx_ip',
                                                    to_string=True)

        if is_backupmx and iredutils.is_strict_ip(primary_mx_ip):
            updates['backupmx'] = 1
            updates['transport'] = 'relay:[%s]' % primary_mx_ip
        else:
            updates['backupmx'] = 0
            updates['transport'] = settings.default_mta_transport

    updates['settings'] = sqlutils.account_settings_dict_to_string(domain_settings)
    try:
        conn.update('domain',
                    vars=sql_vars,
                    where='domain=$domain',
                    **updates)

        web.logger(msg="Update domain profile: %s (%s)." % (domain, profile_type),
                   domain=domain,
                   event='update')

        return (True, )
    except Exception, e:
        return (False, str(e))


def get_paged_domains(conn, first_char=None, cur_page=1, disabled_only=False):
    admin = session.get('username')
    page = int(cur_page) or 1

    sql_where = ''
    if session.get('is_global_admin'):
        if first_char:
            sql_where = """WHERE a.domain LIKE %s""" % web.sqlquote(first_char.lower() + '%')
    else:
        sql_where = ' WHERE domain_admins.username = %s' % web.sqlquote(admin)
        if first_char:
            sql_where += """ AND a.domain LIKE %s""" % web.sqlquote(first_char.lower() + '%')

    if disabled_only:
        if sql_where:
            sql_where += ' AND a.active=0'
        else:
            sql_where += ' WHERE a.active=0'

    # RAW sql command used to get records.
    # TODO split one big/complex command to multiple commands
    #   1: query `domain` to get domain profiles
    #   2: query `alias` to count mail alias accounts
    #   3: query `mailbox` to count mail user accounts
    #   4: sum `mailbox.quota` to sum allocated quota
    if settings.backend == 'mysql':
        raw_sql_get_all_domains = """
            SELECT a.domain, a.description, a.aliases, a.mailboxes, a.maxquota, a.quota,
                   a.transport, a.backupmx, a.active,
                   IFNULL(b.alias_count, 0) AS alias_count,
                   IFNULL(c.mailbox_count, 0) AS mailbox_count,
                   IFNULL(c.quota_count, 0) AS quota_count
              FROM domain AS a
                   LEFT JOIN (SELECT domain, COUNT(address) AS alias_count
                                FROM alias
                               WHERE address<>goto
                                 AND address<>domain
                                 AND address NOT IN (SELECT username FROM mailbox)
                            GROUP BY domain
                             ) AS b ON (a.domain=b.domain)
                   LEFT JOIN (SELECT domain,
                                     SUM(mailbox.quota) AS quota_count,
                                     COUNT(username) AS mailbox_count
                                FROM mailbox
                            GROUP BY domain
                             ) AS c ON (a.domain=c.domain)
                   LEFT JOIN domain_admins ON (domain_admins.domain=a.domain)
                   %s
          GROUP BY a.domain
          ORDER BY a.domain
             LIMIT %d
            OFFSET %d
        """ % (sql_where, settings.PAGE_SIZE_LIMIT, (page - 1) * settings.PAGE_SIZE_LIMIT)
    else:
        # settings.backend == 'pgsql':
        raw_sql_get_all_domains = """
            SELECT a.domain, a.description, a.aliases, a.mailboxes, a.maxquota, a.quota,
                   a.transport, a.backupmx, a.active,
                   COALESCE(b.alias_count, 0) AS alias_count,
                   COALESCE(c.mailbox_count, 0) AS mailbox_count,
                   COALESCE(c.quota_count, 0) AS quota_count
              FROM domain AS a
                   LEFT JOIN (SELECT domain, COUNT(address) AS alias_count
                                FROM alias
                                WHERE address<>goto
                                 AND address<>domain
                                 AND address NOT IN (SELECT username FROM mailbox)
                            GROUP BY domain
                             ) AS b ON (a.domain=b.domain)
                    LEFT JOIN (SELECT domain,
                                      SUM(mailbox.quota) AS quota_count,
                                      COUNT(username) AS mailbox_count
                                 FROM mailbox
                             GROUP BY domain
                              ) AS c ON (a.domain=c.domain)
                    LEFT JOIN domain_admins ON (domain_admins.domain=a.domain)
                    %s
           GROUP BY a.domain, a.description, a.aliases, a.mailboxes, a.maxquota, a.quota,
                    a.transport, a.backupmx, a.active,
                    mailbox_count, alias_count, quota_count
           ORDER BY a.domain
              LIMIT %d
             OFFSET %d
            """ % (sql_where, settings.PAGE_SIZE_LIMIT, (page - 1) * settings.PAGE_SIZE_LIMIT)

    try:
        result_all_domains = conn.query(raw_sql_get_all_domains)

        return (True, list(result_all_domains))
    except Exception, e:
        return (False, str(e))
