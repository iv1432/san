# Author: Zhang Huangbin <zhb@iredmail.org>

# Note: this module will be used in modules under libs/sqllib/, so do not
#       import modules under libs/sqllib/ in this file.

import web
from libs import iredutils


def is_email_exists(conn, mail):
    # Return True if account is invalid or exist.
    mail = str(mail).lower()

    if not iredutils.is_email(mail):
        return True

    sql_vars = {'email': mail}

    try:
        # `alias` table has email addr of mail user account and alias account.
        qr = conn.select('alias',
                         vars=sql_vars,
                         what='address',
                         where='address=$email',
                         limit=1)

        if qr:
            return True

        return False
    except Exception:
        return True


def get_sender_relayhost(conn, sender):
    """Get relayhost of specified sender.

    sender could be an email address, or a domain name prefixed with '@'.
    """

    relayhost = ''

    # Make sure we have correct sender address.
    if iredutils.is_email(sender):
        pass
    elif sender.startswith('@'):
        # If sender is not '@domain.com', return empty value.
        d = sender.lstrip('@')
        if not iredutils.is_domain(d):
            return ''
    elif iredutils.is_domain(sender):
        sender = '@' + sender

    try:
        qr = conn.select('sender_relayhost',
                         vars={'account': sender},
                         what='relayhost',
                         where='account = $account',
                         limit=1)
        if qr:
            relayhost = str(qr[0]['relayhost'])
    except Exception, e:
        web.log_error(e)

    return relayhost


def update_sender_relayhost(conn, sender, relayhost):
    """Update relayhost for specified sender.

    sender could be an email address, or a domain name prefixed with '@'.
    """

    # Make sure we have correct sender address.
    if iredutils.is_email(sender):
        pass
    elif sender.startswith('@'):
        # If sender is not '@domain.com', return empty value.
        d = sender.lstrip('@')
        if not iredutils.is_domain(d):
            return ''
    elif iredutils.is_domain(sender):
        sender = '@' + sender

    try:
        # Delete existing record first.
        conn.delete('sender_relayhost',
                    vars={'account': sender},
                    where='account=$account')

        if relayhost:
            conn.insert('sender_relayhost',
                        account=sender,
                        relayhost=relayhost)

        return (True, )
    except Exception, e:
        return (False, str(e))


def filter_existing_emails(conn, mails):
    mails = [str(v).lower() for v in mails if iredutils.is_email(v)]
    mails = list(set(mails))

    exist = []
    nonexist = []

    try:
        qr = conn.select('alias',
                         vars={'mails': mails},
                         what='address',
                         where='address IN $mails')
        if not qr:
            # All are not exist
            nonexist = mails
        else:
            for i in qr:
                exist.append(str(i['address']).lower())

            nonexist = [v for v in mails if v not in exist]
    except:
        pass

    return {'exist': exist, 'nonexist': nonexist}


def filter_existing_domains(conn, domains):
    domains = [str(v).lower() for v in domains if iredutils.is_domain(v)]
    domains = list(set(domains))

    exist = []
    nonexist = []

    try:
        # Primary domains
        qr1 = conn.select('domain',
                          vars={'domains': domains},
                          what='domain',
                          where='domain IN $domains')

        # Alias domains
        qr2 = conn.select('alias_domain',
                          vars={'domains': domains},
                          what='alias_domain AS domain',
                          where='alias_domain IN $domains')

        qr = list(qr1) + list(qr2)
        if not qr:
            nonexist = domains
        else:
            for i in qr:
                exist.append(str(i['domain']).lower())

            nonexist = [d for d in domains if d not in exist]
    except:
        pass

    return {'exist': exist, 'nonexist': nonexist}
