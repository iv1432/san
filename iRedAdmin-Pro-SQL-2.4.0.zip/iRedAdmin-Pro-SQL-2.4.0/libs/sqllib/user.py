# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils, iredpwd, form_utils

from libs.languages import get_language_maps, TIMEZONES

from libs.sqllib import sqlutils, decorators
from libs.sqllib import general as sql_lib_general
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import alias as sql_lib_alias

from libs.amavisd import spampolicy as spampolicylib
from libs.amavisd import get_wblist_from_form, wblist as wblistlib

session = web.config.get('_session', {})

if session.get('amavisd_enable_policy_lookup'):
    from libs.amavisd.core import AmavisdWrap
    from libs.amavisd.utils import delete_policy_accounts

if session.get('enable_iredapd'):
    from libs.iredapd import throttle as iredapd_throttle
    from libs.iredapd import greylist as iredapd_greylist
    from libs.iredapd import utils as iredapd_utils

ENABLED_SERVICES = [
    'enablesmtp', 'enablesmtpsecured',
    'enablepop3', 'enablepop3secured',
    'enableimap', 'enableimapsecured',
    'enablesogo',
    'enablemanagesieve', 'enablemanagesievesecured',
    'enablesieve', 'enablesievesecured',
    'enabledeliver', 'enableinternal',
]


@decorators.require_domain_access
def change_email(conn, mail, new_mail):
    if not (iredutils.is_email(mail) and iredutils.is_email(new_mail)):
        return (False, 'INVALID_MAIL')

    (old_username, old_domain) = mail.split('@', 1)
    (new_username, new_domain) = new_mail.split('@', 1)

    if old_domain != new_domain:
        return (False, 'PERMISSION_DENIED')

    if sql_lib_general.is_email_exists(conn=conn, mail=new_mail):
        return (False, 'ALREADY_EXISTS')

    # Change email address
    try:
        sql_vars = {'mail': mail, 'new_mail': new_mail}

        conn.update('mailbox',
                    vars=sql_vars,
                    username=new_mail,
                    where='username=$mail')

        # Replace old email by the new one in `alias.goto`
        qr = conn.select('alias',
                         vars=sql_vars,
                         what='address, goto',
                         where='address=$mail AND islist=0',
                         limit=1)

        if qr:
            record = qr[0]
            goto = record.get('goto', '')
            if goto == mail:
                new_goto = new_mail
            else:
                # Remove old email
                new_goto = [str(addr).strip().lower()
                            for addr in goto.split(',')
                            if iredutils.is_email(addr)]

                # append new email
                if mail in new_goto:
                    new_goto.remove(mail)
                    new_goto.append(new_mail)

            conn.update('alias',
                        vars=sql_vars,
                        address=new_mail,
                        goto=new_goto,
                        where='address=$mail AND islist=0')

        sql_lib_alias.remove_member_from_all_aliases(conn=conn,
                                                     member=mail,
                                                     replaced_by=new_mail)

        return (True, )
    except Exception, e:
        return (False, str(e))


def delete_users(conn, accounts):
    accounts = [str(v) for v in accounts if iredutils.is_email(v)]

    if not accounts:
        return (True, )

    sql_vars = {'accounts': accounts, 'admin': session.get('username')}

    # Log maildir path of deleted users.
    try:
        if settings.backend == 'mysql':
            sql_raw = '''
                INSERT INTO deleted_mailboxes (username, maildir, domain, admin)
                SELECT username, \
                       CONCAT(storagebasedirectory, '/', storagenode, '/', maildir) AS maildir, \
                       SUBSTRING_INDEX(username, '@', -1), \
                       $admin
                  FROM mailbox
                 WHERE username IN $accounts'''
        elif settings.backend == 'pgsql':
            sql_raw = '''
                INSERT INTO deleted_mailboxes (username, maildir, domain, admin)
                SELECT username, \
                       CONCAT(storagebasedirectory || '/' || storagenode || '/' || maildir), \
                       SPLIT_PART(username, '@', 2), \
                       $admin
                  FROM mailbox
                 WHERE username IN $accounts'''

        conn.query(sql_raw, vars=sql_vars)
    except:
        pass

    try:
        for tbl in ['mailbox',
                    'domain_admins',
                    'recipient_bcc_user',
                    'sender_bcc_user',
                    'used_quota']:
            conn.delete(
                tbl,
                vars=sql_vars,
                where='username IN $accounts',
            )

        conn.delete(
            'alias',
            vars=sql_vars,
            where='address IN $accounts',
        )

        # Remove users from alias.goto.
        qr = conn.select(
            'alias',
            what='address,goto',
            where='''islist=1 AND (%s)''' % ' OR '.join(
                ['goto LIKE %s' % web.sqlquote('%%' + v + '%%') for v in accounts]
            ),
        )

        # Update aliases, remove deleted users.
        for als in qr:
            exist_members = [v for v in str(als.goto).replace(' ', '').split(',')]

            # Skip if MySQL pattern matching doesn't get correct results.
            if not set(accounts) & set(exist_members):
                continue

            conn.update(
                'alias',
                vars={'address': als.address},
                where='address = $address',
                goto=','.join([str(v) for v in exist_members if v not in accounts]),
                modified=iredutils.get_gmttime(),
            )
    except Exception, e:
        return (False, str(e))

    # Delete records in Amavisd database: users, policy
    if session.get('amavisd_enable_policy_lookup'):
        amavisd_wrap = AmavisdWrap()
        try:
            delete_policy_accounts(conn=amavisd_wrap.lookup_db, accounts=accounts)
        except:
            pass

    if session.get('enable_iredapd'):
        iredapd_utils.cleanup_removed_accounts(accounts=accounts, inout_type='inbound')
        iredapd_utils.cleanup_removed_accounts(accounts=accounts, inout_type='outbound')

    web.logger(event='delete',
               domain=accounts[0].split('@', 1)[-1],
               msg="Delete user: %s." % ', '.join(accounts))

    return (True, )


@decorators.require_domain_access
def simple_profile(conn, mail, columns=None):
    '''Return value of sql column `mailbox.settings`.

    columns -- must be a iterable object
    '''
    try:
        qr = conn.select('mailbox',
                         vars={'username': mail},
                         what=','.join(columns) or '*',
                         where='username=$username',
                         limit=1)

        if qr:
            return (True, list(qr)[0])
        else:
            return (False, 'NO_SUCH_OBJECT')
    except Exception, e:
        return (False, str(e))


def get_user_settings(conn, mail, existing_settings=None):
    '''Return dict of per-user settings stored in SQL column: mailbox.settings.

    Value format: var:value, var2:value2, var3:value3
    existing_settings -- original value of sql column `mailbox.settings`.
    '''
    # @existing_settings: original value of sql column `mailbox.settings`.
    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    user_settings = {}

    # Get settings stored in sql column `mailbox.settings`
    if existing_settings:
        orig_settings = existing_settings
    else:
        qr = simple_profile(conn=conn, mail=mail, columns=['settings'])
        if qr[0]:
            orig_settings = qr[1]['settings']
        else:
            return qr

    if orig_settings:
        user_settings = sqlutils.account_settings_string_to_dict(orig_settings)

    return (True, user_settings)


def get_user_alias_addresses(conn, mail):
    """Get one user's alias addresses."""
    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    qr = conn.select('alias',
                     vars={'mail': mail},
                     what='address',
                     where='is_alias=1 AND alias_to=$mail')
    if qr:
        addrs = []
        for i in qr:
            addrs.append(i['address'])
        return (True, addrs)
    else:
        return (True, [])


def get_bulk_user_alias_addresses(conn, mails):
    """Get bulk users' alias addresses."""
    alias_addresses = {}
    try:
        qr = conn.select('alias',
                         vars={'addresses': mails},
                         what='address, alias_to',
                         where='is_alias=1 AND alias_to IN $addresses')
        for r in qr:
            mail = str(r.alias_to).lower()
            addr = str(r.address).lower()

            if not mail in alias_addresses:
                alias_addresses[mail] = [addr]
            else:
                alias_addresses[mail].append(addr)

        return (True, alias_addresses)
    except Exception, e:
        return (False, str(e))


def num_users_under_domains(conn, domains, disabled_only=False):
    # Count separated admin accounts
    num = 0
    if not domains:
        return num

    sql_where = ''
    if disabled_only:
        sql_where = 'AND active=0'

    sql_vars = {'domains': domains}
    try:
        qr = conn.select('mailbox',
                         vars=sql_vars,
                         what='COUNT(username) AS total',
                         where='domain IN $domains %s' % sql_where)
        if qr:
            num = qr[0].total or 0
    except:
        pass

    return num


@decorators.require_domain_access
def get_paged_users(conn,
                    domain,
                    cur_page=1,
                    admin_only=False,
                    sort_by_quota=False,
                    first_char=None,
                    disabled_only=False):
    domain = str(domain).lower()
    cur_page = int(cur_page) or 1

    sql_vars = {'domain': domain}
    sql_where = 'mailbox.domain=%s' % web.sqlquote(domain)

    if admin_only:
        sql_where += ' AND (mailbox.isadmin=1 OR mailbox.isglobaladmin=1)'

    if first_char:
        sql_where += ' AND mailbox.username LIKE %s' % web.sqlquote(first_char.lower() + '%')

    if disabled_only:
        sql_where += ' AND mailbox.active=0'

    try:
        if sort_by_quota:
            if settings.backend == 'mysql':
                sql_cmd_percentage = '100 * IFNULL(used_quota.bytes, 0)/(mailbox.quota * 1024 * 1024) as percentage'
            else:
                # ATTENTION:
                #   - 'COALESCE(X, 0) as percentage': set percentage of unlimited mailbox to 0
                #   - 'NULLIF()': set `mailbox.quota` of unlimited mailbox to null,
                #                 this way we can avoid PostgreSQL error: `division by zero`
                sql_cmd_percentage = 'COALESCE((100 * COALESCE(used_quota.bytes, 0)/(NULLIF(mailbox.quota, 0) * 1024 * 1024)), 0) as percentage'

            qr = conn.query("""
                SELECT
                    mailbox.username, mailbox.name, mailbox.quota,
                    mailbox.employeeid, mailbox.active, mailbox.isadmin,
                    mailbox.isglobaladmin,
                    %s
                FROM mailbox
                LEFT JOIN used_quota ON (used_quota.username = mailbox.username)
                WHERE %s
                ORDER BY percentage DESC, mailbox.username ASC
                LIMIT %d
                OFFSET %d
            """ % (sql_cmd_percentage,
                   sql_where,
                   settings.PAGE_SIZE_LIMIT,
                   (cur_page-1) * settings.PAGE_SIZE_LIMIT))
        else:
            qr = conn.select(
                'mailbox',
                vars=sql_vars,
                # Just query what we need to reduce memory use.
                what='username,name,quota,employeeid,active,isadmin,isglobaladmin',
                where=sql_where,
                order='username ASC',
                limit=settings.PAGE_SIZE_LIMIT,
                offset=(cur_page - 1) * settings.PAGE_SIZE_LIMIT,
            )

        return (True, list(qr))
    except Exception, e:
        return (False, str(e))


def mark_user_as_admin(conn,
                       domain,
                       users,
                       as_normal_admin=None,
                       as_global_admin=None):
    '''Mark normal mail user accounts as domain admin.

    domain -- specified users will be admin of this domain.
    users -- iterable object which contains list of email addresses.
    as_normal_admin -- True to enable, False to disable. None for no change.
    as_global_admin -- True to enable, False to disable. None for no change.
    '''
    sql_vars = {'users': users}
    sql_updates = {}

    if as_normal_admin is True:
        sql_updates['isadmin'] = 1
    elif as_normal_admin is False:
        sql_updates['isadmin'] = 0

    if session.get('is_global_admin'):
        if as_global_admin is True:
            sql_updates['isglobaladmin'] = 1
        elif as_global_admin is False:
            sql_updates['isglobaladmin'] = 0

    if not sql_updates:
        return (True, )

    try:
        # update `mailbox.isadmin`, `mailbox.isglobaladmin`.
        conn.update('mailbox',
                    vars=sql_vars,
                    where='username IN $users',
                    **sql_updates)

        if as_normal_admin is True:
            # Add records in `domain_admins` to identify admin privilege.
            for u in users:
                try:
                    conn.insert('domain_admins',
                                username=u,
                                domain=domain)
                except:
                    pass
        elif as_normal_admin is False:
            # Remove admin privilege.
            for u in users:
                try:
                    conn.delete('domain_admins',
                                vars={'username': u, 'domain': domain},
                                where='username=$username AND domain=$domain')
                except:
                    pass

        if as_global_admin is True:
            for u in users:
                try:
                    conn.insert('domain_admins',
                                username=u,
                                domain='ALL')
                except:
                    pass
        elif as_global_admin is False:
            for u in users:
                try:
                    conn.delete('domain_admins',
                                vars={'username': u, 'domain': 'ALL'},
                                where='username=$username AND domain=$domain')
                except:
                    pass

        return (True, )
    except Exception, e:
        return (False, str(e))


def profile(conn, domain, mail):
    mail = str(mail).lower()
    mail_domain = mail.split('@', 1)[-1]

    if mail_domain != domain:
        raise web.seeother('/domains?msg=PERMISSION_DENIED')

    if not mail.endswith('@' + domain):
        raise web.seeother('/domains?msg=PERMISSION_DENIED')

    try:
        qr = conn.query(
            '''
            SELECT
            mailbox.*,
            alias.address AS alias_address,
            alias.goto AS alias_goto,
            alias.active AS alias_active,
            sbcc.username AS sbcc_username,
            sbcc.bcc_address AS sbcc_bcc_address,
            sbcc.active AS sbcc_active,
            rbcc.username AS rbcc_username,
            rbcc.bcc_address AS rbcc_bcc_address,
            rbcc.active AS rbcc_active
            FROM mailbox
            LEFT JOIN alias ON (mailbox.username = alias.address)
            LEFT JOIN sender_bcc_user AS sbcc ON (mailbox.username = sbcc.username)
            LEFT JOIN recipient_bcc_user AS rbcc ON (mailbox.username = rbcc.username)
            WHERE mailbox.username = $username
            LIMIT 1
            ''',
            vars={'username': mail})

        if qr:
            return (True, list(qr)[0])
        else:
            return (False, 'INVALID_MAIL')
    except Exception, e:
        return (False, str(e))


def add_user_from_form(conn, domain, form):
    # Get domain name, username, cn.
    mail_domain = form_utils.get_domain_name(form)
    mail_username = form.get('username')
    if mail_username:
        mail_username = web.safestr(mail_username).strip().lower()
    else:
        return (False, 'INVALID_MAIL')

    mail = mail_username + '@' + mail_domain

    if mail_domain != domain:
        return (False, 'PERMISSION_DENIED')

    if not iredutils.is_email(mail):
        return (False, 'INVALID_MAIL')

    # Check account existing.
    if sql_lib_general.is_email_exists(conn=conn, mail=mail):
        return (False, 'ALREADY_EXISTS')

    # Get domain profile.
    qr_profile = sql_lib_domain.profile(conn=conn, domain=domain)

    if qr_profile[0] is True:
        domain_profile = qr_profile[1]
        domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings'])
    else:
        return qr_profile

    # Check account limit.
    num_exist_accounts = sql_lib_admin.num_managed_users(conn=conn,
                                                         domains=[domain])

    if domain_profile.mailboxes == -1:
        return (False, 'NOT_ALLOWED')
    elif domain_profile.mailboxes > 0:
        if domain_profile.mailboxes <= num_exist_accounts:
            return (False, 'EXCEEDED_DOMAIN_ACCOUNT_LIMIT')

    # Check spare quota and number of spare account limit.
    # Get quota from <form>
    mail_quota = str(form.get('mailQuota')).strip()
    default_user_quota = domain_settings.get('default_user_quota', 0)

    if mail_quota.isdigit():
        mail_quota = int(mail_quota)
    else:
        mail_quota = default_user_quota

    # Re-calculate mail quota if this domain has limited max quota.
    if domain_profile.maxquota > 0:
        # Get used quota.
        allocated_quota = sql_lib_domain.sum_allocated_domain_quota(conn=conn, domain=domain)

        spare_quota = domain_profile.maxquota - allocated_quota

        if spare_quota > 0:
            if spare_quota < mail_quota:
                mail_quota = spare_quota
        else:
            # No enough quota.
            return (False, 'EXCEEDED_DOMAIN_QUOTA_SIZE')

    max_user_quota = domain_settings.get('max_user_quota', 0)
    if max_user_quota > 0:
        if mail_quota > max_user_quota:
            mail_quota = max_user_quota

    #
    # Get password from <form>.
    #
    newpw = web.safestr(form.get('newpw', ''))
    confirmpw = web.safestr(form.get('confirmpw', ''))

    # Get password length limit from domain profile or global setting.
    min_passwd_length = domain_settings.get('min_passwd_length', 0)
    max_passwd_length = domain_settings.get('max_passwd_length', 0)

    if min_passwd_length < settings.min_passwd_length:
        min_passwd_length = settings.min_passwd_length

    if max_passwd_length < settings.max_passwd_length:
        max_passwd_length = settings.max_passwd_length

    qr_pw = iredpwd.verify_new_password(newpw,
                                        confirmpw,
                                        min_passwd_length=min_passwd_length,
                                        max_passwd_length=max_passwd_length)

    if qr_pw[0] is True:
        pwscheme = None
        if 'store_password_in_plain_text' in form and settings.STORE_PASSWORD_IN_PLAIN_TEXT:
            pwscheme = 'PLAIN'
        passwd = iredpwd.generate_password_hash(qr_pw[1], pwscheme=pwscheme)
    else:
        return qr_pw

    # Get display name from <form>
    cn = form.get('cn', '')

    # Get preferred language.
    preferred_language = form_utils.get_language(form)
    if not preferred_language in get_language_maps():
        preferred_language = ''

    # Assign new user to default mail aliases.
    assigned_aliases = [str(v).lower()
                        for v in domain_settings.get('default_groups', [])
                        if iredutils.is_email(v)]

    # Get storage base directory.
    tmpStorageBaseDirectory = settings.storage_base_directory
    splitedSBD = tmpStorageBaseDirectory.rstrip('/').split('/')
    storageNode = splitedSBD.pop()
    storageBaseDirectory = '/'.join(splitedSBD)

    record = {'domain': domain,
              'username': mail,
              'password': passwd,
              'name': cn,
              'maildir': iredutils.generate_maildir_path(mail),
              'quota': mail_quota,
              'storagebasedirectory': storageBaseDirectory,
              'storagenode': storageNode,
              'language': preferred_language,
              'created': iredutils.get_gmttime(),
              'active': 1,
              'local_part': mail_username}

    # Always store plain password in another attribute.
    if settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR:
        record[settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR] = newpw

    try:
        # Store new user in SQL db.
        conn.insert('mailbox', **record)

        # Assign new user to default mail aliases.
        if assigned_aliases:
            for ali in assigned_aliases:
                try:
                    if settings.backend == 'mysql':
                        conn.update('alias',
                                    vars={'address': ali},
                                    goto=web.sqlliteral("CONCAT(%s, ',', goto)" % web.sqlquote(mail)),
                                    where='address=$address')
                    elif settings.backend == 'pgsql':
                        conn.update('alias',
                                    vars={'address': ali},
                                    goto=web.sqlliteral("%s || ',' || goto" % web.sqlquote(mail)),
                                    where='address=$address')
                except:
                    pass

        # Create an alias account: address=goto.
        conn.insert('alias',
                    address=mail,
                    goto=mail,
                    domain=domain,
                    islist=0,
                    created=iredutils.get_gmttime(),
                    active=1)

        # Create bcc
        for (addr, sql_table) in [(domain_settings.get('default_recipient_bcc'), 'recipient_bcc_user'),
                                  (domain_settings.get('default_sender_bcc'), 'sender_bcc_user')]:
            if iredutils.is_email(addr):
                conn.insert(sql_table,
                            username=mail,
                            bcc_address=addr,
                            domain=domain,
                            created=iredutils.get_gmttime(),
                            active=1)

        web.logger(msg="Create user: %s." % (mail),
                   domain=domain,
                   event='create')
        return (True, )
    except Exception, e:
        return (False, str(e))


# Update column `mailbox.settings`.
def update_user_settings(conn,
                         mail,
                         exist_settings={},
                         new_settings={},
                         removed_settings=[]):
    # Get current settings stored in SQL db
    if exist_settings:
        current_settings = exist_settings
    else:
        qr = get_user_settings(conn=conn, mail=mail)
        if qr[0]:
            current_settings = qr[1]
        else:
            current_settings = {}

    if new_settings:
        for (k, v) in new_settings.items():
            current_settings[k] = v

    if removed_settings:
        for k in removed_settings:
            try:
                current_settings.pop(k)
            except:
                pass

    # Convert settings dict to string
    settings_string = sqlutils.account_settings_dict_to_string(current_settings)

    try:
        conn.update('mailbox',
                    vars={'username': mail},
                    where='username=$username',
                    settings=settings_string)
        return (True, )
    except Exception, e:
        return (False, str(e))


def _update_user_forwarding_from_form(conn, mail, form):
    domain = mail.split('@', 1)[-1]

    fwd_addresses = [str(v).lower()
                     for v in form.get('mailForwardingAddresses', '').splitlines()
                     if iredutils.is_email(v)]
    fwd_addresses = list(set(fwd_addresses))

    if mail in fwd_addresses:
        fwd_addresses.remove(mail)

    try:
        conn.delete('alias', vars={'address': mail}, where='address=$address', )
    except Exception, e:
        return (False, str(e))

    members_in_domain = [v for v in fwd_addresses if v.endswith('@' + domain)]
    members_not_in_domain = [v for v in fwd_addresses if not v.endswith('@' + domain)]

    # Verify internal members.
    if members_in_domain:
        qr = conn.select('alias',
                         vars={'address': members_in_domain, 'domain': domain},
                         what='address',
                         where='address IN $address AND domain = $domain')

        members_in_domain = []
        for i in qr:
            members_in_domain += [str(i.address)]

    fwd_addresses = members_in_domain + members_not_in_domain

    inserts = {'address': mail,
               'domain': mail.split('@', 1)[-1],
               'created': iredutils.get_gmttime(),
               'active': 1}

    if fwd_addresses:
        # Get account status
        if 'forwarding' in form:
            inserts['active'] = 1
        else:
            inserts['active'] = 0

        if 'savecopy' in form:
            fwd_addresses += [mail]

        inserts['goto'] = ','.join(fwd_addresses)
    else:
        # Save address=goto to keep catch-all working.
        inserts['goto'] = mail

    try:
        conn.insert('alias', **inserts)
        return (True, )
    except Exception, e:
        return (False, str(e))


def update(conn, mail, profile_type, form):
    profile_type = web.safestr(profile_type)
    mail = str(mail).lower()
    domain = mail.split('@', 1)[-1]

    # change email address
    if profile_type == 'rename':
        # new email address
        new_mail = web.safestr(form.get('new_mail_username')).strip().lower() + '@' + domain

        qr = change_email(conn=conn, mail=mail, new_mail=new_mail)
        if qr[0]:
            raise web.seeother('/profile/user/general/%s?msg=EMAIL_CHANGED' % new_mail)
        else:
            raise web.seeother('/profile/user/general/%s?msg=%s' % (new_mail, web.urlquote(qr[1])))

    # Check disabled user profiles.
    if not session.get('is_global_admin'):
        qr = sql_lib_domain.simple_profile(conn=conn,
                                           domain=domain,
                                           columns=['settings'])
        if qr[0]:
            domain_profile = qr[1]
        del qr

        domain_settings = sqlutils.account_settings_string_to_dict(domain_profile.get('settings', ''))

        disabled_user_profiles = domain_settings.get('disabled_user_profiles', [])
        if profile_type in disabled_user_profiles:
            return (False, 'PERMISSION_DENIED')

    # Pre-defined update key:value pairs
    updates = {'modified': iredutils.get_gmttime()}

    if profile_type == 'general':
        managed_domains = []
        if session.get('is_global_admin') or session.get('allowed_to_grant_admin'):
            # Get settings of domain admin and global admin
            if 'domainadmin' in form:
                # isadmin=1
                updates['isadmin'] = 1
            else:
                updates['isadmin'] = 0

            if 'allowed_to_grant_admin' in form:
                update_user_settings(conn=conn,
                                     mail=mail,
                                     new_settings={'grant_admin': 'yes'})

                web.logger(msg="Grant user %s as domain admin by %s" % (mail, session.get('username')),
                           domain=domain,
                           admin=session.get('username'),
                           username=mail,
                           event='grant')
            else:
                update_user_settings(conn=conn,
                                     mail=mail,
                                     removed_settings=['grant_admin'])

                if mail == session.get('username'):
                    session['allowed_to_grant_admin'] = False

                if 'old_allowed_to_grant_admin' in form:
                    web.logger(msg="Revoke admin %s by %s" % (mail, session.get('username')),
                               domain=domain,
                               admin=session.get('username'),
                               username=mail,
                               event='revoke')

        if session.get('is_global_admin'):
            if 'domainGlobalAdmin' in form:
                updates['isglobaladmin'] = 1
                managed_domains += ['ALL']
            else:
                updates['isglobaladmin'] = 0

        if session.get('is_global_admin') or session.get('allowed_to_grant_admin'):
            # Get managed domains
            managed_domains += form_utils.get_domain_names(form)

            try:
                # Delete records in domain_admins first
                conn.delete('domain_admins',
                            vars={'username': mail},
                            where='username=$username')

                if managed_domains:
                    v = []

                    for d in set(managed_domains):
                        v += [{'username': mail,
                               'domain': d,
                               'created': iredutils.get_gmttime(),
                               'active': 1}]

                    conn.multiple_insert('domain_admins', values=v)
                    del v
                else:
                    # No managed domains, don't mark this user as admin.
                    updates['isadmin'] = 0
            except Exception, e:
                return (False, str(e))

        # Get name
        updates['name'] = form.get('cn', '')

        # Get preferred language: short lang code. e.g. en_US, de_DE.
        preferred_language = form_utils.get_language(form)
        if preferred_language in get_language_maps():
            updates['language'] = preferred_language
        else:
            updates['language'] = ''

        tz_name = web.safestr(form.get('timezone', ''))
        if tz_name in TIMEZONES:
            update_user_settings(conn=conn,
                                 mail=mail,
                                 new_settings={'timezone': tz_name})

            if session['username'] == mail:
                session['timezone'] = TIMEZONES[tz_name]
        else:
            update_user_settings(conn=conn,
                                 mail=mail,
                                 removed_settings=['timezone'])

        # Update language immediately.
        if session.get('username') == mail and \
           session.get('lang', 'en_US') != preferred_language:
            session['lang'] = preferred_language

        # check account status
        updates['active'] = 0
        if 'accountStatus' in form:
            updates['active'] = 1

        # Update account status in table `alias` immediately
        try:
            conn.update('alias',
                        vars={'address': mail},
                        where='address=$address',
                        active=updates['active'],
                        modified=iredutils.get_gmttime())
        except:
            pass

        # Get mail quota size.
        mailQuota = str(form.get('mailQuota'))
        if mailQuota.isdigit():
            mailQuota = int(mailQuota)

            # Verify mail quota, it cannot exceed domain quota.
            qr = sql_lib_domain.simple_profile(conn=conn,
                                               domain=domain,
                                               columns=['maxquota', 'settings'])
            if qr[0] is True:
                domain_quota = int(qr[1].maxquota)
                domain_settings = sqlutils.account_settings_string_to_dict(qr[1]['settings'])
                max_user_quota = domain_settings.get('max_user_quota', 0)
            else:
                return qr

            if domain_quota == 0:
                # Unlimited domain quota
                if max_user_quota:
                    if mailQuota <= max_user_quota:
                        updates['quota'] = mailQuota
                    else:
                        updates['quota'] = max_user_quota
                else:
                    updates['quota'] = mailQuota
            else:
                # Get domain spare quota
                # Get allocated quota size
                domain_allocated_quota = sql_lib_domain.sum_allocated_domain_quota(conn=conn, domain=domain)

                # Get quota of current user
                qr = simple_profile(conn=conn,
                                    mail=mail,
                                    columns=['quota'])

                if qr[0] is True:
                    current_user_quota = int(qr[1].quota)
                else:
                    return qr

                domain_spare_quota = domain_quota - domain_allocated_quota + current_user_quota

                if domain_spare_quota < 0:
                    # Set to 1 MB
                    updates['quota'] = 1
                else:
                    if mailQuota <= domain_spare_quota:
                        if max_user_quota:
                            if mailQuota <= max_user_quota:
                                updates['quota'] = mailQuota
                            else:
                                updates['quota'] = max_user_quota
                        else:
                            updates['quota'] = mailQuota
                    else:
                        if max_user_quota:
                            if domain_spare_quota <= max_user_quota:
                                updates['quota'] = domain_spare_quota
                            else:
                                updates['quota'] = max_user_quota
                        else:
                            updates['quota'] = domain_spare_quota

        # Get employee id.
        updates['employeeid'] = form.get('employeeNumber', '')

        # Get list of assigned alias accounts.
        old_member_of_aliases = [str(v).lower()
                                 for v in form.get('oldMemberOfAlias', [])
                                 if iredutils.is_email(v) and str(v).endswith('@' + domain)]

        # Get list of newly assigned alias accounts.
        member_of_aliases = [str(v).lower()
                             for v in form.get('memberOfAlias', [])
                             if iredutils.is_email(v)
                             and str(v).endswith('@' + domain)]

        newly_assigned_aliases = [str(v).lower()
                                  for v in member_of_aliases
                                  if v not in old_member_of_aliases]
        removed_aliases = [str(v).lower()
                           for v in old_member_of_aliases
                           if v not in member_of_aliases]

        # Remove user from aliases if not in both existing_aliases and new_aliases.
        # Assign user to new aliases.
        if newly_assigned_aliases:
            try:
                if settings.backend == 'mysql':
                    conn.update('alias',
                                vars={'newly_assigned_aliases': newly_assigned_aliases},
                                where='address IN $newly_assigned_aliases',
                                goto=web.sqlliteral("CONCAT('%s', ',', goto)" % mail),
                                modified=iredutils.get_gmttime())
                else:
                    conn.update('alias',
                                vars={'newly_assigned_aliases': newly_assigned_aliases},
                                where='address IN $newly_assigned_aliases',
                                goto=web.sqlliteral("'%s' || ',' || goto" % mail),
                                modified=iredutils.get_gmttime())
            except:
                pass

        # Remove user from old assigned aliases.
        if removed_aliases:
            # Get profiles of alias accounts.
            alias_profiles = conn.select('alias',
                                         vars={'removed_aliases': removed_aliases},
                                         what='address,goto',
                                         where='address IN $removed_aliases')

            for als in alias_profiles:
                try:
                    als_members = [str(v).lower() for v in str(als.goto).replace(' ', '').split(',') if str(v).lower() != mail]

                    # Remove current user from alias accounts.
                    conn.update('alias',
                                vars={'address': als.address},
                                where='address = $address',
                                goto=','.join(als_members),
                                modified=iredutils.get_gmttime())
                except:
                    pass

    elif profile_type == 'forwarding':
        qr = _update_user_forwarding_from_form(conn=conn, mail=mail, form=form)
        if not qr[0]:
            return qr

    elif profile_type == 'bcc':
        # Get bcc status
        rbcc_active = 0
        sbcc_active = 0
        if 'recipientbcc' in form:
            rbcc_active = 1
        if 'senderbcc' in form:
            sbcc_active = 1

        # Get sender/recipient bcc.
        senderBccAddress = str(form.get('senderBccAddress', ''))
        recipientBccAddress = str(form.get('recipientBccAddress', ''))

        # BCC must handle alias domains.
        bcc_alias_domains = [domain]
        # Get all alias domains.
        qr = sql_lib_domain.get_all_alias_domains(conn=conn,
                                                  domain=domain,
                                                  name_only=True)
        if qr[0] is True:
            bcc_alias_domains += qr[1]
        bcc_alias_users = list(set([mail.split('@', 1)[0] + '@' + d for d in bcc_alias_domains]))
        del bcc_alias_domains

        try:
            # Delete bcc records first.
            for u in bcc_alias_users:
                conn.delete('sender_bcc_user',
                            vars={'username': u},
                            where='username=$username')

                conn.delete('recipient_bcc_user',
                            vars={'username': u},
                            where='username=$username')

            # Insert new records.
            for u in bcc_alias_users:
                if iredutils.is_email(senderBccAddress):
                    conn.insert('sender_bcc_user',
                                username=u,
                                bcc_address=senderBccAddress,
                                domain=u.split('@', 1)[-1],
                                created=iredutils.get_gmttime(),
                                modified=iredutils.get_gmttime(),
                                active=sbcc_active)

                if iredutils.is_email(recipientBccAddress):
                    conn.insert('recipient_bcc_user',
                                username=u,
                                bcc_address=recipientBccAddress,
                                domain=u.split('@', 1)[-1],
                                created=iredutils.get_gmttime(),
                                modified=iredutils.get_gmttime(),
                                active=rbcc_active)

        except Exception, e:
            return (False, str(e))

    elif profile_type == 'relay':
        # Get transport.
        transport = str(form.get('mtaTransport', ''))
        updates['transport'] = transport

        # Get sender dependent relayhost
        relayhost = str(form.get('relayhost', ''))

        # Update relayhost
        _qr = sql_lib_general.update_sender_relayhost(conn=conn,
                                                      sender=mail,
                                                      relayhost=relayhost)
        if not _qr[0]:
            return _qr

    elif profile_type == 'aliases':
        if session.get('is_global_admin') or 'aliases' not in disabled_user_profiles:
            user_alias_addresses = form_utils.get_multiple_values(form,
                                                                  input_name='user_alias_addresses',
                                                                  input_is_textarea=True,
                                                                  default_value=[],
                                                                  is_email=True,
                                                                  to_lowercase=True)

            # Remove primary address first.
            if mail in user_alias_addresses:
                user_alias_addresses.remove(mail)

            # Remove all existing per-user aliases first.
            conn.delete('alias',
                        vars={'mail': mail},
                        where='alias_to = $mail AND is_alias = 1')

            if not settings.USER_ALIAS_CROSS_ALL_DOMAINS:
                # Remove emails not under same domain
                user_alias_addresses = [v for v in user_alias_addresses if v.endswith('@' + domain)]
            else:
                # Remove non-local mail domains
                # Get all local mail domains
                ua_domains = set()
                for addr in user_alias_addresses:
                    ua_domains.add(addr.split('@', 1)[-1])

                # Get exist/nonexist mail domains
                qr = sql_lib_general.filter_existing_domains(conn=conn, domains=ua_domains)
                exist_domains = qr['exist']

                # Remove email addresses in non-local mail domains
                user_alias_addresses = [v for v in user_alias_addresses if v.split('@', 1)[-1] in exist_domains]

            # Verify existence
            qr = sql_lib_general.filter_existing_emails(conn=conn, mails=user_alias_addresses)
            nonexist_user_alias_addresses = qr['nonexist']

            # Add all available per-user alias addresses.
            v = []
            for addr in nonexist_user_alias_addresses:
                v += [{'address': addr,
                       'goto': mail,
                       'is_alias': 1,
                       'alias_to': mail,
                       'domain': domain,
                       'created': iredutils.get_gmttime(),
                       'active': 1}]

            if v:
                conn.multiple_insert('alias', values=v)

    elif profile_type == 'throttle':
        if session.get('enable_iredapd'):
            t_account = mail

            inbound_setting = form_utils.get_throttle_setting(form, account=t_account, inout_type='inbound')
            outbound_setting = form_utils.get_throttle_setting(form, account=t_account, inout_type='outbound')

            iredapd_throttle.add_throttle(account=t_account,
                                          setting=inbound_setting,
                                          inout_type='inbound')

            iredapd_throttle.add_throttle(account=t_account,
                                          setting=outbound_setting,
                                          inout_type='outbound')

    elif profile_type == 'wblist':
        if session.get('is_global_admin') or 'wblist' not in disabled_user_profiles:
            if session.get('amavisd_enable_policy_lookup'):
                wl_senders = get_wblist_from_form(form, 'wl_sender')
                bl_senders = get_wblist_from_form(form, 'bl_sender')
                wl_rcpts = get_wblist_from_form(form, 'wl_rcpt')
                bl_rcpts = get_wblist_from_form(form, 'bl_rcpt')

                wblist_lib = wblistlib.WBList()
                qr = wblist_lib.add_wblist(account=mail,
                                           wl_senders=wl_senders,
                                           bl_senders=bl_senders,
                                           wl_rcpts=wl_rcpts,
                                           bl_rcpts=bl_rcpts,
                                           flush_before_import=True)
                return qr

    elif profile_type == 'spampolicy':
        policy_lib = spampolicylib.SpamPolicy()
        qr = policy_lib.update_spam_policy(account=mail, form=form)
        return qr

    elif profile_type == 'password':
        newpw = web.safestr(form.get('newpw', ''))
        confirmpw = web.safestr(form.get('confirmpw', ''))

        # Verify new passwords.
        qr = iredpwd.verify_new_password(newpw, confirmpw)
        if qr[0] is True:
            pwscheme = None
            if 'store_password_in_plain_text' in form and settings.STORE_PASSWORD_IN_PLAIN_TEXT:
                pwscheme = 'PLAIN'
            passwd = iredpwd.generate_password_hash(qr[1], pwscheme=pwscheme)
        else:
            return qr

        # Hash/encrypt new password.
        updates['password'] = passwd
        updates['passwordlastchange'] = iredutils.get_gmttime()

    elif profile_type == 'greylisting':
        if session.get('enable_iredapd'):
            qr = iredapd_greylist.update_greylist_settings_from_form(account=mail, form=form)
            return qr

    elif profile_type == 'advanced':
        # Get enabled/disabled services.
        enabledService = [str(v).lower()
                          for v in form.get('enabledService', [])
                          if v in ENABLED_SERVICES]
        disabledService = []

        # Append 'sieve', 'sievesecured' for dovecot-1.2.
        if 'enablemanagesieve' in enabledService:
            enabledService += ['enablesieve']
        else:
            disabledService += ['enablesieve']

        if 'enablemanagesievesecured' in enabledService:
            enabledService += ['enablesievesecured']
        else:
            disabledService += ['enablesievesecured']

        # Receiving email on server for this user
        if 'enabledeliver' in enabledService:
            enabledService += ['enablelda']
            enabledService += ['enablelmtp']
        else:
            disabledService += ['enablelda']
            disabledService += ['enablelmtp']

        disabledService += [v for v in ENABLED_SERVICES if v not in enabledService]

        # Enable/disable services.
        for srv in enabledService:
            updates[srv] = 1

        for srv in disabledService:
            updates[srv] = 0

        # allow_nets
        _allow_nets = form.get('allow_nets', '').splitlines()
        allow_nets = [str(v) for v in _allow_nets if iredutils.is_ip(v)]
        if allow_nets:
            updates['allow_nets'] = ','.join(allow_nets)
        else:
            updates['allow_nets'] = None

        # Maildir path
        if session.get('is_global_admin') is True:
            # Get maildir related settings.
            storagebasedirectory = str(form.get('storageBaseDirectory', ''))
            storagenode = str(form.get('storageNode', ''))
            maildir = str(form.get('mailMessageStore', ''))

            updates['storagebasedirectory'] = storagebasedirectory
            updates['storagenode'] = storagenode
            updates['maildir'] = maildir

    else:
        return (True, )

    # Update SQL db
    try:
        conn.update('mailbox',
                    vars={'username': mail},
                    where='username=$username',
                    **updates)

        # Update session immediately after updating SQL.
        if profile_type == 'general':
            if not 'domainGlobalAdmin' in form and \
               session.get('username') == mail:
                session['is_global_admin'] = False

        web.logger(msg="Update user profile (%s): %s." % (profile_type, mail),
                   admin=session.get('username'),
                   username=mail,
                   domain=domain,
                   event='update')

        return (True, )
    except Exception, e:
        return (False, str(e))


def update_preferences(conn, mail, form, profile_type='general'):
    mail = str(mail).lower()
    if not session['username'] == mail:
        raise web.seeother('/preferences?msg=PERMISSION_DENIED')

    domain = mail.split('@', 1)[-1]

    # Get domain profile, used to get disabled user preferences
    qr = sql_lib_domain.simple_profile(conn=conn,
                                       domain=domain,
                                       columns=['settings'])
    if qr[0]:
        domain_profile = qr[1]
    else:
        return qr

    domain_settings = sqlutils.account_settings_string_to_dict(domain_profile.get('settings', ''))
    disabled_user_preferences = domain_settings.get('disabled_user_preferences', [])

    if profile_type in disabled_user_preferences:
        raise web.seeother('/preferences?msg=PERMISSION_DENIED')

    # Pre-defined update key:value pairs
    updates = {'modified': iredutils.get_gmttime()}

    if profile_type == 'general':
        if not 'personal_info' in disabled_user_preferences:
            updates['name'] = form.get('cn', '')

        # Get preferred language: short lang code. e.g. en_US, de_DE.
        lang = form_utils.get_language(form)
        updates['language'] = lang

        # Update language immediately.
        if session.get('username') == mail and session.get('lang') != lang:
            session['lang'] = lang

        # Timezone
        tz_name = web.safestr(form.get('timezone', ''))
        if tz_name in TIMEZONES:
            update_user_settings(conn=conn,
                                 mail=mail,
                                 new_settings={'timezone': tz_name})

            if session['username'] == mail:
                session['timezone'] = TIMEZONES[tz_name]

    elif profile_type == 'forwarding':
        qr = _update_user_forwarding_from_form(conn=conn, mail=mail, form=form)
        return qr

    elif profile_type == 'password':
        # Get password length limit from domain profile or global setting.
        min_passwd_length = domain_settings.get('min_passwd_length', 0)
        max_passwd_length = domain_settings.get('max_passwd_length', 0)

        if min_passwd_length < settings.min_passwd_length:
            min_passwd_length = settings.min_passwd_length

        if max_passwd_length < settings.max_passwd_length:
            max_passwd_length = settings.max_passwd_length

        newpw = web.safestr(form.get('newpw', ''))
        confirmpw = web.safestr(form.get('confirmpw', ''))

        # Verify new passwords.
        qr = iredpwd.verify_new_password(newpw=newpw,
                                         confirmpw=confirmpw,
                                         min_passwd_length=min_passwd_length,
                                         max_passwd_length=max_passwd_length)

        if qr[0] is True:
            pwscheme = None
            if 'store_password_in_plain_text' in form and settings.STORE_PASSWORD_IN_PLAIN_TEXT:
                pwscheme = 'PLAIN'
            passwd = iredpwd.generate_password_hash(qr[1], pwscheme=pwscheme)
        else:
            return qr

        updates['password'] = passwd
        updates['passwordlastchange'] = iredutils.get_gmttime()

        # Always store plain password in another attribute.
        if settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR:
            updates[settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR] = newpw

    # Update SQL db
    try:
        conn.update('mailbox',
                    vars={'username': mail},
                    where='username=$username',
                    **updates)

        web.logger(msg="[self-service] Update profile (%s): %s." % (profile_type, mail),
                   admin=mail,
                   username=mail,
                   domain=domain,
                   event='update')

        return (True, )
    except Exception, e:
        return (False, str(e))


def get_bulk_user_forwardings(conn, mails):
    user_forwardings = {}
    try:
        qr = conn.select('alias',
                         vars={'addresses': mails},
                         what='address, goto',
                         where='address IN $addresses AND address <> goto')
        for r in qr:
            user_forwardings[str(r.address)] = str(r.goto).split(',')

        return (True, user_forwardings)
    except Exception, e:
        return (False, str(e))
