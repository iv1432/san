# Author: Zhang Huangbin <zhb@iredmail.org>


def account_settings_dict_to_string(account_settings):
    # Convert account setting dict to string.
    # - dict: {'var': 'value', 'var2: value2', ...}
    # - string: 'var:value;var2:value2;...'
    if not account_settings or not isinstance(account_settings, dict):
        return ''

    for key in account_settings:
        if key in ['default_groups',
                   'enabled_services',
                   'disabled_domain_profiles',
                   'disabled_user_profiles',
                   'disabled_user_preferences']:
            # Remove setting item if value is empty
            account_settings[key] = ','.join(account_settings[key])

    new_settings = ';'.join(['%s:%s' % (str(k), v) for k, v in account_settings.items()])
    if new_settings:
        new_settings += ';'

    return new_settings


def account_settings_string_to_dict(account_settings):
    # Convert account setting (string, format 'var:value;var2:value2;...', used
    # in MySQL/PGSQL backends) to dict.
    #   - domain.settings
    #   - mailbox.settings
    # Original setting must be a string
    if not account_settings:
        return {}

    new_settings = {}

    items = [st for st in account_settings.split(';') if ':' in st]
    for item in items:
        if item:
            key, value = item.split(':')
            new_settings[key] = value

    # Convert value to proper format (int, string, ...), default is string.
    # It will be useful to compare values with converted values.
    # If original value is not stored in proper format, key:value pair will
    # be removed.
    for key in new_settings:
        # integer
        if key in ['default_user_quota',
                   'max_user_quota',
                   'min_passwd_length',
                   'max_passwd_length']:
            try:
                new_settings[key] = int(new_settings[key])
            except:
                new_settings.pop(key)

        # list
        if key in ['enabled_services',
                   'default_groups',
                   'disabled_domain_profiles',
                   'disabled_user_profiles',
                   'disabled_user_preferences']:
            new_settings[key] = [str(v) for v in new_settings[key].split(',') if v]

    return new_settings
