# Author: Zhang Huangbin <zhb@iredmail.org>

from os import getloadavg


def get_server_uptime():
    try:
        # Works on Linux.
        f = open("/proc/uptime")
        contents = f.read().split()
        f.close()
    except:
        return None

    total_seconds = float(contents[0])

    MINUTE = 60
    HOUR = MINUTE * 60
    DAY = HOUR * 24

    # Get the days, hours, minutes.
    days = int(total_seconds / DAY)
    hours = int((total_seconds % DAY) / HOUR)
    minutes = int((total_seconds % HOUR) / MINUTE)

    return (days, hours, minutes)


def get_system_load_average():
    try:
        (a1, a2, a3) = getloadavg()
        a1 = '%.3f' % a1
        a2 = '%.3f' % a2
        a3 = '%.3f' % a3
        return (a1, a2, a3)
    except:
        return (0, 0, 0)


def get_nic_info():
    # Return list of basic info of available network interfaces.
    # Format: [(name, ip_address, netmask), ...]
    # Sample: [('eth0', '192.168.1.1', '255.255.255.0'), ...]
    netif_data = []

    try:
        import netifaces

        ifaces = netifaces.interfaces()

        for iface in ifaces:
            if iface == 'lo':
                continue

            try:
                addr = netifaces.ifaddresses(iface)

                for af in addr:
                    if af in (netifaces.AF_INET, netifaces.AF_INET6):
                        for item in addr[af]:
                            netif_data.append((iface, item['addr'], item['netmask']))
            except:
                pass
    except Exception:
        pass

    return netif_data
