import time


# Custom Jinja2 filters.
def filesizeformat(value, baseMB=False):
    """Convert file size to a human-readable format, e.g. 13 KB, 20 MB, 1 GB."""
    try:
        bytes = float(value)
    except:
        return 0

    if baseMB is True:
        bytes = bytes * 1024 * 1024

    base = 1024

    if bytes == 0:
        return '0'

    ret = '0'
    if bytes < base:
        ret = '%d Bytes' % (bytes)
    elif bytes < base * base:
        ret = '%d KB' % (bytes / base)
    elif bytes < base * base * base:
        ret = '%d MB' % (bytes / (base * base))
    elif bytes < base * base * base * base:
        ret = '%.2f GB' % (bytes / (base * base * base))
    else:
        ret = '%.3f TB' % (bytes / (base * base * base * base))

    return ret


def set_datetime_format(t, hour=True, time_format=None):
    """Format LDAP timestamp and Amavisd msgs.time_iso to YYYY-MM-DD HH:MM:SS.

    >>> set_datetime_format('20100925T113256Z')
    '2010-09-25 11:32:56'

    >>> set_datetime_format('20100925T113256Z', hour=False)
    '2010-09-25'

    >>> set_datetime_format('INVALID_TIME_STAMP')   # Return original string
    'INVALID_TIME_STAMP'
    """
    if t is None:
        return '--'
    else:
        t = str(t)

    if not time_format:
        if not hour:
            time_format = '%Y-%m-%d'
        else:
            time_format = '%Y-%m-%d %H:%M:%S'

    # LDAP timestamp
    if 'T' not in t and t.endswith('Z'):
        try:
            return time.strftime(time_format,
                                 time.strptime(t, '%Y%m%d%H%M%SZ'))
        except:
            pass

    # MySQL TIMESTAMP(): yyyymmddTHHMMSSZ
    if 'T' in t and t.endswith('Z'):
        try:
            return time.strftime(time_format,
                                 time.strptime(t, '%Y%m%dT%H%M%SZ'))
        except:
            pass

    # MySQL NOW(): yyyy-mm-dd HH:MM:SS
    if '-' in t and ' ' in t and ':' in t:
        try:
            return time.strftime(time_format,
                                 time.strptime(t, '%Y-%m-%d %H:%M:%S'))
        except:
            pass

    # PostgreSQL, time with time zone. e.g. 2015-04-27 20:40:30-04:00
    if len(t) == 25:
        t = t[:-6]
        try:
            return time.strftime(time_format,
                                 time.strptime(t, '%Y-%m-%d %H:%M:%S'))
        except:
            pass

    # ISO8601 UTC ascii time. Used in table: amavisd.msgs.
    if len(t) == 14:
        try:
            return time.strftime(time_format, time.strptime(t, '%Y%m%d%H%M%S'))
        except:
            pass

    return t


def cut_string(s, length=40):
    try:
        if len(s) != len(s.encode('utf-8', 'replace')):
            length = length / 2

        if len(s) >= length:
            return s[:length] + '...'
        else:
            return s
    except UnicodeDecodeError:
        return unicode(s, encoding='utf-8', errors='replace')
    except:
        return s


# Return value of percentage.
def convert_to_percentage(current, total):
    try:
        current = int(current)
        total = int(total)
    except:
        return 0

    if current == 0 or total == 0:
        return 0
    else:
        percent = (current * 100) // total
        if percent < 0:
            return 0
        elif percent > 100:
            return 100
        else:
            return percent
