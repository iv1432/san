# Author: Zhang Huangbin <zhb@iredmail.org>

import email
from email.Header import decode_header

# Convert HTML content to plain text with BeautifulSoup
has_bs = True
try:
    from bs4 import BeautifulSoup
except ImportError:
    try:
        from BeautifulSoup import BeautifulSoup
    except:
        has_bs = False


def _decode_headers(msg):
    """Decode message into list of {header: value}."""

    # List of {header: value} pairs.
    headers = []

    # header 'From: name <email>'
    header_from = []

    for (header, value) in msg.items():
        for (text, encoding) in decode_header(value):
            if not encoding:
                encoding = 'utf-8'

            try:
                value = unicode(text, encoding=encoding, errors='replace')
            except:
                continue

            if header == 'From':
                header_from.append(value)
            else:
                headers += [{header: value}]

    if header_from:
        headers = [{'From': ' '.join(header_from)}] + headers

    return headers


def _get_charset_of_message_part(part, default_character_set='utf-8'):
    """Get charset of message part."""

    try:
        if part.get_content_charset():
            return part.get_content_charset()
        elif part.get_charset():
            return part.get_charset()
    except:
        pass

    return default_character_set


def parse_raw_message(msg):
    '''Read RAW message from string. Return tuple of:

    list of multiple mail headers: [[header: value], [header: value], ...]
    list of (multiple) body parts: [part1, part2, ...]
    list of attachment file names: [name1, name2, ...]
    '''

    # Get all mail headers. Sample:
    # [{'From': 'sender@xx.com'}, {'To': 'recipient@xx.net'}]
    headers = []

    # Get decoded content parts of mail body.
    bodies = []

    # Get list of attachment names.
    attachments = []

    msg = email.message_from_string(msg)

    # Get all headers.
    for i in _decode_headers(msg):
        for k in i:
            headers += [(k, i[k])]

    for part in msg.walk():
        # multipart/* are just containers
        if part.get_content_maintype() == 'multipart':
            continue

        # String or None.
        filename = part.get_filename()
        if filename:
            attachments += [filename]
        else:
            try:
                # Plain text, not an attachment.
                text = unicode(
                    part.get_payload(decode=True),
                    encoding=_get_charset_of_message_part(part),
                    errors='replace',
                )

                text = text.strip()

                if has_bs:
                    try:
                        text = BeautifulSoup(text).text
                    except:
                        pass

                splited_words = text.split()
                text = ' '.join(splited_words)
                del splited_words

                if text not in bodies:
                    bodies.append(text)
            except:
                pass

    return (headers, bodies, attachments)
