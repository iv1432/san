# Author: Zhang Huangbin <zhb@iredmail.org>

# --------------------------------------
# WARNING
# --------------------------------------
# Please place all your custom settings in settings.py to override settings
# listed in this file, so that you can simply copy settings.py while upgrading
# iRedAdmin.
# --------------------------------------

# Debug iRedAdmin: True, False.
DEBUG = False

# Session timeout in seconds. Default is 30 minutes (1800 seconds).
SESSION_TIMEOUT = 1800

# if set to False, session will expire when client ip was changed.
SESSION_IGNORE_CHANGE_IP = False

# Mail detail message of '500 internal server error' to webmaster: True, False.
# If set to True, iredadmin will mail detail error to webmaster when
# it catches 'internal server error' via LOCAL mail server to aid
# in debugging production servers.
MAIL_ERROR_TO_WEBMASTER = False

# Skin/theme. iRedAdmin will use CSS files and HTML templates under
#   - statics/{skin}/
#   - templates/{skin}/
SKIN = 'default'

# Set http proxy server address if iRedAdmin cannot access internet
# (iredmail.org) directly.
# Sample:
#   - Without authentication: HTTP_PROXY = 'http://192.168.1.1:3128'
#   - With authentication: HTTP_PROXY = 'http://user:password@192.168.1.1:3128'
HTTP_PROXY = ''

# Local timezone. It must be one of below:
#   GMT-12:00
#   GMT-11:00
#   GMT-10:00
#   GMT-09:30
#   GMT-09:00
#   GMT-08:00
#   GMT-07:00
#   GMT-06:00
#   GMT-05:00
#   GMT-04:30
#   GMT-04:00
#   GMT-03:30
#   GMT-03:00
#   GMT-02:00
#   GMT-01:00
#   GMT
#   GMT+01:00
#   GMT+02:00
#   GMT+03:00
#   GMT+03:30
#   GMT+04:00
#   GMT+04:30
#   GMT+05:00
#   GMT+05:30
#   GMT+05:45
#   GMT+06:00
#   GMT+06:30
#   GMT+07:00
#   GMT+08:00
#   GMT+08:45
#   GMT+09:00
#   GMT+09:30
#   GMT+10:00
#   GMT+10:30
#   GMT+11:00
#   GMT+11:30
#   GMT+12:00
#   GMT+12:45
#   GMT+13:00
#   GMT+14:00
LOCAL_TIMEZONE = 'GMT'

###################################
# RESTful API
#
# Enable RESTful API
ENABLE_RESTFUL_API = False

# Restrict API access to specified clients (IP addresses).
# if not allowed, client will receive error message 'NOT_AUTHORIZED'
RESTRICT_API_ACCESS = False
RESTFUL_API_CLIENTS = []

###################################
# General settings
#
# Show percentage of mailbox quota usage. Used in LDAP backend.
SHOW_USED_QUOTA = True

# Default password scheme, must be a string.
# Passwords of new mail accounts will be crypted by specified scheme.
#
#   - LDAP backends: BCRYPT, SSHA512, SSHA, PLAIN.
#                    Multiple passwords are supported if you separate schemes
#                    with '+'. For example:
#                    'SSHA+MD5', 'CRAM-MD5+SSHA', 'CRAM-MD5+SSHA+MD5'.
#
#   - SQL backends: BCRYPT, SSHA512, SSHA, MD5, PLAIN-MD5 (without salt), PLAIN.
#                   Multiple passwords are NOT supported.
#
# Recommended schemes in specified order:
#
#   BCRYPT -> SSHA512 -> SSHA.
#
# WARNING: MD5, PLAIN-MD5, PLAIN are not recommended.
#
# Important notes:
#
#   - Password length and complexity are probably more important then a strong
#     crypt algorithm.
#
#   - BCRYPT: *) must be supported by your system's libc.
#                You can get available algorithms with command 'doveadm pw -l'
#                ('BLF-CRYPT' is BCRYPT).
#                Unfortunately, most Linux distributions doesn't support it,
#                but FreeBSD and OpenBSD support it.
#
#             *) BCRYPT is slower than SSHA512, SSHA, MD5.
#                But, "Speed is exactly what you don't want in a password hash
#                function."
#
#   - SSHA512: requires Dovecot-2.0 (or later) and Python-2.5 (or later).
#              If you're running Python-2.4, iRedAdmin will generate SSHA hash
#              instead of SSHA512. But if you're running Dovecot-1.x, user
#              authentication will fail.
#
#              OpenLDAP doesn't support user authentication with SSHA512
#              directly, so you must set 'auth_bind = no' in
#              /etc/dovecot/dovecot-ldap.conf to let Dovecot do the password
#              verification instead.
#
# Sample password format:
#
# - BCRYPT: {CRYPT}$2a$05$TKnXV39M3uJ4o.AbY1HbjeAval9bunHbxd0.6Qn782yKoBjTEBXTe
#           NOTE: Use prefix '{CRYPT}' instead of '{BLF-CRYPT}'.
# - SSHA512: {SSHA512}FxgXDhBVYmTqoboW+ibyyzPv/wGG7y4VJtuHWrx+wfqrs/lIH2Qxn2eA0jygXtBhMvRi7GNFmL++6aAZ0kXpcy1fxag=
# - SSHA: {SSHA}bfxqKqOOKODJw/bGqMo54f9Q/iOvQoftOQrqWA==
# - CRAM-MD5: {CRAM-MD5}465076e1c95ac134fc2ba88ad617b6660958f388d60423504ee7c46ce44be8b4
# - MD5: $1$ozdpg0V0$0fb643pVsPtHVPX8mCZYW/
# - PLAIN-MD5: 900150983cd24fb0d6963f7d28e17f72.
# - PLAIN: Plain text.
#
# References:
#
#   - Dovecot password schemes:
#       o Dovecot-1.x: http://wiki.dovecot.org/Authentication/PasswordSchemes
#       o dovecot-2.x: http://wiki2.dovecot.org/Authentication/PasswordSchemes
#
#   - bcrypt:
#       o A Future-Adaptable Password Scheme: http://www.openbsd.org/papers/bcrypt-paper.ps
#       o How to safely store a password. http://codahale.com/how-to-safely-store-a-password/
#
DEFAULT_PASSWORD_SCHEME = 'SSHA'

# List of password schemes which should not prefix scheme name in generated hash.
# Currently, only this setting impacts NTLM only.
# Sample setting:
#
#   HASHES_WITHOUT_PREFIXED_PASSWORD_SCHEME = ['NTLM']
#
# Sample password hashes:
#
#   NTLM without prefix: {NTLM}32ED87BDB5FDC5E9CBA88547376818D4
#   NTLM without prefix:       32ED87BDB5FDC5E9CBA88547376818D4
HASHES_WITHOUT_PREFIXED_PASSWORD_SCHEME = ['NTLM']

# Allow to store password in plain text.
# It will show a HTML checkbox to allow admin to store newly created user
# password or reset password in plain text. If not checked, password
# will be stored as encrypted.
# See DEFAULT_PASSWORD_SCHEME below.
STORE_PASSWORD_IN_PLAIN_TEXT = False

# Always store plain password in additional LDAP attribute of user object, or
# SQL column (in `vmail.mailbox` table).
# Value must be a valid LDAP attribute name of user object, or SQL column name
# in `vmail.mailbox` table.
STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR = ''

#
# Password restrictions
#
# Special characters which can be used in password.
PASSWORD_SPECIAL_CHARACTERS = """#$%&'"*+-,.:;!<=>?@[]/\(){}^_`~"""
# Must contain at least one letter, one uppercase letter, one number, one special character
PASSWORD_HAS_LETTER = True
PASSWORD_HAS_UPPERCASE = True
PASSWORD_HAS_NUMBER = True
PASSWORD_HAS_SPECIAL_CHAR = True

# Print PERMISSION_DENIED related programming info to stdout or web server
# log file. e.g. Apache log file.
LOG_PERMISSION_DENIED = True

# Redirect to "Domains and Accounts" page instead of Dashboard.
REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN = False

# List of IP addresses which global admins are allowed to login from.
# e.g. ['127.0.0.1', '192.168.1.1']
# Valid formats:
#   - Single IP addess: 192.168.1.1
#   - IP range:         192.168.1.1-30
#   - Whole subnet:     192.168.1
GLOBAL_ADMIN_IP_LIST = []

# List all local transports.
LOCAL_TRANSPORTS = ['dovecot', 'lmtp:unix:private/dovecot-lmtp', 'lmtp:inet:127.0.0.1:24']

# Redirect to which page after logged in.
# Available values are: preferences, quarantined, received, wblist, spampolicy.
SELF_SERVICE_DEFAULT_PAGE = 'preferences'

###################################
# Maildir related.
#

# It's RECOMMEND for better performance. Samples:
#   - hashed: domain.ltd/u/s/e/username-2009.09.04.12.05.33/
#   - non-hashed: domain.ltd/username-2009.09.04.12.05.33/
MAILDIR_HASHED = True

# Prepend domain name in path. Samples:
#   - with domain name: domain.ltd/username/
#   - without: username/
MAILDIR_PREPEND_DOMAIN = True

# Append timestamp in path. Samples:
#   - with timestamp: domain.ltd/username-2010.12.20.13.13.33/
#   - without timestamp: domain.ltd/username/
MAILDIR_APPEND_TIMESTAMP = True

#######################################
# OpenLDAP backend related settings.
#
# LDAP connection trace level. Must be an integer.
LDAP_CONN_TRACE_LEVEL = 0

# Additional values (in lower cases) for attribute 'enabledService'.
# Notes:
#
#   - both ADDITIONAL_ENABLED_[XX]_SERVICES, ADDITIONAL_DISABLED_[XX]_SERVICES
#     are manageable in account (user/domain) profile page.
#   - ADDITIONAL_ENABLED_[XX]_SERVICES will be added for newly created account
#     automatically.
#   - ADDITIONAL_DISABLED_[XX]_SERVICES won't be added for newly created
#     account automatically, admin must go to account profile page to enable
#     them for certain accounts.
#
# Additional services for mail domain.
ADDITIONAL_ENABLED_DOMAIN_SERVICES = []
ADDITIONAL_DISABLED_DOMAIN_SERVICES = []

# Additional services for mail user.
ADDITIONAL_ENABLED_USER_SERVICES = []
ADDITIONAL_DISABLED_USER_SERVICES = []

#######################################
# MySQL/PostgreSQL backends related settings.
#
# Allow to assign per-user alias address under different domains.
USER_ALIAS_CROSS_ALL_DOMAINS = False

# Access policies of mail deliver restrictions. Must be in lower cases.
SQL_ALIAS_ACCESS_POLICIES = [
    'public',       # Unrestricted Everyone can send mail to this address.
    'domain',       # Domain users only.
    'subdomain',    # Domain and sub-domain users only.
    'membersonly',  # Members only
    'allowedonly',  # Moderators only
    'membersandmoderatorsonly',  # Members and moderators only
]

###################################
# Amavisd related settings.
#
# If Amavisd is not running on the database server (settings.amavisd_db_host),
# you should specify the amavisd server address here.
AMAVISD_QUARANTINE_HOST = ''

# Remove old SQL records of sent/received mails in Amavisd database.
# NOTE: require cron job with script tools/cleanup_amavisd_db.py.
AMAVISD_REMOVE_MAILLOG_IN_DAYS = 3

# Remove old SQL records of quarantined mails.
# Since quarantined mails may take much disk space, it's better to release
# or remove them as soon as possible.
# NOTE: require cron job with script tools/cleanup_amavisd_db.py.
AMAVISD_REMOVE_QUARANTINED_IN_DAYS = 7

# Prefix text to the subject of spam
AMAVISD_SPAM_SUBJECT_PREFIX = '[SPAM] '

###################################
# iRedAdmin related settings.
#
IREDADMIN_LOG_KEPT_DAYS = 30

###################################
# iRedAPD related settings.
#
# Show how many top senders/recipients on Dashboard page.
NUM_TOP_SENDERS = 10
NUM_TOP_RECIPIENTS = 10

# Count top senders/recipients in last SECONDS (86400 == 1 day)
TIME_LENGTH_OF_TOP_SENDERS = 86400
TIME_LENGTH_OF_TOP_RECIPIENTS = 86400

###################################
# Minor settings. You do not need to change them.
#
# Recipient delimiters. If you have multiple delimiters, please list them all.
RECIPIENT_DELIMITERS = ['+']

# Show how many items in one page.
PAGE_SIZE_LIMIT = 50

# Smallest uid/gid number which can be assigned to new users/groups.
MIN_UID = 3000
MIN_GID = 3000

# The link to support page on iRedAdmin footer.
URL_SUPPORT = 'http://www.iredmail.org/support.html'

# Path to the logo image.
# Please copy your logo image to 'static/' folder, then put the image file name 
# in BRAND_LOGO.  e.g.: 'logo.png' (will load file 'static/logo.png').
BRAND_LOGO = ''

# Product name, short description.
BRAND_NAME = 'iRedAdmin-Pro'
BRAND_DESC = 'iRedMail Admin Panel'

# Path to some commands
CMD_SENDMAIL = '/usr/sbin/sendmail'

# Email account used to send notification emails.
NOTIFICATION_SMTP_SERVER = 'localhost'
NOTIFICATION_SMTP_PORT = 587
NOTIFICATION_SMTP_STARTTLS = True
NOTIFICATION_SMTP_USER = 'no-reply@localhost.local'
NOTIFICATION_SMTP_PASSWORD = ''
NOTIFICATION_SMTP_DEBUG_LEVEL = 0

# Mail subject and sender used in notification emails sent to recipients
# of quarantined emails.
#
# URL of your iRedAdmin-Pro. Sample: 'https://your_server.com/iredadmin/'
NOTIFICATION_URL_SELF_SERVICE = ''
# Subject of notification email. Available placeholders:
#   - %(total)d -- number of quarantined mails in total
NOTIFICATION_QUARANTINE_MAIL_SUBJECT = '[Attention] You have %(total)d emails quarantined and not delivered to mailbox'
# Sender address in mail header `From:`
NOTIFICATION_QUARANTINE_MAIL_SENDER = 'No Reply <%s>' % NOTIFICATION_SMTP_USER
