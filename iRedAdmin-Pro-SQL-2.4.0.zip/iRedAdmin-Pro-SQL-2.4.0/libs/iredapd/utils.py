# Author: Zhang Huangbin <zhb@iredmail.org>

from libs.iredapd import throttle as iredapd_throttle
from libs.iredapd import greylist as iredapd_greylist


def cleanup_removed_accounts(accounts, inout_type='inbound'):
    for account in accounts:
        try:
            # Delete greylisting settings
            if inout_type == 'inbound':
                iredapd_greylist.delete_greylist_setting(account=account)

            # Delete throttle tracking and settings
            iredapd_throttle.delete_throttle_tracking(account=account, inout_type=inout_type)
            iredapd_throttle.delete_throttle_tracking(account=account, inout_type=inout_type)

            iredapd_throttle.delete_throttle_setting(account=account, inout_type=inout_type)
            iredapd_throttle.delete_throttle_setting(account=account, inout_type=inout_type)
        except:
            pass

