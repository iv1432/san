# Author: Zhang Huangbin <zhb@iredmail.org>

from libs import iredutils
from libs.iredapd import iRedAPDWrap


# Simple wrappers
def add_throttle(account, setting, inout_type='inbound'):
    t = Throttle()
    qr = t.add_throttle(account=account, setting=setting, inout_type=inout_type)
    return qr


def get_throttle_setting(account, inout_type='outbound'):
    t = Throttle()
    qr = t.get_throttle_setting(account=account, inout_type=inout_type)
    return qr


def delete_throttle_setting(account, inout_type):
    t = Throttle()
    qr = t.delete_throttle_setting(account=account, inout_type=inout_type)
    return qr


def delete_throttle_tracking(account, inout_type):
    t = Throttle()
    qr = t.delete_throttle_tracking(account=account, inout_type=inout_type)
    return qr


class Throttle(iRedAPDWrap):
    def get_throttle_id(self, account, inout_type):
        tid = None

        # get `throttle.id`
        qr = self.db.select('throttle',
                            vars={'account': account, 'inout_type': inout_type},
                            where='account=$account AND kind=$inout_type',
                            limit=1)
        if qr:
            tid = qr[0].id

        return tid

    def delete_throttle_setting(self, account, inout_type):
        if not iredutils.is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        if not (inout_type in ['inbound', 'outbound']):
            return (False, 'INVALID_INOUT_TYPE')

        if account and inout_type:
            self.db.delete('throttle',
                           vars={'account': account, 'inout_type': inout_type},
                           where='account=$account AND kind=$inout_type')

            return (True, )

        return (True, )

    def delete_throttle_tracking(self, account, inout_type):
        tid = self.get_throttle_id(account, inout_type)

        if tid:
            try:
                self.db.delete('throttle_tracking',
                               vars={'tid': tid},
                               where='tid=$tid')
            except Exception, e:
                return (False, str(e))

        return (True, )

    def get_throttle_setting(self, account, inout_type='outbound'):
        """Get throttle setting.

        account -- a valid throttling account
        inout_type -- inbound, outbound
        """
        setting = {}
        if not iredutils.is_valid_amavisd_address(account):
            return setting

        qr = self.db.select('throttle',
                            vars={'account': account, 'inout_type': inout_type},
                            where='kind=$inout_type AND account=$account',
                            limit=1)

        if qr:
            setting = qr[0]

        return setting

    def add_throttle(self,
                     account,
                     setting,
                     inout_type='inbound'):
        if not setting:
            # Delete tracking and setting
            self.delete_throttle_tracking(account=account, inout_type=inout_type)
            self.delete_throttle_setting(account=account, inout_type=inout_type)
            return (True, )

        # Delete record if
        #   - no period
        #   - account mismatch
        #   - account is '@.' (global setting) but no valid setting (all are empty)
        if (not setting.get('period', 0)) \
           or (account != setting.get('account')) \
           or (account == '@.' \
               and (not setting.get('max_msgs')) \
               and (not setting.get('max_size')) \
               and (not setting.get('max_quota'))):
            # Delete tracking and setting
            #   - (period == 0) means disabled
            self.delete_throttle_tracking(account=account, inout_type=inout_type)
            self.delete_throttle_setting(account=account, inout_type=inout_type)
        else:
            try:
                # Get `throttle.id` if there's a setting.
                tid = self.get_throttle_id(account=account, inout_type=inout_type)

                if tid:
                    # Update existing setting
                    self.db.update('throttle',
                                   vars={'tid': tid},
                                   where='id=$tid',
                                   **setting)
                else:
                    # Add new throttle setting.
                    self.db.insert('throttle', **setting)
            except Exception, e:
                return (False, str(e))

        return (True, )
