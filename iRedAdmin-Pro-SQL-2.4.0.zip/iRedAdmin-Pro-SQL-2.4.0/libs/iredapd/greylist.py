# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from libs import iredutils
from libs.iredapd import iRedAPDWrap


# Simple wrappers
def get_greylist_setting_and_whitelists(account):
    gl = Greylisting()

    # Get greylist setting
    gl_setting = gl.get_greylist_setting(account=account)

    # Get greylist whitelists
    gl_whitelists = gl.get_greylist_whitelists(account=account)

    # Get greylist whitelist domains
    gl_whitelist_domains = gl.get_greylist_whitelist_domains()

    return {'setting': gl_setting,
            'whitelists': gl_whitelists,
            'whitelist_domains': gl_whitelist_domains}


def delete_greylist_setting(account, senders=None):
    gl = Greylisting()

    qr = gl.delete_greylist_setting(account=account, senders=senders)

    return qr


def update_greylist_settings_from_form(account, form):
    gl = Greylisting()

    # Enable/disable greylisting
    if 'greylisting' in form:
        qr = gl.enable_disable_greylist_setting(account=account, enable=True)
    else:
        qr = gl.enable_disable_greylist_setting(account=account, enable=False)

    if not qr[0] is True:
        return qr

    # Update greylisting whitelist domains.
    if account == '@.':
        wl_domains = set()
        lines = form.get('whitelist_domains', '').splitlines()
        for line in lines:
            if iredutils.is_domain(line):
                wl_domains.add(str(line).lower())

        qr = gl.update_greylist_whitelist_domains(domains=wl_domains)
        if not qr[0] is True:
            return qr

    # Update greylisting whitelists.
    whitelists = []

    # Store senders to avoid duplicate
    _senders = set()
    lines = form.get('whitelists', '').splitlines()
    for line in lines:
        # Split sender and comment with '#'
        wl = line.split('#', 1)

        sender = ''
        comment = ''

        if len(wl) == 1:
            sender = str(wl[0]).strip()
            comment = ''
        elif len(wl) == 2:
            sender = str(wl[0]).strip()
            comment = wl[1].strip()

        if sender not in _senders:
            whitelists += [{'account': account, 'sender': sender, 'comment': comment}]
            _senders.add(sender)

    qr = gl.update_greylist_whitelists(account=account, gl_whitelists=whitelists)

    return qr


class Greylisting(iRedAPDWrap):
    def get_greylist_setting(self, account):
        """Return greylisting setting of specified account."""
        gl_setting = {}
        if not iredutils.is_valid_amavisd_address(account):
            return gl_setting

        try:
            qr = self.db.select('greylisting',
                                vars={'account': account},
                                what='id, account, sender, active',
                                where="""account = $account AND sender='@.'""",
                                limit=1)
            if qr:
                gl_setting = qr[0]
        except Exception, e:
            web.log_error(e)

        return gl_setting

    def delete_greylist_setting(self, account, senders=None):
        """Delete greylisting setting of specified account."""
        if not iredutils.is_valid_amavisd_address(account):
            return True

        try:
            if senders:
                self.db.select('greylisting',
                               vars={'account': account, 'senders': senders},
                               where="""account = $account AND sender IN $sender""")
            else:
                self.db.select('greylisting',
                               vars={'account': account},
                               where="""account = $account""")
            return (True, )
        except Exception, e:
            return (False, str(e))

    def enable_disable_greylist_setting(self, account, enable=False):
        """Update (or create) greylisting setting of specified account."""
        account_type = iredutils.is_valid_amavisd_address(account)
        if not account_type:
            return (False, 'INVALID_ACCOUNT')

        active = 0
        if enable:
            active = 1

        gl_setting = {'account': account,
                      'priority': iredutils.IREDAPD_ACCOUNT_PRIORITIES.get(account_type, 0),
                      'sender': '@.',
                      'sender_priority': 0,
                      'active': active}

        try:
            # Delete existing record first.
            self.db.delete('greylisting',
                           vars={'account': account, 'sender': gl_setting['sender']},
                           where='account = $account AND sender = $sender')

            # Create new record
            self.db.insert('greylisting', **gl_setting)
        except Exception, e:
            return (False, str(e))

        return (True, )

    def get_greylist_whitelists(self, account):
        """Return greylisting whitelists of specified account."""
        if not iredutils.is_valid_amavisd_address(account):
            return False

        whitelists = []
        try:
            qr = self.db.select('greylisting_whitelists',
                                vars={'account': account},
                                what='id, sender, comment',
                                where='account = $account',
                                order='sender')
            if qr:
                whitelists = list(qr)
        except Exception, e:
            web.log_error(e)

        return whitelists

    def get_greylist_whitelist_domains(self):
        """Return greylisting whitelist domains of specified account."""
        domains = []
        try:
            qr = self.db.select('greylisting_whitelist_domains',
                                what='domain',
                                order='domain')
            if qr:
                for i in qr:
                    domains.append(str(i.domain).lower())
        except Exception, e:
            web.log_error(e)

        return domains

    def update_greylist_whitelists(self, account, gl_whitelists):
        """Update greylisting whitelists for specified account.

        gl_whitelists - a list of dict which maps to sql column/value pairs. e.g.
                        [{'account': '@.', 'sender': '192.168.1.1', 'comment': ''}, ...]
        """
        if not iredutils.is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        # Delete existing whitelists first
        try:
            self.db.delete('greylisting_whitelists',
                           vars={'account': account},
                           where='account = $account')
        except Exception, e:
            return (False, str(e))

        # Insert new whitelists
        if gl_whitelists:
            try:
                self.db.multiple_insert('greylisting_whitelists', values=gl_whitelists)
            except Exception, e:
                return (False, str(e))

        return (True, 'GL_UPDATED')

    def update_greylist_whitelist_domains(self, domains=None):
        """Update greylisting whitelist domains for specified account.

        domains -- must be a iterable object. e.g. list, tuple."""
        # Delete existing records first
        try:
            self.db.delete('greylisting_whitelist_domains', where='1=1')
        except Exception, e:
            return (False, str(e))

        # Insert new records
        if domains:
            values = []
            for d in domains:
                values += [{'domain': d}]

            try:
                self.db.multiple_insert('greylisting_whitelist_domains', values=values)
            except Exception, e:
                return (False, str(e))

        return (True, 'GL_WLD_UPDATED')
