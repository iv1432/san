# Author: Zhang Huangbin <zhb@iredmail.org>

import os
import sys
import gettext

import web
from jinja2 import Environment, FileSystemLoader

# Directory to be used as the Python egg cache directory.
# Note that the directory specified must exist and be writable by the
# user that the daemon process run as.
os.environ['PYTHON_EGG_CACHE'] = '/tmp/.iredadmin-eggs'
os.environ['LC_ALL'] = 'C'

# Absolute path to this file.
rootdir = os.path.abspath(os.path.dirname(__file__))

import iredutils
import iredpwd
import jinja_filters
import settings
import ireddate

# Set debug mode.
web.config.debug = settings.DEBUG

# Set session parameters.
web.config.session_parameters['cookie_name'] = 'iRedAdmin-Pro-%s' % settings.backend
web.config.session_parameters['cookie_domain'] = None
web.config.session_parameters['ignore_expiry'] = False
web.config.session_parameters['ignore_change_ip'] = settings.SESSION_IGNORE_CHANGE_IP
web.config.session_parameters['timeout'] = settings.SESSION_TIMEOUT

# Initialize session object.
session_dbn = 'mysql'
if settings.backend in ['pgsql']:
    session_dbn = 'postgres'

db_iredadmin = web.database(
    dbn=session_dbn,
    host=settings.iredadmin_db_host,
    port=int(settings.iredadmin_db_port),
    db=settings.iredadmin_db_name,
    user=settings.iredadmin_db_user,
    pw=settings.iredadmin_db_password,
)
db_iredadmin.supports_multiple_insert = True

# Store session data in 'iredadmin.sessions'.
sessionStore = web.session.DBStore(db_iredadmin, 'sessions')

# We will use web.admindb in module 'iredutils' later.
web.admindb = db_iredadmin

# URL handlers.
# Import backend related urls.
urls_backend = []
if settings.backend == 'ldap':
    from controllers.ldap.urls import urls as urls_backend
elif settings.backend in ['mysql', 'pgsql']:
    from controllers.sql.urls import urls as urls_backend

urls = urls_backend

# Import amavisd related urls.
if settings.amavisd_enable_quarantine \
   or settings.amavisd_enable_logging \
   or settings.amavisd_enable_policy_lookup:
    from controllers.amavisd.urls import urls as urls_amavisd
    urls += urls_amavisd

from controllers.iredapd.urls import urls as urls_iredapd
urls += urls_iredapd

from controllers.panel.urls import urls as urls_panel
urls += urls_panel

# Initialize application object.
app = web.application(urls, globals())

session = web.session.Session(
    app,
    sessionStore,
    initializer={
        'webmaster': settings.webmaster,
        'username': None,
        'logged': False,
        # Admin
        'is_global_admin': False,
        'is_normal_admin': False,
        # normal mail user
        'account_is_mail_user': False,
        'failed_times': 0,   # Integer.
        'lang': settings.default_language,

        # Show used quota.
        'show_used_quota': settings.SHOW_USED_QUOTA,

        # Amavisd related features.
        'amavisd_enable_quarantine': settings.amavisd_enable_quarantine,
        'amavisd_enable_logging': settings.amavisd_enable_logging,
        'amavisd_enable_policy_lookup': settings.amavisd_enable_policy_lookup,

        # iRedAPD related features.
        'enable_iredapd': settings.iredapd_enabled,
    }
)

web.config._session = session


# Generate CSRF token and store it in session.
def csrf_token():
    if not 'csrf_token' in session:
        session['csrf_token'] = iredutils.generate_random_strings(32)

    return session['csrf_token']


# Hooks.
def hook_lang():
    web.ctx.lang = web.input(lang=None, _method="GET").lang or session.get('lang', 'en_US')


# Initialize object which used to stored all translations.
all_translations = {'en_US': gettext.NullTranslations()}


# Translations
def ired_gettext(string):
    """Translate a given string to the language of the application."""
    lang = web.ctx.lang

    if lang in all_translations:
        translation = all_translations[lang]
    else:
        try:
            # Store new translation
            translation = gettext.translation(
                'iredadmin',
                rootdir + '/../i18n',
                languages=[lang])
            all_translations[lang] = translation
        except:
            translation = all_translations['en_US']

    return translation.ugettext(string)


# Define template render.
def render_template(template_name, **context):
    jinja_env = Environment(loader=FileSystemLoader(rootdir + '/../templates/' + settings.SKIN))

    jinja_env.globals.update({
        '_': ired_gettext,  # Override _() which provided by Jinja2.
        'ctx': web.ctx,     # Used to get 'homepath'.
        'skin': settings.SKIN,
        'session': web.config._session,
        'backend': settings.backend,
        'csrf_token': csrf_token,
        'page_size_limit': settings.PAGE_SIZE_LIMIT,
        'url_support': settings.URL_SUPPORT,

        # Brand logo, name, description
        'brand_logo': settings.BRAND_LOGO,
        'brand_name': settings.BRAND_NAME,
        'brand_desc': settings.BRAND_DESC,
    })

    jinja_env.filters.update({
        'filesizeformat': jinja_filters.filesizeformat,
        'set_datetime_format': jinja_filters.set_datetime_format,
        'cut_string': jinja_filters.cut_string,
        'convert_to_percentage': jinja_filters.convert_to_percentage,
        'generate_random_password': iredpwd.generate_random_password,
        'utc_to_timezone': ireddate.utc_to_timezone,
    })

    web.header('Content-Type', 'text/html')
    return jinja_env.get_template(template_name).render(context)


class SessionExpired(web.HTTPError):
    def __init__(self, message):
        message = web.seeother('/login?msg=SESSION_EXPIRED')
        web.HTTPError.__init__(self, '303 See Other', {}, data=message)


# Logger. Logging into SQL database.
def log_into_sql(msg,
                 admin='',
                 domain='',
                 username='',
                 event='',
                 loglevel='info'):
    try:
        if not admin:
            admin = session.get('username')

        db_iredadmin.insert(
            'log',
            admin=str(admin),
            domain=str(domain),
            username=str(username),
            loglevel=str(loglevel),
            event=str(event),
            msg=str(msg),
            ip=str(session.ip),
            timestamp=iredutils.get_gmttime(),
        )
    except Exception:
        pass

    return None


# Log error message. default log to sys.stderr.
def log_error(*args):
    for s in args:
        try:
            print >> sys.stderr, web.safestr(s)
        except Exception, e:
            print >> sys.stderr, e


# Load hooks
app.add_processor(web.loadhook(hook_lang))

# Mail 500 error to webmaster.
if settings.MAIL_ERROR_TO_WEBMASTER:
    app.internalerror = web.emailerrors(settings.webmaster, web.webapi._InternalError)

# Store objects in 'web' module.
web.app = app
web.render = render_template
web.logger = log_into_sql
web.log_error = log_error
web.session.SessionExpired = SessionExpired
