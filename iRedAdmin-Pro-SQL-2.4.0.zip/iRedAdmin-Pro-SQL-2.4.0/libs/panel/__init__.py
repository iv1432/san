from os import environ
import urllib2
import socket
from xml.dom.minidom import parseString as parseXMLString
import web

import settings
from libs import __id__

# Events in admin log. Detailed comments of event names are defined in
# templates/default/macros/general.html
LOG_EVENTS = [
    'all',
    'login', 'user_login',
    'active', 'disable',
    'create', 'delete', 'update',
    'grant',        # Grant user as domain admin
    'revoke',       # Revoke admin privilege
    'backup',
    'update_wblist',
    'iredapd',      # iRedAPD rejection.
]


def convert_xml_url_to_dict(url, xml_nodes=None):
    """
    >>> convert_xml_url_to_dict('http://xxx/sample.xml',
                            ['version', 'date', 'url'])
    (True, {'version': '1.3.0',
            'date': '2010-10-01',
            'url': 'http://xxx/release-notes-1.3.0.html'
            })

    >>> convert_xml_url_to_dict('http://xxx/sample.xml',
                            ['version', ...])  # Error while checking.
    (False, 'HTTP Error 404: Not Found')
    """

    xml_data = {}
    try:
        socket.setdefaulttimeout(20)

        http_proxy = settings.HTTP_PROXY or environ.get('http_proxy', '')
        if http_proxy:
            proxy_handler = urllib2.ProxyHandler({'http': http_proxy})
            opener = urllib2.build_opener(proxy_handler)
            urllib2.install_opener(opener)

        dom = parseXMLString(urllib2.urlopen(url).read())

        for n in xml_nodes:
            try:
                xml_data[n] = dom.documentElement.getElementsByTagName(n)[0].childNodes[0].data
            except:
                xml_data[n] = None

        return (True, xml_data)
    except Exception, e:
        return (False, web.safestr(e))


def get_latest_release_info(uri):
    return convert_xml_url_to_dict(uri, ['version', 'date', 'releasenotes'])


def get_license_info():
    if len(__id__) != 32:
        raise web.seeother('/system/log?msg=INVALID_PRODUCT_ID')

    url = 'http://www.iredmail.org/version/check.py/licenseinfo/' + __id__
    return convert_xml_url_to_dict(url, ['product', 'purchased', 'expired',
                                         'contacts', 'status', 'latestversion',
                                         'releasenotes', 'upgradetutorials'])
