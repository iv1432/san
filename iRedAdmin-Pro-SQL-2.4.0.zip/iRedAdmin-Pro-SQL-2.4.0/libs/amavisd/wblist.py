# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from libs.iredutils import is_valid_amavisd_address
from libs.amavisd import core, utils

session = web.config.get('_session')


class WBList(core.AmavisdWrap):
    def get_account_wblist(self,
                           account,
                           whitelist=True,
                           blacklist=True,
                           outbound_whitelist=True,
                           outbound_blacklist=True):
        """Get white/blacklists of specified account."""
        inbound_sql_where = 'users.email=$user AND users.id=wblist.rid AND wblist.sid = mailaddr.id'
        if whitelist and not blacklist:
            inbound_sql_where += ' AND wblist.wb=%s' % web.sqlquote('W')
        if not whitelist and blacklist:
            inbound_sql_where += ' AND wblist.wb=%s' % web.sqlquote('B')

        outbound_sql_where = 'users.email=$user AND users.id=outbound_wblist.sid AND outbound_wblist.rid = mailaddr.id'
        if outbound_whitelist and not outbound_blacklist:
            outbound_sql_where += ' AND outbound_wblist.wb=%s' % web.sqlquote('W')
        if not whitelist and blacklist:
            outbound_sql_where += ' AND outbound_wblist.wb=%s' % web.sqlquote('B')

        wl = []
        bl = []
        outbound_wl = []
        outbound_bl = []

        try:
            qr = self.lookup_db.select(['mailaddr', 'users', 'wblist'],
                                       vars={'user': account},
                                       what='mailaddr.email AS address, wblist.wb AS wb',
                                       where=inbound_sql_where)
            for r in qr:
                if r.wb == 'W':
                    wl.append(r.address)
                else:
                    bl.append(r.address)

            qr = self.lookup_db.select(['mailaddr', 'users', 'outbound_wblist'],
                                       vars={'user': account},
                                       what='mailaddr.email AS address, outbound_wblist.wb AS wb',
                                       where=outbound_sql_where)
            for r in qr:
                if r.wb == 'W':
                    outbound_wl.append(r.address)
                else:
                    outbound_bl.append(r.address)
        except Exception, e:
            return (False, e)

        return (True, {'whitelist': wl,
                       'blacklist': bl,
                       'outbound_whitelist': outbound_wl,
                       'outbound_blacklist': outbound_bl})

    def add_wblist(self,
                   account,
                   wl_senders=(),
                   bl_senders=(),
                   wl_rcpts=(),
                   bl_rcpts=(),
                   flush_before_import=False):
        """Add white/blacklists for specified account.

        wl_senders -- whitelist senders (inbound)
        bl_senders -- blacklist senders (inbound)
        wl_rcpts -- whitelist recipients (outbound)
        bl_rcpts -- blacklist recipients (outbound)
        flush_before_import -- Delete all existing wblist before importing
                               new wblist
        """
        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        # Remove duplicate.
        if wl_senders:
            wl_senders = set([str(s).lower()
                              for s in wl_senders
                              if is_valid_amavisd_address(s)])

        # Whitelist has higher priority, don't include whitelisted sender.
        if bl_senders:
            bl_senders = set([str(s).lower()
                              for s in bl_senders
                              if is_valid_amavisd_address(s)])

        if wl_rcpts:
            wl_rcpts = set([str(s).lower()
                            for s in wl_rcpts
                            if is_valid_amavisd_address(s)])

        if bl_rcpts:
            bl_rcpts = set([str(s).lower()
                            for s in bl_rcpts
                            if is_valid_amavisd_address(s)])

        if flush_before_import:
            if wl_senders:
                bl_senders = set([s for s in bl_senders if s not in wl_senders])

            if wl_rcpts:
                bl_rcpts = set([s for s in bl_rcpts if s not in wl_rcpts])

        sender_addresses = set(wl_senders) | set(bl_senders)
        rcpt_addresses = set(wl_rcpts) | set(bl_rcpts)
        all_addresses = list(sender_addresses | rcpt_addresses)

        # Get current user's id from `amavisd.users`
        qr = utils.get_user_record(conn=self.lookup_db, account=account)

        if qr[0]:
            user_id = qr[1].id
        else:
            return qr

        # Delete old records
        if flush_before_import:
            # user_id = wblist.rid
            self.lookup_db.delete('wblist',
                                  vars={'rid': user_id},
                                  where='rid=$rid')

            # user_id = outbound_wblist.sid
            self.lookup_db.delete('outbound_wblist',
                                  vars={'sid': user_id},
                                  where='sid=$sid')

        if not all_addresses:
            return (True, )

        # Insert all senders into `amavisd.mailaddr`
        utils.create_mailaddr(conn=self.lookup_db, addresses=all_addresses)

        # Get `mailaddr.id` of senders
        sender_records = {}
        if sender_addresses:
            qr = self.lookup_db.select('mailaddr',
                                       vars={'addresses': list(sender_addresses)},
                                       what='id, email',
                                       where='email IN $addresses')
            for r in qr:
                sender_records[str(r.email)] = r.id
            del qr

        # Get `mailaddr.id` of recipients
        rcpt_records = {}
        if rcpt_addresses:
            qr = self.lookup_db.select('mailaddr',
                                       vars={'addresses': list(rcpt_addresses)},
                                       what='id, email',
                                       where='email IN $addresses')
            for r in qr:
                rcpt_records[str(r.email)] = r.id
            del qr

        # Remove existing records of current submitted records then insert new.
        try:
            if sender_records:
                self.lookup_db.delete('wblist',
                                      vars={'rid': user_id, 'sid': sender_records.values()},
                                      where='rid=$rid AND sid IN $sid')

            if rcpt_records:
                self.lookup_db.delete('outbound_wblist',
                                      vars={'sid': user_id, 'rid': rcpt_records.values()},
                                      where='sid=$sid AND rid IN $rid')
        except Exception, e:
            return (False, str(e))

        # Generate dict used to build SQL statements for importing wblist
        values = []
        if sender_addresses:
            for s in wl_senders:
                if sender_records.get(s):
                    values.append({'rid': user_id, 'sid': sender_records[s], 'wb': 'W'})

            for s in bl_senders:
                # Filter out same record in blacklist
                if sender_records.get(s) and s not in wl_senders:
                    values.append({'rid': user_id, 'sid': sender_records[s], 'wb': 'B'})

        rcpt_values = []
        if rcpt_addresses:
            for s in wl_rcpts:
                if rcpt_records.get(s):
                    rcpt_values.append({'sid': user_id, 'rid': rcpt_records[s], 'wb': 'W'})

            for s in bl_rcpts:
                # Filter out same record in blacklist
                if rcpt_records.get(s) and s not in wl_rcpts:
                    rcpt_values.append({'sid': user_id, 'rid': rcpt_records[s], 'wb': 'B'})

        try:
            if values:
                self.lookup_db.multiple_insert('wblist', values)

            if rcpt_values:
                self.lookup_db.multiple_insert('outbound_wblist', rcpt_values)

            # Log
            if values:
                if flush_before_import:
                    web.logger(msg='Update whitelists and/or blacklists for %s.' % account,
                               admin=session['username'],
                               event='update_wblist')
                else:
                    if wl_senders:
                        web.logger(msg='Add whitelists for %s: %s.' % (account, ', '.join(wl_senders)),
                                   admin=session['username'],
                                   event='update_wblist')

                    if bl_senders:
                        web.logger(msg='Add blacklists for %s: %s.' % (account, ', '.join(bl_senders)),
                                   admin=session['username'],
                                   event='update_wblist')

            if rcpt_values:
                if flush_before_import:
                    web.logger(msg='Update outbound whitelists and/or blacklists for %s.' % account,
                               admin=session['username'],
                               event='update_wblist')
                else:
                    if wl_rcpts:
                        web.logger(msg='Add outbound whitelists for %s: %s.' % (account, ', '.join(wl_senders)),
                                   admin=session['username'],
                                   event='update_wblist')

                    if bl_rcpts:
                        web.logger(msg='Add outbound blacklists for %s: %s.' % (account, ', '.join(bl_senders)),
                                   admin=session['username'],
                                   event='update_wblist')

        except Exception, e:
            return (False, str(e))

        return (True, )

    def delete_wblist(self,
                      account,
                      wl_senders=None,
                      bl_senders=None,
                      wl_rcpts=None,
                      bl_rcpts=None):
        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        # Remove duplicate.
        if wl_senders:
            wl_senders = list(set([str(s).lower()
                                   for s in wl_senders
                                   if is_valid_amavisd_address(s)]))

        # Whitelist has higher priority, don't include whitelisted sender.
        if bl_senders:
            bl_senders = list(set([str(s).lower()
                                   for s in bl_senders
                                   if is_valid_amavisd_address(s)]))

        if wl_rcpts:
            wl_rcpts = list(set([str(s).lower()
                                 for s in wl_rcpts
                                 if is_valid_amavisd_address(s)]))

        if bl_rcpts:
            bl_rcpts = list(set([str(s).lower()
                                 for s in bl_rcpts
                                 if is_valid_amavisd_address(s)]))

        # Get account id from `amavisd.users`
        qr = utils.get_user_record(conn=self.lookup_db, account=account)

        if qr[0]:
            user_id = qr[1].id
        else:
            return qr

        # Remove wblist.
        # No need to remove unused senders in `mailaddr` table, because we
        # have daily cron job to delete them (tools/cleanup_amavisd_db.py).
        try:
            # Get `mailaddr.id` for wblist senders
            if wl_senders:
                sids = []
                qr = self.lookup_db.select('mailaddr',
                                           vars={'addresses': wl_senders},
                                           what='id',
                                           where='email IN $addresses')
                for r in qr:
                    sids.append(r.id)

                if sids:
                    self.lookup_db.delete('wblist',
                                          vars={'user_id': user_id, 'sids': sids},
                                          where="rid=$user_id AND sid IN $sids AND wb='W'")

            if bl_senders:
                sids = []
                qr = self.lookup_db.select('mailaddr',
                                           vars={'addresses': bl_senders},
                                           what='id',
                                           where='email IN $addresses')
                for r in qr:
                    sids.append(r.id)

                if sids:
                    self.lookup_db.delete('wblist',
                                          vars={'user_id': user_id, 'sids': sids},
                                          where="rid=$user_id AND sid IN $sids AND wb='B'")

            if wl_rcpts:
                rids = []
                qr = self.lookup_db.select('mailaddr',
                                           vars={'addresses': wl_rcpts},
                                           what='id',
                                           where='email IN $addresses')
                for r in qr:
                    rids.append(r.id)

                if rids:
                    self.lookup_db.delete('outbound_wblist',
                                          vars={'user_id': user_id, 'rids': rids},
                                          where="sid=$user_id AND rid IN $rids AND wb='W'")

            if bl_rcpts:
                rids = []
                qr = self.lookup_db.select('mailaddr',
                                           vars={'addresses': bl_rcpts},
                                           what='id',
                                           where='email IN $addresses')
                for r in qr:
                    rids.append(r.id)

                if rids:
                    self.lookup_db.delete('outbound_wblist',
                                          vars={'user_id': user_id, 'rids': rids},
                                          where="sid=$user_id AND rid IN $rids AND wb='B'")

        except Exception, e:
            return (False, str(e))

        return (True, )

    def delete_all_wblist(self,
                          account,
                          wl_senders=False,
                          bl_senders=False,
                          wl_rcpts=False,
                          bl_rcpts=False):
        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        # Get account id from `amavisd.users`
        qr = utils.get_user_record(conn=self.lookup_db, account=account)

        if qr[0]:
            user_id = qr[1].id
        else:
            return qr

        # Remove ALL wblist.
        # No need to remove unused senders in `mailaddr` table, because we
        # have daily cron job to delete them (tools/cleanup_amavisd_db.py).
        try:
            if wl_senders:
                self.lookup_db.delete('wblist',
                                      vars={'user_id': user_id},
                                      where="rid=$user_id AND wb='W'")

            if bl_senders:
                self.lookup_db.delete('wblist',
                                      vars={'user_id': user_id},
                                      where="rid=$user_id AND wb='B'")

            if wl_rcpts:
                self.lookup_db.delete('outbound_wblist',
                                      vars={'user_id': user_id},
                                      where="sid=$user_id AND wb='W'")

            if bl_rcpts:
                self.lookup_db.delete('outbound_wblist',
                                      vars={'user_id': user_id},
                                      where="sid=$user_id AND wb='B'")

        except Exception, e:
            return (False, str(e))

        return (True, )
