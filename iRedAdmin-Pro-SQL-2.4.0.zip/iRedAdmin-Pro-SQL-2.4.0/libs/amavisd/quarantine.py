# Author: Zhang Huangbin <zhb@iredmail.org>

import socket
import web
import settings
from libs import iredutils
from libs.amavisd import core

session = web.config.get('_session')

# Import backend related modules.
if settings.backend == 'ldap':
    from libs.ldaplib import connUtils, decorators
elif settings.backend in ['mysql', 'pgsql']:
    from libs.sqllib import SQLWrap, decorators
    from libs.sqllib import admin as sql_lib_admin


# If msgs.quar_type != 'Q' (SQL), we can't get mail body.
class Quarantine(core.AmavisdWrap):
    def get_raw_message(self, mail_id=None):
        """Query SQL server and return raw mail message."""

        # TODO Check domain_access
        if mail_id is None:
            return (False, 'INVALID_MAILID')

        mail_id = str(mail_id)

        try:
            records = self.db.select(
                'quarantine',
                what='mail_text',
                where='mail_id = %s' % web.sqlquote(mail_id),
                order='chunk_ind ASC',
            )

            if not records:
                return (False, 'INVALID_MAILID')

            # Combine mail_text as RAW mail message.
            message = ''
            for i in list(records):
                for j in i.mail_text:
                    message += j

            return (True, message)
        except Exception, e:
            return (False, str(e))

    def get_quarantined_mails(self,
                              page=1,
                              accountType='',
                              account='',
                              quarantined_type='',
                              sizelimit=settings.PAGE_SIZE_LIMIT,
                              sort_by_score=False,
                              countOnly=False):
        """Return ([True | False], (total, records))"""

        page = int(page)
        accountType = str(accountType) or None
        account = str(account) or None
        sizelimit = sizelimit

        # Pre-defined values.
        count = 0
        records = []
        sql_append_selection = ''

        # Domain names under control.
        allDomains = []

        # Reversed domain name if need to sql query server with domain names.
        allReversedDomainNames = []

        # Query SQL.
        if session.get('is_normal_admin'):
            # List all managed domains in query if admin is not global admin
            if settings.backend == 'ldap':
                connutils = connUtils.Utils()
                qr = connutils.get_managed_domains(admin=session.get('username'),
                                                   attributes=['domainName'])
                if qr[0] is True:
                    for i in qr[1]:
                        domain = i[1].get('domainName', [''])[0]
                        allDomains += [domain]

            elif settings.backend in ['mysql', 'pgsql']:
                sql_wrap = SQLWrap()
                qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                       admin=session.get('username'),
                                                       domain_name_only=True)

                if qr[0] is True:
                    allDomains += qr[1]

            allReversedDomainNames = iredutils.reverse_amavisd_domain_names(allDomains)

            if allDomains:
                sql_append_selection += ' AND (sender.domain IN %s OR recip.domain IN %s)' % (
                    web.sqlquote(allReversedDomainNames),
                    web.sqlquote(allReversedDomainNames),
                )
            else:
                return (True, (0, {}))

        if accountType == 'domain':
            if account:
                reversed_account = iredutils.reverse_amavisd_domain_names([account])[0]

                if not session.get('is_global_admin'):
                    # Make sure account is managed domain
                    if not account in allDomains:
                        # PERMISSION_DENIED
                        return (True, (0, {}))

                sql_append_selection += ' AND (sender.domain=%s OR recip.domain=%s)' % (
                    web.sqlquote(reversed_account), web.sqlquote(reversed_account),
                )
        elif accountType == 'user':
            if session.get('is_normal_admin'):
                # Make sure account is under managed domains
                if not account.split('@', 1)[-1] in allDomains:
                    # PERMISSION_DENIED
                    return (True, (0, {}))
            elif session.get('account_is_mail_user'):
                if account != session['username']:
                    return (True, (0, {}))

            sql_append_selection += ' AND (sender.email=%s OR recip.email=%s)' % (
                web.sqlquote(account),
                web.sqlquote(account),
            )

        if quarantined_type == 'spam':
            sql_append_selection += " AND msgs.content IN ('S', 's', 'Y')"
        elif quarantined_type == 'virus':
            sql_append_selection += " AND msgs.content = 'V'"
        elif quarantined_type == 'banned':
            sql_append_selection += " AND msgs.content = 'B'"
        elif quarantined_type == 'badheader':
            sql_append_selection += " AND msgs.content = 'H'"

        # Get number of total records. SQL table: amavisd.msgs
        try:
            # Refer to templates/default/macros/amavisd.html for more detail
            # about msgs.content (content type, spam status), msgs.quar_type
            # (quarantine type).
            result = self.db.query(
                """
                -- Get number of quarantined emails
                SELECT COUNT(msgs.mail_id) AS total
                FROM msgs
                LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
                LEFT JOIN maddr AS sender ON msgs.sid = sender.id
                LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE
                    -- msgs.content IN ('S', 's', 'Y', 'V', 'B', 'H')
                    -- AND msgs.quar_type = 'Q'
                    msgs.quar_type = 'Q'
                    %s
                """ % (sql_append_selection))

            count = result[0].total or 0
        except Exception, e:
            pass

        if countOnly is True:
            return (True, (count, {}))

        # Get records of quarantined mails.
        try:
            # msgs.content:
            #   - S: spam(kill)
            #   - s: prior to 2.7.0 the CC_SPAMMY was logged as 's', now 'Y' is used.
            # msgs.quar_type:
            #   - Q: sql
            #   - F: file
            sort_column = 'msgs.time_num'
            if sort_by_score:
                sort_column = 'msgs.spam_level'

            result = self.db.query(
                '''
                -- Get records of quarantined mails.
                SELECT
                    msgs.mail_id, msgs.secret_id, msgs.subject, msgs.time_iso,
                    msgs.content, msgs.size, msgs.spam_level,
                    sender.email AS sender_email,
                    recip.email AS recipient
                FROM msgs
                LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
                LEFT JOIN maddr AS sender ON msgs.sid = sender.id
                LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE
                    -- msgs.content IN ('S', 's', 'Y', 'V', 'B', 'H')
                    -- AND msgs.quar_type = 'Q'
                    msgs.quar_type = 'Q'
                    %s
                ORDER BY %s DESC
                LIMIT %d
                OFFSET %d
                ''' % (sql_append_selection, sort_column, sizelimit, (page - 1) * sizelimit)
            )
            records = iredutils.convert_sql_records_to_unicode(result)
        except:
            pass

        return (True, (count, records))

    def release_quarantined_mails(self, records=None):
        # Release quarantined mails.
        #
        # records = [
        #    {'mail_id': 'xxx',
        #     'secret_id': 'yyy',
        #     'requested_by': session.get('username'),
        #    },
        #    [],
        # ]
        #
        # Refer to amavisd doc 'README.protocol' for more detail:
        #   - Releasing a message from a quarantine

        # Don't waste time if no record is specified.
        if not records:
            return (True, )

        # TODO Check domain_access
        #   - Get managed domains.
        #   - Check whether mail_id in `records` are one of managed domains.
        #   - Get allowed mail_id list.

        # Pre-defined variables.
        releasedMailIDs = []

        # Create socket.
        try:
            quar_server = settings.amavisd_db_host
            quar_port = int(settings.amavisd_quarantine_port)

            if settings.AMAVISD_QUARANTINE_HOST:
                quar_server = settings.AMAVISD_QUARANTINE_HOST

            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((quar_server, quar_port))
        except Exception, e:
            return (False, str(e))

        # Generate commands from dict, used for socket communication.
        # Note: We need to update Amavisd SQL database after mail was released
        #       with success, so do NOT send all release requests in ONE socket
        #       command although it will get better performance (a little).
        for record in records:
            cmd_release = 'request=release\r\n'

            # Skip record without 'mail_id'.
            if not 'mail_id' in record:
                continue

            for k in record:
                if record[k] is not None and record[k] != '':
                    cmd_release += '%s=%s\r\n' % (k, record[k])

            cmd_release += 'quar_type=Q\r\n'
            try:
                s.send(cmd_release + '\r\n')

                # Must wait for Amavisd's response before deleting SQL record,
                # otherwise we may delete sql record BEFORE Amavisd releases
                # quarantined email.
                s.recv(1024)

                releasedMailIDs += [record.get('mail_id', 'NOT-EXIST')]
            except Exception, e:
                return (False, str(e))

        # Close socket.
        try:
            s.close()
        except Exception, e:
            return (False, str(e))

        # Return if no record was released successfully.
        if len(releasedMailIDs) == 0:
            return (True, )

        # Update Amavisd SQL database.
        try:
            #
            #   - Update msgs.content to 'C' (Clean)
            #       UPDATE msgs \
            #       SET msgs.content = 'C' \
            #       WHERE msgs.mail_id IN ('xxx', 'yyy', ..)
            #
            #   - Delete records in 'quarantine':
            #       DELETE FROM quarantine \
            #       WHERE quarantine.partition_tag = msgs.partition_tag \
            #       AND quarantine.mail_id = msgs.mail_id
            #
            self.db.update('msgs',
                           where='mail_id IN ' + web.sqlquote(releasedMailIDs),
                           quar_type='',
                           content='C')

            self.db.delete('quarantine',
                           where='mail_id IN ' + web.sqlquote(releasedMailIDs))

            return (True, )
        except Exception, e:
            return (False, str(e))

    @decorators.require_global_admin
    def delete_all_quarantined(self):
        try:
            self.db.delete('quarantine', where='1=1')
            self.db.delete('msgs', where="""quar_type='Q'""")
            return (True, )
        except Exception, e:
            return (False, str(e))
