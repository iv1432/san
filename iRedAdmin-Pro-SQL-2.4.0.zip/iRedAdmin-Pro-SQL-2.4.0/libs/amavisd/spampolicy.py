# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs.iredutils import is_valid_amavisd_address
from libs.amavisd import core, utils

session = web.config.get('_session')

DEFAULT_SPAM_TAG_LEVEL = 2
DEFAULT_SPAM_TAG2_LEVEL = 6


class SpamPolicy(core.AmavisdWrap):
    def get_spam_policy(self, account):
        account = str(account).lower()

        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        try:
            sql_where = 'users.policy_id=policy.id AND users.email=$account'
            qr = self.lookup_db.select(['policy', 'users'],
                                       vars={'account': account},
                                       what='policy.*, users.id AS users_id',
                                       where=sql_where,
                                       limit=1)
            if qr:
                return (True, qr[0])
            else:
                return (True, {})
        except Exception, e:
            return (False, str(e))

    def get_global_spam_score(self):
        score = DEFAULT_SPAM_TAG2_LEVEL
        (success, policy) = self.get_spam_policy(account='@.')
        if success and policy:
            score = policy.get('spam_tag2_level', DEFAULT_SPAM_TAG2_LEVEL)

        return score

    def delete_spam_policy(self, account):
        account = str(account).lower()

        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        try:
            sql = """DELETE FROM policy WHERE id IN (SELECT policy_id FROM users WHERE email='%s')""" % account
            self.lookup_db.query(sql)
            return (True, )
        except Exception, e:
            return (False, str(e))

    def update_spam_policy(self, account, form):
        account = str(account).lower()

        if not is_valid_amavisd_address(account):
            return (False, 'INVALID_ACCOUNT')

        qr = utils.get_policy_record(conn=self.lookup_db, account=account)
        if qr[0]:
            policy_id = qr[1].id
        else:
            return qr

        # Update spam policy
        updates = {}
        updates['bypass_spam_checks'] = None
        updates['bypass_virus_checks'] = None
        updates['bypass_banned_checks'] = None
        updates['bypass_header_checks'] = None

        if not 'enable_spam_checks' in form:
            updates['bypass_spam_checks'] = 'Y'

        if not 'enable_virus_checks' in form:
            updates['bypass_virus_checks'] = 'Y'

        if not 'enable_banned_checks' in form:
            updates['bypass_banned_checks'] = 'Y'

        if not 'enable_header_checks' in form:
            updates['bypass_header_checks'] = 'Y'

        updates['spam_quarantine_to'] = None
        updates['virus_quarantine_to'] = None
        updates['banned_quarantine_to'] = None
        updates['bad_header_quarantine_to'] = None

        if 'spam_quarantine_to' in form:
            updates['spam_quarantine_to'] = 'spam-quarantine'

        if 'virus_quarantine_to' in form:
            updates['virus_quarantine_to'] = 'virus-quarantine'

        if 'banned_quarantine_to' in form:
            updates['banned_quarantine_to'] = 'banned-quarantine'

        if 'bad_header_quarantine_to' in form:
            updates['bad_header_quarantine_to'] = 'bad-header-quarantine'

        # Modify spam subject
        if 'modify_spam_subject' in form:
            updates['spam_subject_tag2'] = settings.AMAVISD_SPAM_SUBJECT_PREFIX
        else:
            updates['spam_subject_tag2'] = None

        updates['spam_tag_level'] = None
        updates['spam_kill_level'] = None

        if account == '@.' and 'always_insert_x_spam_headers' in form:
            updates['spam_tag_level'] = -100

        spam_tag2_level = form.get('spam_tag2_level', '')
        if spam_tag2_level:
            try:
                updates['spam_tag2_level'] = updates['spam_kill_level'] = float(spam_tag2_level)
            except:
                pass
        else:
            updates['spam_tag2_level'] = None

        updates['message_size_limit'] = None
        msg_size = form.get('message_size_limit', '0')
        if msg_size.isdigit():
            updates['message_size_limit'] = msg_size

        # delete record to keep database clean if no custom settings.
        use_default_setting = False
        if updates['bypass_spam_checks'] == None \
           and updates['bypass_virus_checks'] is None \
           and updates['bypass_banned_checks'] is None \
           and updates['bypass_header_checks'] is None \
           and updates['spam_quarantine_to'] == 'spam-quarantine' \
           and updates['virus_quarantine_to'] == 'spam-quarantine' \
           and updates['banned_quarantine_to'] == 'spam-quarantine' \
           and updates['bad_header_quarantine_to'] == 'spam-quarantine' \
           and updates['spam_tag2_level'] is None \
           and updates['spam_subject_tag2'] is None:
            if session.get('is_global_admin') or session.get('is_normal_admin'):
                if updates['spam_tag_level'] is None and updates['message_size_limit'] is None:
                    use_default_setting = True
            else:
                use_default_setting = True

        if use_default_setting:
            self.delete_spam_policy(account=account)
        else:
            try:
                self.lookup_db.update('policy',
                                      vars={'id': policy_id},
                                      where='id=$id',
                                      **updates)

                qr = utils.link_policy_to_user(conn=self.lookup_db,
                                               account=account,
                                               policy_id=policy_id)
                if not qr[0]:
                    return qr

                # Update `policy.spam_tag3_level` and `policy.spam_subject_tag3`
                # separately, these two columns don't exist in Amavisd-new-2.6.x.
                try:
                    extra_updates = {'spam_tag3_level': updates['spam_tag2_level'],
                                     'spam_subject_tag3': updates['spam_subject_tag2']}

                    self.lookup_db.update('policy',
                                          vars={'id': policy_id},
                                          where='id=$id',
                                          **extra_updates)
                except:
                    pass

            except Exception, e:
                return (False, str(e))

        return (True, )
