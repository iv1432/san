# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils
from libs.amavisd import MAIL_ID_CHARACTERS, core

session = web.config.get('_session')


# Import backend related modules.
if settings.backend == 'ldap':
    from libs.ldaplib import connUtils
elif settings.backend in ['mysql', 'pgsql']:
    from libs.sqllib import SQLWrap, admin as sql_lib_admin


class Log(core.AmavisdWrap):
    def delete_all_records(self, log_type=None, account=None):
        # Delete all records, or delete records older than one week.
        # log_type -- sent, received
        # account -- single email address, domain name, '@.'

        account_is_email = False
        account_is_domain = False
        maddr_ids = []

        if account:
            if iredutils.is_email(account):
                account_is_email = True
            elif iredutils.is_domain(account):
                account_is_domain = True
            else:
                if account == '@.':
                    pass
                else:
                    return (False, 'INVALID_ACCOUNT')

            # get `maddr.id` of this account
            if account_is_email:
                # user
                qr = self.db.select('maddr',
                                    vars={'account': account},
                                    what='id',
                                    where='email=$account',
                                    limit=1)
                if qr:
                    maddr_ids.append(qr[0].id)
            elif account_is_domain:
                # domain
                reversed_domain = iredutils.reverse_amavisd_domain_names([account])[0]
                qr = self.db.select('maddr',
                                    vars={'account': reversed_domain},
                                    what='id',
                                    where='domain=$account')
                if qr:
                    for r in qr:
                        maddr_ids.append(r.id)

            # no `maddr.id`, no mail log.
            if not maddr_ids:
                return (True, )
        else:
            managed_domains = []
            if session.get('is_global_admin') or session.get('is_normal_admin'):
                # Get all managed domains
                if settings.backend == 'ldap':
                    connutils = connUtils.Utils()
                    qr = connutils.get_managed_domains(admin=session.get('username'),
                                                       attributes=['domainName'],
                                                       listedOnly=False,
                                                       domainNameOnly=True)
                    if qr[0]:
                        managed_domains = qr[1]

                elif settings.backend in ['mysql', 'pgsql']:
                    sql_wrap = SQLWrap()
                    qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                           admin=session.get('username'),
                                                           domain_name_only=True)

                    if qr[0]:
                        managed_domains = qr[1]

                managed_domains_reversed = iredutils.reverse_amavisd_domain_names(managed_domains)

            if not managed_domains_reversed:
                return (True, )

        try:
            # Delete records in tables: msgs, msgrcpt.
            if log_type == 'sent':
                if account:
                    # Delete all records sent by single user
                    self.db.delete('msgs',
                                   vars={'maddr_ids': maddr_ids},
                                   where='sid IN $maddr_ids')
                else:
                    # Delete all records sent by domain users
                    self.db.delete('msgs',
                                   vars={'managed_domains_reversed': managed_domains_reversed},
                                   where='sid IN (SELECT id FROM maddr WHERE domain IN $managed_domains_reversed)')

            elif log_type == 'received':
                if account:
                    self.db.delete('msgs',
                                   vars={'maddr_ids': maddr_ids},
                                   where='mail_id IN (SELECT mail_id FROM msgrcpt WHERE rid IN $maddr_ids)')

                    self.db.delete('msgrcpt',
                                   vars={'maddr_ids': maddr_ids},
                                   where='rid IN $maddr_ids')
                else:
                    all_rcpt_ids = []   # maddr.id

                    qr = self.db.select(
                        'maddr',
                        vars={'domains': managed_domains_reversed},
                        what='id',
                        where='domain IN $domains',
                    )
                    for i in qr:
                        all_rcpt_ids.append(i['id'])

                    del qr

                    self.db.delete('msgs',
                                   vars={'ids': all_rcpt_ids},
                                   where='mail_id IN (SELECT mail_id FROM msgrcpt WHERE rid IN $ids)')

                    self.db.delete('msgrcpt',
                                   vars={'ids': all_rcpt_ids},
                                   where='rid IN $ids')
                    del all_rcpt_ids

            return (True, )
        except Exception, e:
            return (False, str(e))

    def delete_records_by_mail_id(self, log_type='sent', mail_ids=None):
        # log_type -- received, sent, quarantined, quarantine
        if not isinstance(mail_ids, list):
            return (False, 'INCORRECT_MAILID')

        # Filter unexpected mail_id strings.
        if not mail_ids:
            return (True, )

        mail_ids = [v for v in mail_ids if len(set(v) - set(MAIL_ID_CHARACTERS)) == 0]

        # Converted into SQL style list.
        mail_ids = web.sqlquote(mail_ids)

        if log_type in ['received', 'sent', 'quarantined', 'quarantine']:
            try:
                # Delete records in tables: msgs, msgrcpt.
                self.db.delete('msgs', where='mail_id IN %s' % mail_ids)
                self.db.delete('msgrcpt', where='mail_id IN %s' % mail_ids)
            except Exception, e:
                return (False, str(e))

        if log_type in ['quarantined', 'quarantine']:
            try:
                self.db.delete('quarantine', where="mail_id IN %s" % (mail_ids))
            except Exception, e:
                return (False, str(e))

        return (True, )

    def count_incoming_mails(self,
                             reversedDomainNames=[],
                             timeLength=None,
                             sqlAppendWhere=''):
        # timeLength is seconds.
        total = 0
        sql_append_where = ''

        if not reversedDomainNames:
            if not session.get('account_is_mail_user'):
                return total

        if sqlAppendWhere:
            sql_append_where = sqlAppendWhere
        else:
            sql_append_where = ' AND recip.domain IN %s' % web.sqlquote(reversedDomainNames)

        if isinstance(timeLength, int):
            if settings.backend in ['ldap', 'mysql']:
                sql_append_where += ' AND msgs.time_num > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL %d SECOND))' % timeLength
            elif settings.backend in ['pgsql']:
                sql_append_where += """ AND msgs.time_iso > CURRENT_TIMESTAMP - INTERVAL '%d seconds'""" % timeLength

        try:
            qr_count = self.db.query(
                '''
                -- Get number of incoming mails.
                SELECT COUNT(msgs.mail_id) AS total
                FROM msgs
                LEFT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                LEFT JOIN maddr AS sender ON (msgs.sid = sender.id)
                LEFT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                WHERE msgs.quar_type <> 'Q' %s
                ''' % (sql_append_where)
            )
            total = qr_count[0].total or 0
        except Exception, e:
            web.log_error(e)

        return total

    def count_outgoing_mails(self,
                             reversedDomainNames=[],
                             timeLength=None,
                             sqlAppendWhere=''):
        # timeLength is seconds.
        total = 0
        sql_append_where = ''

        if not reversedDomainNames:
            return total

        if sqlAppendWhere:
            sql_append_where = sqlAppendWhere
        else:
            sql_append_where += ' AND sender.domain IN %s' % web.sqlquote(reversedDomainNames)

        if isinstance(timeLength, int):
            if settings.backend in ['ldap', 'mysql']:
                sql_append_where += ' AND msgs.time_num > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL %d SECOND))' % timeLength
            elif settings.backend in ['pgsql']:
                sql_append_where += """ AND msgs.time_iso > CURRENT_TIMESTAMP - INTERVAL '%d seconds'""" % timeLength

        try:
            qr_count = self.db.query(
                '''
                -- Get number of outgoing mails.
                SELECT COUNT(msgs.mail_id) AS total
                FROM msgs
                RIGHT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                RIGHT JOIN maddr AS sender ON (msgs.sid = sender.id)
                RIGHT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                WHERE msgs.quar_type <> 'Q' %s
                ''' % (sql_append_where)
            )
            total = qr_count[0].total or 0
        except Exception:
            pass

        return total

    def count_virus_mails(self,
                          reversedDomainNames=[],
                          timeLength=None):
        # timeLength is seconds.
        total = 0
        sql_append_where = ''

        if not reversedDomainNames:
            return total

        if session.get('is_global_admin') is not True:
            sql_append_where += ' AND (sender.domain IN %s OR recip.domain IN %s)' % (
                web.sqlquote(reversedDomainNames),
                web.sqlquote(reversedDomainNames),
            )

        if isinstance(timeLength, int):
            if settings.backend in ['ldap', 'mysql']:
                sql_append_where += ' AND msgs.time_num > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL %d SECOND))' % timeLength
            elif settings.backend in ['pgsql']:
                sql_append_where += """ AND msgs.time_iso > CURRENT_TIMESTAMP - INTERVAL '%d seconds'""" % timeLength

        try:
            qr_count = self.db.query(
                '''
                SELECT COUNT(msgs.mail_id) AS total
                FROM msgs
                RIGHT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                RIGHT JOIN maddr AS sender ON (msgs.sid = sender.id)
                RIGHT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                WHERE msgs.content = 'V' %s
                ''' % (sql_append_where)
            )
            total = qr_count[0].total or 0
        except Exception:
            pass

        return total

    def get_in_out_mails(self,
                         logType='sent',
                         cur_page=1,
                         accountType='',
                         account=''):
        """
        @accountType: 'domain', 'user', None
        @logType: 'sent', 'received', 'all'
        """
        logType = str(logType)
        cur_page = int(cur_page)
        accountType = str(accountType) or None
        account = str(account) or None

        # Reversed domain name if need to sql query server with domain names.
        # Example: demo.iredmail.org -> org.iredmail.demo
        allReversedDomainNames = []

        count = 0          # Number of total mails.
        self.records = {}       # Detail records.
        self.mailids = []       # List of msgs.mail_id
        sql_append_where = ''
        reversed_account = ''

        if accountType == 'domain':
            reversed_account = iredutils.reverse_amavisd_domain_names([account])

        # Get all managed domain names and reversed names.
        all_domains = []
        allReversedDomainNames = []
        quoted_all_reversed_domain_names = []
        sql_restricted_sender_domains = ''
        sql_restricted_recip_domains = ''
        if not session.get('account_is_mail_user'):
            if settings.backend == 'ldap':
                connutils = connUtils.Utils()
                qr_all_domains = connutils.get_managed_domains(admin=session.get('username'),
                                                               attributes=['domainName'])
                if qr_all_domains[0] is True:
                    for i in qr_all_domains[1]:
                        domain = i[1].get('domainName', [''])[0]
                        all_domains += [domain]
            elif settings.backend in ['mysql', 'pgsql']:
                sql_wrap = SQLWrap()
                qr_all_domains = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                                   admin=session.get('username'),
                                                                   domain_name_only=True)
                if qr_all_domains[0] is True:
                    all_domains += qr_all_domains[1]
            else:
                return (True, (count, list(self.records), self.mailids))

            allReversedDomainNames = iredutils.reverse_amavisd_domain_names(all_domains)
            quoted_all_reversed_domain_names = web.sqlquote(allReversedDomainNames)
            sql_restricted_sender_domains = ' AND sender.domain IN %s' % quoted_all_reversed_domain_names
            sql_restricted_recip_domains = ' AND recip.domain IN %s' % quoted_all_reversed_domain_names

        # restrict permission for per-account search
        # @logType == 'sent'
        # - if domain is under control, no restriction
        # - if domain is not under control, restrict recipient domain to managed domains
        # @logType == 'received'
        # - if domain is under control, no restriction
        # - if domain is not under control, restrict sender domain to managed domains
        verify_domain = account
        if accountType == 'user':
            verify_domain = account.split('@', 1)[-1]

        if logType == 'received':
            if accountType == 'domain':
                if session.get('is_global_admin') or verify_domain in all_domains:
                    sql_append_where += ' AND recip.domain IN %s' % web.sqlquote(reversed_account)
                else:
                    sql_append_where += ' %s AND recip.domain IN %s' % (sql_restricted_sender_domains, web.sqlquote(reversed_account))
            elif accountType == 'user':
                if session.get('is_global_admin') or verify_domain in all_domains:
                    sql_append_where += ' AND recip.email=%s' % web.sqlquote(account)
                else:
                    sql_append_where += ' %s AND recip.email=%s' % (sql_restricted_sender_domains, web.sqlquote(account))
            else:
                sql_append_where += ' AND recip.domain IN %s' % quoted_all_reversed_domain_names

        elif logType == 'sent':
            if accountType == 'domain':
                if session.get('is_global_admin') or verify_domain in all_domains:
                    sql_append_where += ' AND sender.domain IN %s' % web.sqlquote(reversed_account)
                else:
                    sql_append_where += ' %s AND sender.domain IN %s' % (sql_restricted_recip_domains, web.sqlquote(reversed_account))
            elif accountType == 'user':
                if session.get('is_global_admin') or verify_domain in all_domains:
                    sql_append_where += ' AND sender.email = %s' % (web.sqlquote(account))
                else:
                    sql_append_where += ' %s AND sender.email = %s' % (sql_restricted_recip_domains, web.sqlquote(account))
            else:
                sql_append_where += ' AND sender.domain IN %s' % quoted_all_reversed_domain_names

        ########################
        # Get detail records.
        #
        try:
            if logType == 'received':
                count = self.count_incoming_mails(allReversedDomainNames, sqlAppendWhere=sql_append_where)

                result = self.db.query(
                    '''
                    -- Get records of received mails.
                    SELECT
                        msgs.mail_id, msgs.subject, msgs.time_iso, msgs.size, msgs.spam_level,
                        sender.email AS sender_email,
                        recip.email AS recipient
                    FROM msgs
                    LEFT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                    LEFT JOIN maddr AS sender ON (msgs.sid = sender.id)
                    LEFT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                    WHERE msgs.quar_type <> 'Q' %s
                    ORDER BY msgs.time_num DESC
                    LIMIT %d
                    OFFSET %d
                    ''' % (sql_append_where,
                           settings.PAGE_SIZE_LIMIT,
                           (cur_page - 1) * settings.PAGE_SIZE_LIMIT)
                )
                self.records = iredutils.convert_sql_records_to_unicode(result)
            elif logType == 'sent':
                count = self.count_outgoing_mails(allReversedDomainNames, sqlAppendWhere=sql_append_where)

                result = self.db.query(
                    '''
                    -- Get records of sent mails.
                    SELECT
                        msgs.mail_id, msgs.subject, msgs.time_iso, msgs.size,
                        sender.email AS sender_email,
                        recip.email AS recipient
                    FROM msgs
                    RIGHT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                    RIGHT JOIN maddr AS sender ON (msgs.sid = sender.id)
                    RIGHT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                    WHERE msgs.quar_type <> 'Q' %s
                    ORDER BY msgs.time_num DESC
                    LIMIT %d
                    OFFSET %d
                    ''' % (sql_append_where,
                           settings.PAGE_SIZE_LIMIT,
                           (cur_page - 1) * settings.PAGE_SIZE_LIMIT)
                )
                self.records = iredutils.convert_sql_records_to_unicode(result)
            else:
                self.records = {}
        except:
            pass

        # Get list of msgs.mail_id.
        for r in self.records:
            self.mailids += [r.mail_id]

        return (True, (count, list(self.records), self.mailids))

    def get_top_users(self, reversedDomainNames=[], logType='sent', timeLength=None, number=10):
        self.records = {}
        sql_append_where = ''

        if not reversedDomainNames or not isinstance(reversedDomainNames, list):
            return []

        if not session.get('is_global_admin'):
            if logType == 'sent':
                sql_append_where += ' AND sender.domain IN %s' % web.sqlquote(reversedDomainNames)

        if isinstance(timeLength, int):
            if settings.backend in ['ldap', 'mysql']:
                sql_append_where += ' AND msgs.time_num > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL %d SECOND))' % timeLength
            elif settings.backend in ['pgsql']:
                sql_append_where += """ AND msgs.time_iso > CURRENT_TIMESTAMP - INTERVAL '%d seconds'""" % timeLength

        if logType == 'sent':
            try:
                result = self.db.query(
                    """
                    -- Get top 10 senders.
                    SELECT
                        COUNT(msgs.mail_id) AS total,
                        sender.email AS mail
                    FROM msgs
                    RIGHT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                    RIGHT JOIN maddr AS sender ON (msgs.sid = sender.id)
                    RIGHT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                    WHERE 1=1 %s
                    GROUP BY mail
                    ORDER BY total DESC
                    LIMIT %d
                    """ % (sql_append_where, number)
                )
                self.records = list(result)
            except Exception:
                pass

        elif logType == 'received':
            try:
                result = self.db.query(
                    """
                    -- Get top 10 recipients
                    SELECT
                        COUNT(msgs.mail_id) AS total,
                        recip.email AS mail
                    FROM msgs
                    RIGHT JOIN msgrcpt ON (msgs.mail_id = msgrcpt.mail_id)
                    RIGHT JOIN maddr AS sender ON (msgs.sid = sender.id)
                    RIGHT JOIN maddr AS recip ON (msgrcpt.rid = recip.id)
                    WHERE recip.domain IN %s %s
                    GROUP BY mail
                    ORDER BY total DESC
                    LIMIT %d
                    """ % (web.sqlquote(reversedDomainNames), sql_append_where, number)
                )
                self.records = list(result)
            except Exception:
                pass

        return list(self.records)
