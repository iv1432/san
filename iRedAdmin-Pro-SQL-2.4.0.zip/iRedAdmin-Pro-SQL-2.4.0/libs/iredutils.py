# Author: Zhang Huangbin <zhb@iredmail.org>

import re
import datetime
import time
import random
import subprocess
import smtplib
import web
import settings
from libs import regxes

# Priority used in SQL table `amavisd.mailaddr` and iRedAPD plugin `throttle`.
# 0 is the lowest priority.
# Reference: http://www.amavis.org/README.lookups.txt
#
# The following order (implemented by sorting on the 'priority' field
# in DESCending order, zero is low priority) is recommended, to follow
# the same specific-to-general principle as in other lookup tables;
#   9 - lookup for user+foo@sub.example.com
#   8 - lookup for user@sub.example.com (only if $recipient_delimiter is '+')
#   7 - lookup for user+foo (only if domain part is local)
#   6 - lookup for user     (only local; only if $recipient_delimiter is '+')
#   5 - lookup for @sub.example.com
#   3 - lookup for @.sub.example.com
#   2 - lookup for @.example.com
#   1 - lookup for @.com
#   0 - lookup for @.       (catchall)
MAILADDR_PRIORITIES = {
    'email': 10,
    'ip': 9,
    'wildcard_ip': 8,
    'wildcard_addr': 7,     # r'user@*'. used in iRedAPD plugin `amavisd_wblist`
                            # as wildcard sender. e.g. 'user@*'
    'domain': 5,
    'subdomain': 3,
    'tld_domain': 2,
    'catchall_ip': 1,       # used in iRedAPD plugin `throttle`
    'catchall': 0,
}

# iRedAPD account priorities.
IREDAPD_ACCOUNT_PRIORITIES = {
    'email': 100,               # e.g. 'user@domain.com'. Highest priority
    'wildcard_addr': 90,        # e.g. `user@*`. used in plugin `amavisd_wblist`
                                # as wildcard sender. e.g. 'user@*`
    'ip': 80,                   # e.g. 173.254.22.21
    'wildcard_ip': 70,          # e.g. 173.254.22.*
    'cidr': 70,                 # e.g. 173.254.22.0/24
    'domain': 60,               # e.g. @domain.com
    'subdomain': 50,            # e.g. @.domain.com
    'top_level_domain': 40,     # e.g. @com, @org
    'catchall': 0,              # '@.'. Lowest priority
}


def is_email(s):
    try:
        s = str(s).strip()
    except UnicodeEncodeError:
        return False

    # Not contain invalid characters and match regular expression
    if not set(s) & set(r'~!#$%^&*()\/ ') \
       and re.compile(r'^' + regxes.email + r'$', re.IGNORECASE).match(s):
        return True

    return False


def is_domain(s):
    s = str(s)
    if len(set(s) & set('~!#$%^&*()+\\/\ ')) > 0 or '.' not in s:
        return False

    comp_domain = re.compile(r'^' + regxes.domain + r'$', re.IGNORECASE)
    if comp_domain.match(s):
        return True
    else:
        return False


def is_tld_domain(s):
    s = str(s)

    comp_domain = re.compile(regxes.top_level_domain, re.IGNORECASE)
    if comp_domain.match(s):
        return True
    else:
        return False


def is_ip(s):
    """Verify if given string is valid IP (v4, v6) address or network."""
    try:
        # Verify whether it's valid IP address or network.
        if '/' in s:
            if regxes.cmp_ipv4_cidr.match(s) or regxes.cmp_ipv6_cidr.match(s):
                return True
        else:
            if regxes.cmp_ipv4.match(s) or regxes.cmp_ipv6.match(s):
                return True

        return False
    except:
        return False


# Valid IP address
def is_ipv4(s):
    if regxes.cmp_ipv4.match(s):
        return True

    return False


def is_ipv6(s):
    if regxes.cmp_ipv6.match(s):
        return True
    return False


def is_strict_ip(s):
    if is_ipv4(s):
        return True
    elif is_ipv6(s):
        return True

    return False


def is_wildcard_ipv4(s):
    if regxes.cmp_wildcard_ipv4.match(s):
        return True

    return False


def is_wildcard_addr(s):
    if re.match(regxes.wildcard_addr, s):
        return True

    return False


def is_valid_account_first_char(s):
    if re.match(regxes.valid_account_first_char, s):
        return True

    return False


def get_gmttime():
    # Convert local time to UTC
    return time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())


def convert_sql_records_to_unicode(qr=[]):
    """Convert SQL record value to avoid incorrect unicode handle in Jinja2.

    >>> db = web.DB(None, {})
    >>> qr = db.query('SELECT * FROM msgs')
    >>> convert_sql_records_to_unicode(qr)

    >>> qr = db.select('msgs')
    >>> convert_sql_records_to_unicode(qr)
    """
    rcds = []
    for record in qr:
        for k in record:
            try:
                record[k] = web.safeunicode(record.get(k))
            except UnicodeDecodeError:
                record[k] = '<<< DECODE FAILED >>>'
        rcds += [record]
    return rcds


def generate_random_strings(length=10):
    """Create a random password of specified length"""
    if length <= 0:
        length = 10
    else:
        length = int(length)

    # Characters used to generate the random password
    chars = '23456789' + \
            'abcdefghjkmnpqrstuvwxyz' + \
            '23456789' + \
            'ABCDEFGHJKLMNPQRSTUVWXYZ' + \
            '23456789'

    return "".join(random.choice(chars) for x in range(length))


def generate_maildir_path(mail,
                          hash_maildir=settings.MAILDIR_HASHED,
                          prepend_domain_name=settings.MAILDIR_PREPEND_DOMAIN,
                          append_timestamp=settings.MAILDIR_APPEND_TIMESTAMP):
    """Generate path of mailbox."""

    mail = web.safestr(mail)
    if not is_email(mail):
        return (False, 'INVALID_EMAIL_ADDRESS')

    # Get user/domain part from mail address.
    username, domain = mail.split('@', 1)

    # Get current timestamp.
    timestamp = ''
    if append_timestamp:
        timestamp = time.strftime('-%Y.%m.%d.%H.%M.%S')

    if hash_maildir:
        if len(username) >= 3:
            chars = [username[0], username[1], username[2]]

        elif len(username) == 2:
            chars = [username[0], username[1], username[1]]
        else:
            chars = [username[0], username[0], username[0]]

        # Replace '.' by '_'
        for (index, char) in enumerate(chars):
            if char == '.':
                chars[index] = '_'

        maildir = "%s/%s/%s/%s%s/" % (chars[0], chars[1], chars[2], username, timestamp)
    else:
        maildir = "%s%s/" % (username, timestamp)

    if prepend_domain_name:
        maildir = domain + '/' + maildir

    return maildir.lower()


def convert_shadowlastchange_to_date(day):
    if not isinstance(day, int):
        return '0000-00-00'

    return (datetime.date(1970, 1, 1) + datetime.timedelta(day)).isoformat()


def reverse_amavisd_domain_names(domains=None):
    """
    Reverse list of domain names to amavisd style.

    >>> reverse_amavisd_domain_names(['example.com', 'sub.example.com'])
    ['com.example', 'com.example.sub']
    """
    if not domains:
        return []

    domains = [str(d).lower() for d in domains if is_domain(d)]

    all_reversed = []
    for d in domains:
        rd = d.split('.')
        rd.reverse()
        all_reversed += ['.'.join(rd)]

    return all_reversed


def convert_html_to_text(html):
    try:
        from BeautifulSoup import BeautifulSoup
        s = BeautifulSoup(html).text
        #s.replace('\n', '<br />')
        return s
    except:
        return html


def is_allowed_ip(client_ip, allowed_ip_list):
    if not allowed_ip_list:
        return True

    current_ips = [client_ip]
    if r'.' in client_ip:
        # IPv4
        current_ips.append(r'.'.join(client_ip.split(r'.')[:3]))

    all_allowed_ips = allowed_ip_list
    for ip in all_allowed_ips:
        (p1, p2, p3, p4) = ip.split('.')
        if '-' in p4:
            (range_start, range_end) = p4.split('-')
            part4 = range(int(range_start), int(range_end)+1)
            for p in part4:
                all_allowed_ips.append('.'.join([p1, p2, p3, p]))

    if not set(current_ips) & set(all_allowed_ips):
        return False

    return True


def self_service_login_redirect(username):
    # Possible redirect pages: preferences, quarantined, received, wblist, spampolicy.
    if settings.SELF_SERVICE_DEFAULT_PAGE == 'preferences':
        raise web.seeother('/preferences')
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'quarantined':
        raise web.seeother('/activities/quarantined/user/' + username)
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'received':
        raise web.seeother('/activities/received/user/' + username)
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'wblist':
        raise web.seeother('/preferences/wblist')
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'spampolicy':
        raise web.seeother('/preferences/spampolicy')
    else:
        raise web.seeother('/preferences')


# Apply custom functions defined in `hooks.py`.
def apply_hook(hook_name, *args, **kwargs):
    try:
        import hooks
        if hook_name in hooks.__dict__:
            ret = hooks.__dict__[hook_name](*args, **kwargs)

            return (True, ret)
        else:
            return (None, 'HOOK_NOT_AVAILABLE')
    except ImportError:
        return (None, 'HOOK_NOT_AVAILABLE')
    except Exception, e:
        return (False, str(e))


def sendmail_with_cmd(from_address, recipients, message_text):
    """Send email with `sendmail` command (defined in CMD_SENDMAIL)."""
    if isinstance(recipients, (list, tuple, set)):
        recipients = ','.join(recipients)

    cmd = [settings.CMD_SENDMAIL, '-f', from_address, recipients]

    try:
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        p.stdin.write(message_text)
        p.stdin.close()
        p.wait()

        return (True, )
    except Exception, e:
        return (False, str(e))


def sendmail(from_address, recipients, message_text):
    """Send email through smtp or with command `sendmail`."""
    server = settings.NOTIFICATION_SMTP_SERVER
    port = settings.NOTIFICATION_SMTP_PORT
    user = settings.NOTIFICATION_SMTP_USER
    password = settings.NOTIFICATION_SMTP_PASSWORD
    starttls = settings.NOTIFICATION_SMTP_STARTTLS
    debug_level = settings.NOTIFICATION_SMTP_DEBUG_LEVEL

    if server and port and user and password:
        # Send email through standard smtp protocol
        try:
            s = smtplib.SMTP(server, port)
            s.set_debuglevel(debug_level)

            if starttls:
                s.ehlo()
                s.starttls()
                s.ehlo()

            s.login(user, password)
            s.sendmail(from_address, recipients, message_text)
            s.quit()
            return (True, )
        except Exception, e:
            return (False, str(e))
    else:
        return sendmail_with_cmd(from_address, recipients, message_text)


def get_iredmail_version():
    v = 'Unknown, check /etc/iredmail-release please.'

    # Read first word splited by space in first line.
    try:
        f = open('/etc/iredmail-release', 'r')
        vline = f.readline().split()
        f.close()

        if vline:
            v = vline[0]
    except:
        pass

    return v


def is_valid_amavisd_address(addr):
    # Valid address format:
    #
    #   - email: single address. e.g. user@domain.ltd
    #   - domain: @domain.ltd
    #   - subdomain: entire domain and all sub-domains. e.g. @.domain.ltd
    #   - tld_domain: top level domain name. e.g. @.com, @.org.
    #   - catchall: catch all address. @.
    #   - ip: IPv4 or IPv6 address. Used in iRedAPD plugin `amavisd_wblist`
    #   - wildcard_addr: address with wildcard. e.g. 'user@*'. used in wblist.
    #   - wildcard_ip: wildcard IP addresses. e.g. 192.168.1.*.
    #
    # WARNING: don't forget to update MAILADDR_PRIORITIES in
    # libs/iredutils.py for newly added address format.
    addr = str(addr)

    if addr.startswith(r'@.'):
        if addr == r'@.':
            return 'catchall'
        else:
            domain = addr.split(r'@.', 1)[-1]

            if is_domain(domain):
                return 'subdomain'
            elif is_tld_domain(domain):
                return 'tld_domain'

    elif addr.startswith(r'@'):
        # entire domain
        domain = addr.split(r'@', 1)[-1]
        if is_domain(domain):
            return 'domain'

    elif is_email(addr):
        # single email address
        return 'email'

    elif is_wildcard_addr(addr):
        return 'wildcard_addr'

    elif is_strict_ip(addr):
        return 'ip'
    elif is_wildcard_ipv4(addr):
        return 'wildcard_ip'

    return False


# Get priority from MAILADDR_PRIORITIES
def get_account_priority(account):
    priority = 0

    addr_type = is_valid_amavisd_address(account)
    if addr_type in MAILADDR_PRIORITIES:
        priority = MAILADDR_PRIORITIES[addr_type]

    return priority


def strip_mail_ext_address(mail, delimiters=None):
    """Remove '+extension' in email address.

    >>> strip_mail_ext_address('user+ext@domain.com')
    'user@domain.com'
    """

    if not delimiters:
        delimiters = settings.RECIPIENT_DELIMITERS

    (_orig_user, _domain) = mail.split('@', 1)
    for delimiter in delimiters:
        if delimiter in _orig_user:
            (_user, _ext) = _orig_user.split(delimiter, 1)
            return _user + '@' + _domain

    return mail


def get_password_policies():
    """Return a dict of password policies."""
    return {'has_letter': settings.PASSWORD_HAS_LETTER,
            'has_uppercase': settings.PASSWORD_HAS_UPPERCASE,
            'has_number': settings.PASSWORD_HAS_NUMBER,
            'has_special_char': settings.PASSWORD_HAS_SPECIAL_CHAR,
            'special_characters': settings.PASSWORD_SPECIAL_CHARACTERS}


def is_allowed_api_client(ip):
    if settings.RESTRICT_API_ACCESS:
        if not (ip in settings.RESTFUL_API_CLIENTS):
            return False

    return True
