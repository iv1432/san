# Author: Zhang Huangbin <zhb@iredmail.org>
# Purpose: Notify local recipients (via email) that they have emails
#          quarantined on server and not delivered to their mailbox.

# Usage:
#
#   - Set a correct URL in iRedAdmin-Pro config file `settings.py`, so that
#     users can manage quarantined email within received notification email:
#
#       # URL of iRedAdmin-Pro, it will be displayed in notification email,
#       # so that users can know where they can manage quarantined mails.
#       # It should be https://[your_server]/iredadmin/
#       NOTIFICATION_IREDADMIN_URL = 'https://[your_server]/iredadmin/'
#
#   - Setup a cron job to run this script every 6 or 12, 24 hours, it's up to
#     you. Sample cron job (every 12 hours):
#
#       1 */12 * * * python /path/to/notify_quarantined_recipients.py >/dev/null
#
#   - Also, it's ok to run this script manually:
#
#       # python notify_quarantined_recipients.py

# Customization
#
#   - This script sends email via /usr/sbin/sendmail command by default, it
#     should work quite well and has better performance. if you still prefer
#     to send notification email via smtp, please set proper smtp server and
#     account info in iRedAdmin-Pro config file `settings.py`:
#
#       NOTIFICATION_SMTP_SERVER = 'localhost'
#       NOTIFICATION_SMTP_PORT = 587
#       NOTIFICATION_SMTP_STARTTLS = True
#       NOTIFICATION_SMTP_USER = ''
#       NOTIFICATION_SMTP_PASSWORD = ''
#
#   - To custom mail subject of notification email, please define below
#     variable in iRedAdmin-Pro config file `settings.py`:
#
#       # Subject of notification email.
#       NOTIFICATION_QUARANTINE_MAIL_SUBJECT = '[Attention] You have emails quarantined and not delivered to mailbox'
#
#   - To custom HTML template file, please create your own file by named
#     `tools/notify_quarantined_recipients.custom.html`. If no custom HTML
#     template file, this script will use default one instead:
#     `tools/notify_quarantined_recipients.html`

# How it works:
#
#   - Mail user login to iRedAdmin-Pro (self-service) and choose to receive
#     notification email when there's email quarantined.
#
#       - OpenLDAP: user will be assigned `enabledService=quar_notify`.
#       - SQL backends: column `mailbox.settings` contains `quar_notify:yes`.
#
#     To send notification to all users (who have email quarantined), please
#     use '--force-all' option.
#
#   - This script queries SQL/LDAP database to see who are willing to receive
#     a notification email.
#
#   - This script checks Amavisd database to get info of quarantined mails
#     for these users.

import os
import sys
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from subprocess import Popen, PIPE
from cgi import escape as cgi_escape
import web

os.environ['LC_ALL'] = 'C'

rootdir = os.path.abspath(os.path.dirname(__file__)) + '/../'
sys.path.insert(0, rootdir)

import settings
from libs import iredutils
from tools import ira_tool_lib

web.config.debug = ira_tool_lib.debug
logger = ira_tool_lib.logger

backend = settings.backend

# Get server hostname (FQDN)
pp = Popen(['hostname', '-f'], stdout=PIPE)
server_hostname = pp.communicate()[0]

# Read template HTML file.
custom_tmpl = os.path.join(rootdir, 'tools', 'notify_quarantined_recipients.custom.html')
default_tmpl = os.path.join(rootdir, 'tools', 'notify_quarantined_recipients.html')

if os.path.isfile(custom_tmpl):
    html_tmpl = custom_tmpl
else:
    html_tmpl = default_tmpl

# Info used in notification email.
mail_subject = settings.NOTIFICATION_QUARANTINE_MAIL_SUBJECT
mail_sender = settings.NOTIFICATION_QUARANTINE_MAIL_SENDER
iredadmin_url = settings.NOTIFICATION_URL_SELF_SERVICE

# Use '--force-all' option to notify all mail users.
force_all = '--force-all' in sys.argv or False

# List of target users' email address.
target_users = []

# Get list of users (email) who asked to receive notification email.
if settings.backend == 'ldap':
    from libs.ldaplib import ldaputils
    conn_ldap = ira_tool_lib.get_db_conn('ldap')

    # Get users who ask to get a notification email under each domain.
    if force_all:
        search_filter = '(&(objectClass=mailUser)(accountStatus=active))'
    else:
        search_filter = '(&(objectClass=mailUser)(accountStatus=active)(enabledService=quar_notify))'

    try:
        qr = conn_ldap.search_s(settings.ldap_basedn,
                                2,     # ldap.SCOPE_SUBTREE,
                                search_filter,
                                ['mail'])
        for (dn, entry) in qr:
            target_users += entry.get('mail')
    except Exception, e:
        err = ldaputils.get_full_exception(e)
        logger.info('<< ERROR >> Error while querying mail users under mail domains (%s): %s', (domain, err))

elif settings.backend in ['mysql', 'pgsql']:
    conn_vmaildb = ira_tool_lib.get_db_conn('vmail')

    # Get all users who asked to receive notification email.
    if force_all:
        sql_where = 'active=1'
    else:
        sql_where = 'settings LIKE %s AND active=1' % web.sqlquote('%' + 'quar_notify:' + '%')

    qr = conn_vmaildb.select('mailbox',
                             what='username',
                             where=sql_where)

    for r in qr:
        target_users.append(r.username)

if not target_users:
    logger.debug('No user asks to receive notification email. Exit.')
    sys.exit()

logger.info('%d users are willing to receive notification email.' % len(target_users))

mail_body_template = open(html_tmpl, 'r').read()

# Notify target users.
conn_amavisd = ira_tool_lib.get_db_conn('amavisd')

# Notify how many users each time
for user in target_users:
    # Get maddr.id of recipient
    qr = conn_amavisd.select('maddr',
                             vars={'rcpt': user},
                             what='id',
                             where='email=$rcpt')
    if qr:
        rid = qr[0].id
    else:
        logger.debug('[SKIP] No log of user: ' + user)
        continue

    # Get info of quarantined mails
    sql_what = 'msgrcpt.rid AS rid,' \
               + 'msgs.mail_id AS mail_id,' \
               + 'msgs.subject AS subject,' \
               + 'msgs.from_addr AS from_addr,' \
               + 'msgs.spam_level AS spam_level,' \
               + 'msgs.time_iso'

    sql_where = """msgrcpt.rid=$rid AND msgs.mail_id=msgrcpt.mail_id AND msgs.quar_type='Q'"""
    qr = conn_amavisd.select(['msgs', 'msgrcpt'],
                             vars={'rid': rid},
                             what=sql_what,
                             where=sql_where,
                             order='msgs.time_iso DESC')

    if not qr:
        logger.debug('[SKIP] No quarantined emails for %s.' % user)
        continue

    #
    # Sending notification email to recipients.
    #
    total = len(qr)
    info_by_date = {}

    for rcd in qr:
        # time format: Apr 4, 2015
        time_iso = str(rcd.time_iso)
        if len(time_iso) == 25:
            # PostgreSQL time with time zone
            time_iso = iredutils.set_datetime_format(time_iso[:-6], time_format='%Y%m%d%H%M%S')

        time_tuple = time.strptime(time_iso, '%Y%m%d%H%M%S')
        mail_date = time.strftime('%b %d, %Y', time_tuple)
        mail_time = time.strftime('%H:%M', time_tuple)

        mail_spam_level = str(rcd.spam_level)

        info = '<tr>' + '\n'

        # Allow user to toggle emails with checkbox
        info += '\t' + '<td class="td_subject">' + cgi_escape(rcd.subject) + '</td>' + '\n'
        info += '\t' + '<td class="td_sender">' + cgi_escape(rcd.from_addr) + '</td>' + '\n'
        info += '\t' + '<td class="td_spam_level">' + cgi_escape(mail_spam_level) + '</td>' + '\n'
        info += '\t' + '<td class="td_date">' + mail_time + '</td>' + '\n'
        info += '</tr>' + '\n\n'

        if not mail_date in info_by_date:
            info_by_date[mail_date] = []

        info_by_date[mail_date].append(info)

        quar_mail_info = '\n'
        for mail_date in sorted(info_by_date.keys(), reverse=True):
            quar_mail_info += '<tr class="tr_date"><td colspan="4">' + mail_date + '</td></tr>' + '\n'
            for r in info_by_date[mail_date]:
                quar_mail_info += r

        #    info_by_date.pop(mail_date)

    msg = MIMEMultipart('alternative')
    msg['Subject'] = mail_subject % {'total': total}
    msg['From'] = mail_sender
    msg['To'] = user

    mail_body = mail_body_template % {'quar_mail_info': quar_mail_info,
                                      'quar_keep_days': settings.AMAVISD_REMOVE_QUARANTINED_IN_DAYS,
                                      'iredadmin_url': iredadmin_url}

    # HTML email must contain text and html part with same content, otherwise
    # it will be considered as not well-formated email.
    body_part_plain = MIMEText(mail_body, 'plain')
    msg.attach(body_part_plain)

    body_part_html = MIMEText(mail_body, 'html')
    msg.attach(body_part_html)

    msg_string = msg.as_string()

    ret = iredutils.sendmail(mail_sender, user, msg_string)
    if ret[0]:
        logger.info('+ %s: %d mails.' % (user, total))
    else:
        logger.info('+ << ERROR >> Error while sending notification email to %s: %s' % (user, ret[1]))
