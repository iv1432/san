# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from libs import iredutils
from controllers.utils import tuple_to_api_render

session = web.config.get('_session')


def require_auth_token(func):
    form = web.input()
    auth_token = form.get('auth_token', None)

    if not auth_token or not (auth_token == session.get('auth_token')):
        def no_auth_token(self, *args, **kw):
            return tuple_to_api_render((False, 'NO_AUTH_TOKEN'))

        return no_auth_token

    def proxyfunc(self, *args, **kw):
        return func(self, *args, **kw)

    return proxyfunc


def require_login(func):
    def proxyfunc(self, *args, **kw):
        if session.get('logged') is True:
            return func(self, *args, **kw)
        else:
            session.kill()
            raise web.seeother('/login?msg=LOGIN_REQUIRED')
    return proxyfunc


def require_admin_login(func):
    def proxyfunc(self, *args, **kw):
        if session.get('logged'):
            if session.get('is_global_admin') or session.get('is_normal_admin'):
                return func(self, *args, **kw)
            else:
                if session.get('account_is_mail_user'):
                    raise web.seeother('/preferences?msg=PERMISSION_DENIED')
                else:
                    raise web.seeother('/domains?msg=PERMISSION_DENIED')
        else:
            session.kill()
            raise web.seeother('/login?msg=LOGIN_REQUIRED')
    return proxyfunc


def require_global_admin(func):
    def proxyfunc(self, *args, **kw):
        if session.get('is_global_admin') is True:
            return func(self, *args, **kw)
        else:
            if session.get('account_is_mail_user'):
                raise web.seeother('/preferences?msg=PERMISSION_DENIED')
            else:
                raise web.seeother('/domains?msg=PERMISSION_DENIED')
    return proxyfunc


def api_require_global_admin(func):
    if not iredutils.is_allowed_api_client(web.ctx.ip):
        return tuple_to_api_render((False, 'PERMISSION_DENIED'))

    def proxyfunc(self, *args, **kw):
        if session.get('is_global_admin') is True:
            return func(self, *args, **kw)
        else:
            return tuple_to_api_render((False, 'PERMISSION_DENIED'))
    return proxyfunc


def require_user_login(func):
    def proxyfunc(self, *args, **kw):
        if session.get('account_is_mail_user'):
            return func(self, *args, **kw)
        else:
            session.kill()
            raise web.seeother('/login?msg=LOGIN_REQUIRED')
    return proxyfunc


def csrf_protected(f):
    def decorated(*args, **kw):
        inp = web.input()
        if not ('csrf_token' in inp and inp.csrf_token == session.pop('csrf_token', None)):
            return web.render('error_csrf.html')
        return f(*args, **kw)
    return decorated


# Used in user self-service
def require_preference_access(preference):
    def proxyfunc1(func):
        def proxyfunc2(self, *args, **kw):
            return func(self, *args, **kw)
        return proxyfunc2

    if session.get('is_global_admin') or session.get('is_normal_admin'):
        return proxyfunc1
    else:
        # session.get('account_is_mail_user')
        if preference in session.get('disabled_user_preferences', []):
            raise web.seeother('/preferences?msg=PERMISSION_DENIED')
        else:
            return proxyfunc1
