# Author: Zhang Huangbin <zhb@iredmail.org>

import sys
import web

if sys.version_info >= (2, 6):
    import json
else:
    import simplejson as json


class redirect(object):
    """Make url ending with or without '/' going to the same class."""
    def GET(self, path):
        raise web.seeother('/' + str(path))


class img(object):
    def GET(self, encoded_img):
        web.header('Content-Type', 'image/jpeg')
        return encoded_img.decode('base64')


class Expired(object):
    def GET(self):
        web.header('Content-Type', 'text/html')
        return '''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <title>License expired</title>
    </head>

    <body>
        <p>Your license of iRedAdmin-Pro expired, please <a href="http://www.iredmail.org/pricing.html" target="_blank">purchase a new license</a> to continue using iRedAdmin-Pro.</p>
    </body>
</html>
'''


def api_error(msg):
    raise web.seeother('/login?msg=LOGIN_REQUIRED')


def _render_json(d):
    web.header('Content-Type', 'application/json')
    return json.dumps(d)


def api_render(d):
    return _render_json(d)


def tuple_to_api_render(data=None):
    if isinstance(data, tuple):
        if data[0] is True:
            return api_render({'success': True})
        else:
            return api_render({'success': False, 'msg': data[1]})
    else:
        return api_render({'success': False, 'msg': 'VARIABLE_NOT_TUPLE'})
