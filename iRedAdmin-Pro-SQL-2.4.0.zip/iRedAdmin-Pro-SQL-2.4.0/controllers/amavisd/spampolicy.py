# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from libs import iredutils
from controllers import decorators
from libs.amavisd import spampolicy as spampolicylib

session = web.config.get('_session')


class SpamPolicy(object):
    def _get_account_and_type(self):
        # account, type:
        #   - @.:               global
        #   - domain.com:       domain
        #   - user@domain.com:  user, user_preference
        current_url = web.ctx.environ['PATH_INFO']
        if current_url == '/system/spampolicy':
            # Global policy
            account = '@.'
            account_type = 'global'
        elif current_url.startswith('/profile/domain'):
            # Per-domain policy
            account = '@' + current_url.split('/')[-1]
            account_type = 'domain'
        elif current_url.startswith('/profile/user'):
            # per-user policy, modifying by admin.
            account = current_url.split('/')[-1]
            account_type = 'user'
        else:
            # per-user preferences
            # web.ctx.PATH_INFO == '/preferences/spampolicy'
            account = session['username']
            account_type = 'user_preference'

        #return {'account': account, 'account_type': account_type}
        return (account, account_type, current_url)

    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    def GET(self, account=None):
        (account, account_type, current_url) = self._get_account_and_type()

        policy_lib = spampolicylib.SpamPolicy()
        (success, policy) = policy_lib.get_spam_policy(account=account)
        if not success:
            if account_type == 'user_preference':
                raise web.seeother('/preferences?msg=%s' % web.urlquote(policy))
            else:
                raise web.seeother('/domains?msg=%s' % web.urlquote(policy))

        global_spam_score = policy_lib.get_global_spam_score()

        return web.render('amavisd/spampolicy.html',
                          account_type=account_type,
                          spampolicy=policy,
                          global_spam_score=global_spam_score,
                          current_url=current_url,
                          msg=web.input().get('msg'))

    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    def POST(self, account=None):
        if account:
            if iredutils.is_domain(account):
                policy_account = '@' + account
                current_url = '/profile/domain/spampolicy/' + account
            elif iredutils.is_email(account):
                policy_account = str(account)
                current_url = '/profile/user/spampolicy/' + policy_account
        else:
            (policy_account, account_type, current_url) = self._get_account_and_type()

        form = web.input()

        policy_lib = spampolicylib.SpamPolicy()
        qr = policy_lib.update_spam_policy(account=policy_account, form=form)
        if qr[0]:
            raise web.seeother(current_url + '?msg=UPDATED')
        else:
            raise web.seeother(current_url + '?msg=%s' % web.urlquote(qr[1]))
