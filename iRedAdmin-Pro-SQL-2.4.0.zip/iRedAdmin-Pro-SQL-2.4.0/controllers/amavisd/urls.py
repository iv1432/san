# Author: Zhang Huangbin <zhb@iredmail.org>

from libs.regxes import email as regx_email, domain as regx_domain

urls = [
    # Search activity logs.
    '/activities/search',                   'controllers.amavisd.log.SearchLog',

    # View log of sent/received mails
    '/activities/(received|sent)',               'controllers.amavisd.log.InOutMails',
    '/activities/(received|sent)/page/(\d+)',    'controllers.amavisd.log.InOutMails',

    # Per-user activities
    '/activities/(received|sent)/(user)/(%s)' % regx_email, 'controllers.amavisd.log.InOutMailsPerAccount',
    '/activities/(received|sent)/(user)/(%s)/page/(\d+)' % regx_email, 'controllers.amavisd.log.InOutMailsPerAccount',
    # Per-domain activities
    '/activities/(received|sent)/(domain)/(%s)' % regx_domain, 'controllers.amavisd.log.InOutMailsPerAccount',
    '/activities/(received|sent)/(domain)/(%s)/page/(\d+)' % regx_domain, 'controllers.amavisd.log.InOutMailsPerAccount',

    # Quarantined mails
    '/activities/quarantined',              'controllers.amavisd.log.QuarantinedMails',
    '/activities/quarantined/page/(\d+)',   'controllers.amavisd.log.QuarantinedMails',
    '/activities/quarantined/(spam|virus|banned|badheader|clean)', 'controllers.amavisd.log.QuarantinedMails',
    '/activities/quarantined/(spam|virus|banned|badheader|clean)/page/(\d+)', 'controllers.amavisd.log.QuarantinedMails',
    # Per-user quarantined mails
    '/activities/quarantined/(user)/(%s)' % regx_email, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(user)/(%s)/page/(\d+)' % regx_email, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(user)/(%s)/(spam|virus|banned|badheader|clean)' % regx_email, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(user)/(%s)/(spam|virus|banned|badheader|clean)/page/(\d+)' % regx_email, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    # Per-domain quarantined mails
    '/activities/quarantined/(domain)/(%s)' % regx_domain, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(domain)/(%s)/page/(\d+)' % regx_domain, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(domain)/(%s)/(spam|virus|banned|badheader|clean)' % regx_domain, 'controllers.amavisd.log.QuarantinedMailsPerAccount',
    '/activities/quarantined/(domain)/(%s)/(spam|virus|banned|badheader|clean)/page/(\d+)' % regx_domain, 'controllers.amavisd.log.QuarantinedMailsPerAccount',

    # Get RAW message of quarantined mail by mail_id.
    '/activities/quarantined/raw/(.*)',     'controllers.amavisd.log.GetRawMessageOfQuarantinedMail',

    # Spam policies.
    # Global spam policy (recipient = '@.')
    '/system/spampolicy', 'controllers.amavisd.spampolicy.SpamPolicy',
    # per-domain spam policy (recipient = '@domain.com')
    '/system/spampolicy/(%s)' % regx_domain, 'controllers.amavisd.spampolicy.SpamPolicy',
    # per-user spam policy (recipient = '@domain.com')
    '/system/spampolicy/(%s)' % regx_email, 'controllers.amavisd.spampolicy.SpamPolicy',

    # global wblist
    '/create/wblist', 'controllers.amavisd.wblist.Create',
    '/system/wblist', 'controllers.amavisd.wblist.GlobalWBList',

    # Per-user preferences: wblist, spam control
    '/preferences/wblist', 'controllers.amavisd.wblist.UserWBList',
    '/preferences/spampolicy', 'controllers.amavisd.spampolicy.SpamPolicy',
]
