# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from controllers import decorators
from libs import iredutils
from libs.mailparser import parse_raw_message
from libs.amavisd import QUARANTINE_TYPES
from libs.amavisd import log as loglib, quarantine, wblist as wblistlib


session = web.config.get('_session')


DELETE_ACTION_MSGS = {
    'release': 'RELEASED',
    'release_whitelist_sender': 'RELEASED_WL_SENDER',
    'release_whitelist_sender_domain': 'RELEASED_WL_SENDER_DOMAIN',
    'release_whitelist_sender_subdomain': 'RELEASED_WL_SENDER_SUBDOMAIN',
    'delete': 'DELETED',
    'deleteAll': 'DELETED',
    # log_type == 'received'
    'delete_whitelist_sender': 'DELETED_WL_SENDER',
    'delete_whitelist_sender_domain': 'DELETED_WL_SENDER_DOMAIN',
    'delete_whitelist_sender_subdomain': 'DELETED_WL_SENDER_SUBDOMAIN',
    'delete_blacklist_sender': 'DELETED_BL_SENDER',
    'delete_blacklist_sender_domain': 'DELETED_BL_SENDER_DOMAIN',
    'delete_blacklist_sender_subdomain': 'DELETED_BL_SENDER_SUBDOMAIN',
    # log_type == 'sent'
    'delete_whitelist_rcpt': 'DELETED_WL_RCPT',
    'delete_whitelist_rcpt_domain': 'DELETED_WL_RCPT_DOMAIN',
    'delete_whitelist_rcpt_subdomain': 'DELETED_WL_RCPT_SUBDOMAIN',
    'delete_blacklist_rcpt': 'DELETED_BL_RCPT',
    'delete_blacklist_rcpt_domain': 'DELETED_BL_RCPT_DOMAIN',
    'delete_blacklist_rcpt_subdomain': 'DELETED_BL_RCPT_SUBDOMAIN',
}


class InOutMails(object):
    @decorators.require_admin_login
    def GET(self, log_type='sent', page=1):
        log_type = str(log_type)

        # Get current page.
        page = int(page) or 1

        logLib = loglib.Log()
        qr = logLib.get_in_out_mails(logType=log_type, cur_page=page)
        if qr[0] is True:
            (total, records, mailids) = qr[1]
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))

        return web.render(
            'amavisd/inout.html',
            logType=log_type,
            cur_page=page,
            accountType=None,
            account=None,
            total=total,
            records=records,
            removeLogsInDays=settings.AMAVISD_REMOVE_MAILLOG_IN_DAYS,
            msg=web.input().get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self, log_type='sent', page=1):
        # Get current page.
        page = int(page) or 1
        redirect_url = '/activities/%s/page/%d' % (log_type, page)

        web_input = web.input(record=[], _unicode=False)
        action = web_input.get('action', 'delete')

        if not action.startswith('delete'):
            raise web.seeother(redirect_url + '?msg=INVALID_ACTION')

        mailids = []
        addresses = []
        for r in web_input.get('record', []):
            # record format: mail_id + \r\n + sender
            tmp = r.split(r'\r\n')
            if len(tmp) == 2:
                (mid, addr) = tmp
                mailids.append(mid)

                if iredutils.is_email(addr):
                    if action.endswith('_sender') or action.endswith('_rcpt'):
                        addresses.append(addr)
                    elif action.endswith('_domain'):
                        addresses.append('@' + addr.split('@', 1)[-1])
                    elif action.endswith('_subdomain'):
                        addresses.append('@.' + addr.split('@', 1)[-1])

        if not mailids and action != 'deleteAll':
            raise web.seeother(redirect_url + '?msg=INVALID_MAILID')

        logLib = loglib.Log()

        if action == 'deleteAll':
            qr_del = logLib.delete_all_records(log_type=log_type, account=None)
        else:
            # delete records by mailids
            qr_del = logLib.delete_records_by_mail_id(log_type=log_type, mail_ids=mailids)

        if not qr_del[0]:
            raise web.seeother(redirect_url + '?msg=' + web.urlquote(qr_del[1]))

        # Add server-wide white/blacklists.
        # Note: if admin is a normal admin, we don't know which domain he
        #       manages, so cannot add per-domain white/blacklists here.
        if session.get('is_global_admin') and addresses:
            wblist_account = '@.'

            wblist_lib = wblistlib.WBList()

            # whitelist recipients
            if action.startswith('delete_whitelist'):
                qr_wblist = wblist_lib.add_wblist(account=wblist_account,
                                                  wl_senders=addresses)
            elif action.startswith('delete_blacklist'):
                qr_wblist = wblist_lib.add_wblist(account=wblist_account,
                                                  bl_senders=addresses)

            if not qr_wblist[0]:
                raise web.seeother(redirect_url + '?msg=' + web.urlquote(qr_wblist[1]))

        raise web.seeother(redirect_url + '?msg=' + DELETE_ACTION_MSGS[action])


class InOutMailsPerAccount(object):
    @decorators.require_login
    def GET(self, log_type, accountType, account, page=1):
        log_type = str(log_type)
        accountType = str(accountType)
        account = str(account)
        page = int(page) or 1

        # Verify account syntax
        if accountType == 'domain':
            if not iredutils.is_domain(account):
                raise web.seeother('/activities/%s?msg=INVALID_DOMAIN_NAME' % log_type)
        elif accountType == 'user':
            if not iredutils.is_email(account):
                raise web.seeother('/activities/%s?msg=INVALID_MAIL' % log_type)

        logLib = loglib.Log()
        qr = logLib.get_in_out_mails(logType=log_type,
                                     cur_page=page,
                                     accountType=accountType,
                                     account=account)

        if qr[0] is True:
            (total, records, mailids) = qr[1]
        else:
            raise web.seeother('/activities/%s?msg=%s' % (log_type, web.urlquote(qr[1])))

        return web.render(
            'amavisd/inout.html',
            logType=log_type,
            cur_page=page,
            accountType=accountType,
            account=account,
            total=total,
            records=records,
            removeLogsInDays=settings.AMAVISD_REMOVE_MAILLOG_IN_DAYS,
            msg=web.input().get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, log_type, accountType, account, page=1):
        log_type = str(log_type)
        accountType = str(accountType)
        account = str(account)
        page = int(page) or 1
        redirect_url = '/activities/%s/%s/%s/page/%d' % (log_type, accountType, account, page)

        web_input = web.input(record=[], _unicode=False)
        action = str(web_input.get('action', ''))

        if not action.startswith('delete'):
            raise web.seeother(redirect_url + '?msg=INVALID_ACTION')

        mailids = []
        addresses = []
        for r in web_input.get('record', []):
            # record format: mail_id + \r\n + sender
            tmp = r.split(r'\r\n')
            if len(tmp) == 2:
                (mid, addr) = tmp
                mailids.append(mid)

                if iredutils.is_email(addr):
                    if action.endswith('_sender') or action.endswith('_rcpt'):
                        addresses.append(addr)
                    elif action.endswith('_domain'):
                        addresses.append('@' + addr.split('@', 1)[-1])
                    elif action.endswith('_subdomain'):
                        addresses.append('@.' + addr.split('@', 1)[-1])

        if not mailids and action != 'deleteAll':
            raise web.seeother(redirect_url + '?msg=INVALID_MAILID')

        logLib = loglib.Log()

        if action == 'deleteAll':
            qr_del = logLib.delete_all_records(log_type=log_type, account=None)
        else:
            # delete records by mailids
            qr_del = logLib.delete_records_by_mail_id(log_type=log_type, mail_ids=mailids)

        if not qr_del[0]:
            raise web.seeother(redirect_url + '?msg=' + web.urlquote(qr_del[1]))

        # Add server-wide white/blacklists.
        # Note: if admin is a normal admin, we don't know which domain he
        #       manages, so cannot add per-domain white/blacklists here.
        if session.get('is_global_admin') and addresses:
            wblist_account = account

            wblist_lib = wblistlib.WBList()

            # whitelist recipients
            if action.startswith('delete_whitelist'):
                qr_wblist = wblist_lib.add_wblist(account=wblist_account,
                                                  wl_senders=addresses)
            elif action.startswith('delete_blacklist'):
                qr_wblist = wblist_lib.add_wblist(account=wblist_account,
                                                  bl_senders=addresses)

            if not qr_wblist[0]:
                raise web.seeother(redirect_url + '?msg=' + web.urlquote(qr_wblist[1]))

        raise web.seeother(redirect_url + '?msg=' + DELETE_ACTION_MSGS[action])


class QuarantinedMails(object):
    @decorators.require_admin_login
    def GET(self, quarantined_type=None, page=1):
        web_input = web.input()
        sort_by_score = 'sort_by_score' in web_input

        # Get current page.
        # None means on page 1, e.g. /activities/quarantined
        if quarantined_type in QUARANTINE_TYPES + [None]:
            page = int(page) or 1
        else:
            page = int(quarantined_type) or 1
            quarantined_type = None

        quarantineLib = quarantine.Quarantine()
        qr = quarantineLib.get_quarantined_mails(quarantined_type=quarantined_type,
                                                 page=page,
                                                 sort_by_score=sort_by_score)

        if qr[0] is True:
            (total, records) = qr[1]
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))

        return web.render(
            'amavisd/quarantined.html',
            accountType=None,
            account=None,
            quarantined_type=quarantined_type,
            cur_page=page,
            total=total,
            records=records,
            removeQuarantinedInDays=settings.AMAVISD_REMOVE_QUARANTINED_IN_DAYS,
            sort_by_score=sort_by_score,
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self, quarantined_type=None, page=1):
        web_input = web.input(record=[], _unicode=False)

        action = web_input.get('action', None)

        if quarantined_type in QUARANTINE_TYPES:
            page = int(page) or 1
        else:
            page = int(quarantined_type) or 1
            quarantined_type = None

        redirect_url = '/activities/quarantined'
        if quarantined_type:
            redirect_url = redirect_url + '/' + quarantined_type

        if action == 'deleteAll':
            if session.get('is_global_admin') is True:
                quarantineLib = quarantine.Quarantine()
                result = quarantineLib.delete_all_quarantined()

            raise web.seeother(redirect_url + '?msg=%s' % DELETE_ACTION_MSGS[action])

        # Get necessary information from web form.
        records = []
        mailids = []
        senders = set()

        for r in web_input.get('record', []):
            # record format: mail_id + \r\n + secret_id + \r\n + sender
            tmp = r.split(r'\r\n')
            if len(tmp) == 3:
                records += [{'mail_id': tmp[0], 'secret_id': tmp[1]}]
                mailids.append(tmp[0])

                if iredutils.is_email(tmp[2]):
                    senders.add(tmp[2])

        if not mailids:
            if not (action == 'deleteAll' and session.get('is_global_admin')):
                raise web.seeother(redirect_url + '?msg=INVALID_MAILID')

        if action != 'deleteAll' and not mailids:
            raise web.seeother(redirect_url + '?msg=%s' % DELETE_ACTION_MSGS[action])

        wb_senders = set()
        if action in ['release_whitelist_sender', 'delete_blacklist_sender']:
            wb_senders = senders
        elif action in ['release_whitelist_sender_domain', 'delete_blacklist_sender_domain']:
            for s in senders:
                wb_senders.add('@' + s.split('@', 1)[-1])
        elif action in ['release_whitelist_sender_subdomain', 'delete_blacklist_sender_subdomain']:
            for s in senders:
                wb_senders.add('@.' + s.split('@', 1)[-1])

        wblist_account = '@.'
        if session.get('is_global_admin'):
            # Add as global wblist
            wblist_account = '@.'
        elif session.get('is_normal_admin'):
            # Add as per-domain wblist
            wblist_account = '@' + session['username'].split('@', 1)[-1]

        if action.startswith('release'):
            quarantineLib = quarantine.Quarantine()
            result = quarantineLib.release_quarantined_mails(records=records)

            if action in ['release_whitelist_sender',
                          'release_whitelist_sender_domain',
                          'release_whitelist_sender_subdomain']:
                # whitelist senders or sender_domains
                if wb_senders:
                    wblist_lib = wblistlib.WBList()
                    qr = wblist_lib.add_wblist(account=wblist_account,
                                               wl_senders=wb_senders)
                    if not qr[0]:
                        result = qr

        elif action.startswith('delete'):
            logLib = loglib.Log()
            result = logLib.delete_records_by_mail_id(log_type='quarantine', mail_ids=mailids)

            if action in ['delete_blacklist_sender',
                          'delete_blacklist_sender_domain',
                          'delete_blacklist_sender_subdomain']:
                if wb_senders:
                    wblist_lib = wblistlib.WBList()
                    qr = wblist_lib.add_wblist(account=wblist_account,
                                               bl_senders=wb_senders)
                    if not qr[0]:
                        result = qr

        else:
            result = (False, 'INVALID_ACTION')

        if result[0] is True:
            raise web.seeother(redirect_url + '?msg=%s' % DELETE_ACTION_MSGS[action])
        else:
            raise web.seeother(redirect_url + '?msg=%s' % web.urlquote(result[1]))


class QuarantinedMailsPerAccount(object):
    @decorators.require_login
    def GET(self, accountType, account, quarantined_type=None, page=1):
        accountType = str(accountType)
        account = str(account)

        web_input = web.input()
        sort_by_score = 'sort_by_score' in web_input

        # Normal user login
        if session['account_is_mail_user'] and accountType == 'user':
            if session['username'] != account:
                # Accessing other's quarantined mails
                raise web.seeother('/activities/quarantined/user/%s?msg=PERMISSION_DENIED' % session['username'])
            if 'quarantine' in session.get('disabled_user_preferences', []):
                raise web.seeother('/preferences?msg=PERMISSION_DENIED')

        if quarantined_type:
            # Get current page.
            if str(quarantined_type).isdigit():
                # According to URL mapping, quarantined_type could be page number.
                page = int(quarantined_type) or 1
            else:
                page = int(page) or 1

            if not quarantined_type in QUARANTINE_TYPES:
                quarantined_type = None

        quarantineLib = quarantine.Quarantine()
        qr = quarantineLib.get_quarantined_mails(
            accountType=accountType,
            account=account,
            quarantined_type=quarantined_type,
            page=page,
            sort_by_score=sort_by_score,
        )
        if qr[0] is True:
            (total, records) = qr[1]
        else:
            if session['account_is_mail_user']:
                raise web.seeother('/preferences?msg=%s' % web.urlquote(qr[1]))
            else:
                raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))

        template_file = 'amavisd/quarantined.html'
        if session['account_is_mail_user']:
            template_file = 'amavisd/quarantined_user.html'

        return web.render(
            template_file,
            accountType=accountType,
            account=account,
            quarantined_type=quarantined_type,
            cur_page=page,
            total=total,
            records=records,
            removeQuarantinedInDays=settings.AMAVISD_REMOVE_QUARANTINED_IN_DAYS,
            sort_by_score=sort_by_score,
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, accountType, account, quarantined_type=None, page=1):
        web_input = web.input(record=[], _unicode=False)

        if session.get('account_is_mail_user') and accountType == 'user':
            if account != session['username']:
                result = (False, 'PERMISSION_DENIED')

        if quarantined_type:
            # Get current page.
            if str(quarantined_type).isdigit():
                # According to URL mapping, quarantined_type could be page number.
                page = int(quarantined_type) or 1
            else:
                page = int(page) or 1

            if not quarantined_type in QUARANTINE_TYPES:
                quarantined_type = None

        redirect_url = '/activities/quarantined'
        if accountType and account:
            redirect_url = redirect_url + '/%s/%s' % (accountType, account)

        if quarantined_type:
            redirect_url = redirect_url + '/' + quarantined_type

        action = web_input.get('action', None)

        # Get necessary information from web form.
        records = []
        mailids = []
        senders = set()

        # Get `msgs.mail_id` and `msgs.secret_id`
        for r in web_input.get('record', []):
            # record format: mail_id + \r\n + secret_id + \r\n + sender
            tmp = r.split(r'\r\n')
            if len(tmp) == 3:
                records += [{'mail_id': tmp[0], 'secret_id': tmp[1]}]
                mailids.append(tmp[0])

                if iredutils.is_email(tmp[2]):
                    senders.add(tmp[2])

        if not mailids:
            raise web.seeother(redirect_url + '?msg=INVALID_MAILID')

        wb_senders = set()
        if action in ['release_whitelist_sender', 'delete_blacklist_sender']:
            wb_senders = senders
        elif action in ['release_whitelist_sender_domain', 'delete_blacklist_sender_domain']:
            for s in senders:
                wb_senders.add('@' + s.split('@', 1)[-1])
        elif action in ['release_whitelist_sender_subdomain', 'delete_blacklist_sender_subdomain']:
            for s in senders:
                wb_senders.add('@.' + s.split('@', 1)[-1])

        wblist_account = account
        if session.get('is_global_admin'):
            # Add as global wblist
            wblist_account = '@.'
        elif session.get('is_normal_admin'):
            # Add as per-domain wblist
            wblist_account = '@' + account.split('@', 1)[-1]

        if action.startswith('release'):
            quarantineLib = quarantine.Quarantine()
            result = quarantineLib.release_quarantined_mails(records=records)

            if action in ['release_whitelist_sender',
                          'release_whitelist_sender_domain',
                          'release_whitelist_sender_subdomain']:
                # whitelist senders or sender_domains
                if wb_senders:
                    wblist_lib = wblistlib.WBList()
                    qr = wblist_lib.add_wblist(account=wblist_account,
                                               wl_senders=wb_senders)
                    if not qr[0]:
                        result = qr
        elif action.startswith('delete'):
            logLib = loglib.Log()
            result = logLib.delete_records_by_mail_id(log_type='quarantine', mail_ids=mailids)

            if action in ['delete_blacklist_sender',
                          'delete_blacklist_sender_domain',
                          'delete_blacklist_sender_subdomain']:
                # Don't add account domain in blacklist
                try:
                    wb_senders.remove(account.split('@', 1)[-1])
                except:
                    pass

                if wb_senders:
                    wblist_lib = wblistlib.WBList()
                    qr = wblist_lib.add_wblist(account=wblist_account,
                                               bl_senders=wb_senders)
                    if not qr[0]:
                        result = qr
        else:
            result = (False, 'INVALID_ACTION')

        if result[0]:
            msg = DELETE_ACTION_MSGS[action]
        else:
            msg = web.urlquote(result[1])

        raise web.seeother(redirect_url + '?msg=%s' % msg)


class GetRawMessageOfQuarantinedMail(object):
    @decorators.require_login
    def GET(self, mail_id):
        quarantineLib = quarantine.Quarantine()
        result = quarantineLib.get_raw_message(mail_id)

        if result[0] is True:
            # Parse mail and convert to HTML.
            (headers, bodies, attachments) = parse_raw_message(result[1])
            return web.render(
                'amavisd/quarantined_raw.html',
                mail_id=mail_id,
                headers=headers,
                bodies=bodies,
                attachments=attachments,
            )
        else:
            raise web.seeother('/activities/quarantined?msg=%s' % web.urlquote(result[1]))


class SearchLog(object):
    @decorators.require_admin_login
    def GET(self):
        raise web.seeother('/activities/sent')

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self):
        form = web.input(_unicode=False)
        account = form.get('account', '')

        logType = 'sent'
        if 'received' in form:
            logType = 'received'
        elif 'sent' in form:
            logType = 'sent'
        elif 'quarantined' in form:
            logType = 'quarantined'

        if iredutils.is_email(account):
            accountType = 'user'
        elif iredutils.is_domain(account):
            accountType = 'domain'
        else:
            raise web.seeother('/activities/%s?msg=INVALID_ACCOUNT' % (logType))

        raise web.seeother('/activities/%s/%s/%s' % (logType, accountType, account))
