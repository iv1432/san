# Author: Zhang Huangbin <zhb@iredmail.org>

import web
from controllers import decorators
from libs.iredapd import greylist as iredapd_greylist


class DefaultGreylisting(object):
    @decorators.require_global_admin
    def GET(self):
        qr = iredapd_greylist.get_greylist_setting_and_whitelists(account='@.')
        gl_setting = qr['setting']
        gl_whitelists = qr['whitelists']
        gl_whitelist_domains = qr['whitelist_domains']

        return web.render('iredapd/greylist_global.html',
                          gl_setting=gl_setting,
                          gl_whitelists=gl_whitelists,
                          gl_whitelist_domains=gl_whitelist_domains,
                          parent_setting={},
                          msg=web.input().get('msg'))

    @decorators.require_global_admin
    def POST(self):
        form = web.input()
        qr = iredapd_greylist.update_greylist_settings_from_form(account='@.', form=form)

        if qr[0] is True:
            raise web.seeother('/system/greylisting?msg=GL_UPDATED')
        else:
            raise web.seeother('/system/greylisting?msg=%s' % web.urlquote(qr[1]))
