# Author: Zhang Huangbin <zhb@iredmail.org>

import settings
from libs.regxes import email as regx_email, domain as regx_domain

urls = [
    # Throttling
    '/system/throttle',     'controllers.iredapd.throttle.DefaultThrottle',
    '/system/greylisting',  'controllers.iredapd.greylist.DefaultGreylisting',
]

# API Interfaces
if settings.ENABLE_RESTFUL_API:
    urls += [
        '/api/throttle/global/(inbound|outbound)',  'controllers.iredapd.throttle.APIDefaultThrottle',
        '/api/throttle/(%s)/(inbound|outbound)' % regx_domain, 'controllers.iredapd.throttle.APIDomainThrottle',
        '/api/throttle/(%s)/(inbound|outbound)' % regx_email,  'controllers.iredapd.throttle.APIUserThrottle',
    ]
