# Author: Zhang Huangbin <zhb@iredmail.org>

urls = [
    '/expired',         'controllers.utils.Expired',
    '/system',          'controllers.panel.log.Log',
    '/system/log',      'controllers.panel.log.Log',
    '/system/license',  'controllers.panel.log.License',
]
