# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import __id__, __url_license_terms__
from controllers import decorators
from libs.panel import LOG_EVENTS, log as loglib, get_license_info

session = web.config.get('_session')

if settings.backend == 'ldap':
    from libs.ldaplib import admin as adminlib, connUtils
    from libs import __version_ldap__ as version
elif settings.backend in ['mysql', 'pgsql']:
    from libs import __version_sql__ as version
    from libs.sqllib import SQLWrap, admin as sql_lib_admin


class Log(object):
    @decorators.require_admin_login
    def GET(self):
        web_input = web.input(_unicode=False)

        # Get queries.
        self.event = web.safestr(web_input.get('event', 'all'))
        self.domain = web.safestr(web_input.get('domain', 'all'))
        self.admin = web.safestr(web_input.get('admin', 'all'))
        self.cur_page = web.safestr(web_input.get('page', '1'))

        if not self.cur_page.isdigit() or self.cur_page == '0':
            self.cur_page = 1
        else:
            self.cur_page = int(self.cur_page)

        logLib = loglib.Log()
        total, entries = logLib.listLogs(event=self.event,
                                         domain=self.domain,
                                         admin=self.admin,
                                         cur_page=self.cur_page)

        # Pre-defined
        allDomains = []
        all_admins = []

        if settings.backend == 'ldap':
            # Get all managed domains under control.
            connutils = connUtils.Utils()
            qr = connutils.get_managed_domains(admin=session.get('username'), attributes=['domainName'])
            if qr[0] is True:
                allDomains = [str(v[1]['domainName'][0]).lower() for v in qr[1]]

            # Get all admins.
            if session.get('is_global_admin') is True:
                adminLib = adminlib.Admin()
                result = adminLib.list_accounts(attributes=['mail'])
                if result[0] is not False:
                    all_admins = [v[1]['mail'][0] for v in result[1]]
            else:
                all_admins = [self.admin]

        elif settings.backend in ['mysql', 'pgsql']:
            # Get all managed domains under control.
            sql_wrap = SQLWrap()
            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=session.get('username'),
                                                   domain_name_only=True)
            if qr[0] is True:
                allDomains = qr[1]

            # Get all admins.
            if session.get('is_global_admin') is True:
                qr = sql_lib_admin.get_all_admins(conn=sql_wrap.conn,
                                                  columns=['username'])
                if qr[0] is True:
                    for r in qr[1]:
                        all_admins += [r.username]
            else:
                all_admins = [self.admin]

        return web.render(
            'panel/log.html',
            event=self.event,
            domain=self.domain,
            admin=self.admin,
            allEvents=LOG_EVENTS,
            cur_page=self.cur_page,
            total=total,
            entries=entries,
            allDomains=allDomains,
            allAdmins=all_admins,
            msg=web_input.get('msg'),
        )

    @decorators.require_global_admin
    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self):
        form = web.input(_unicode=False, id=[])
        action = web.safestr(form.get('action', 'delete'))

        deleteAll = False
        if action == 'deleteAll':
            deleteAll = True

        logLib = loglib.Log()
        result = logLib.delete(form=form, deleteAll=deleteAll)

        if result[0] is True:
            raise web.seeother('/system/log?msg=DELETED')
        else:
            raise web.seeother('/system/log?msg=%s' % web.urlquote(result[1]))


class License(object):
    @decorators.require_global_admin
    def GET(self):
        info = get_license_info()

        if info[0] is True:
            if version < info[1].get('latestversion'):
                session['new_version_available'] = True
                session['new_version'] = info[1].get('latestversion')

            return web.render('panel/license.html',
                              info=info[1],
                              id=__id__,
                              url_license_terms=__url_license_terms__,
                              version=version)
        else:
            return web.render('panel/license.html', error=info[1])
