# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings

from controllers.utils import tuple_to_api_render

from libs import iredutils, form_utils
from libs.languages import get_language_maps, TIMEZONES

from libs.sqllib import SQLWrap, decorators, sqlutils
from libs.sqllib import alias as sql_lib_alias
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import utils as sql_lib_utils
from libs.sqllib import general as sql_lib_general

from libs.amavisd import spampolicy as spampolicylib, wblist as wblistlib

session = web.config.get('_session')

if session.get('enable_iredapd'):
    from libs.iredapd import throttle as iredapd_throttle
    from libs.iredapd import greylist as iredapd_greylist


class List(object):
    """List paged virtual mail domains."""
    @decorators.require_admin_login
    def GET(self, cur_page=1, disabled_only=False):
        web_input = web.input(_unicode=False)
        cur_page = int(cur_page) or 1

        total = 0
        all_domain_profiles = []
        domain_used_quota = {}

        first_char = None
        if 'starts_with' in web_input:
            first_char = web_input.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        sql_wrap = SQLWrap()
        total = sql_lib_admin.num_managed_domains(conn=sql_wrap.conn, disabled_only=disabled_only)

        if total:
            qr = sql_lib_domain.get_paged_domains(conn=sql_wrap.conn,
                                                  cur_page=cur_page,
                                                  first_char=first_char,
                                                  disabled_only=disabled_only)
            if qr[0]:
                all_domain_profiles = qr[1]

            if settings.SHOW_USED_QUOTA:
                domains = []
                for i in all_domain_profiles:
                    domains.append(str(i.domain))

                domain_used_quota = sql_lib_domain.get_domain_used_quota(conn=sql_wrap.conn,
                                                                         domains=domains)

        # Get alias domain names.
        all_alias_domains = {}
        if all_domain_profiles:

            all_domain_names = [str(d.domain).lower() for d in all_domain_profiles]
            qr = sql_wrap.conn.select('alias_domain',
                                      vars={'all_domain_names': all_domain_names},
                                      what='alias_domain, target_domain',
                                      where='target_domain IN $all_domain_names')
            if qr:
                for r in qr:
                    td = str(r.target_domain).lower()
                    ad = str(r.alias_domain).lower()

                    if td in all_alias_domains:
                        all_alias_domains[td].append(ad)
                    else:
                        all_alias_domains[td] = [ad]

        return web.render('sql/domain/list.html',
                          cur_page=cur_page,
                          total=total,
                          all_domain_profiles=all_domain_profiles,
                          all_alias_domains=all_alias_domains,
                          domain_used_quota=domain_used_quota,
                          local_transports=settings.LOCAL_TRANSPORTS,
                          first_char=first_char,
                          disabled_only=disabled_only,
                          msg=web_input.get('msg', None))

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input(domainName=[], _unicode=False)
        domains = form.get('domainName', None)
        action = form.get('action')

        sql_wrap = SQLWrap()

        if action == 'delete':
            result = sql_lib_domain.delete_domains(conn=sql_wrap.conn, domains=domains)
            msg = 'DELETED'
        elif action == 'disable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=domains,
                                                      account_type='domain',
                                                      enable_account=False)
            msg = 'DISABLED'
        elif action == 'enable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=domains,
                                                      account_type='domain',
                                                      enable_account=True)
            msg = 'ENABLED'
        else:
            result = (False, 'INVALID_ACTION')
            msg = form.get('msg', None)

        if result[0] is True:
            raise web.seeother('/domains?msg=%s' % msg)
        else:
            raise web.seeother('/domains?msg=' + web.urlquote(result[1]))


class ListDisabled(object):
    '''List disabled mail domains.'''
    @decorators.require_admin_login
    def GET(self, cur_page=1):
        l = List()
        return l.GET(cur_page=cur_page, disabled_only=True)


class Profile(object):
    @decorators.require_domain_access
    def GET(self, profile_type, domain):
        web_input = web.input()
        self.domain = web.safestr(domain.split('/', 1)[0])
        profile_type = web.safestr(profile_type)

        sql_wrap = SQLWrap()
        result = sql_lib_domain.profile(conn=sql_wrap.conn, domain=self.domain)

        if result[0] is not True:
            raise web.seeother('/domains?msg=' + web.urlquote(result[1]))
        else:
            domain_profile = result[1]

        aliasDomains = []   # Get all alias domains.
        allAliases = []     # Get all mail aliases.

        # profile_type == 'throttle'
        # throttle: iRedAPD
        gl_setting = {}
        gl_whitelists = []
        inbound_throttle_setting = {}
        outbound_throttle_setting = {}

        # Get alias domains.
        qr = sql_lib_domain.get_all_alias_domains(conn=sql_wrap.conn,
                                                  domain=self.domain,
                                                  name_only=True)
        if qr[0] is True:
            aliasDomains = qr[1]

        # Get all mail aliases.
        mailsOfAllAliases = []
        qr = sql_lib_alias.get_all_aliases(conn=sql_wrap.conn,
                                           domain=self.domain,
                                           columns=['name', 'address'])
        if qr[0] is True:
            allAliases = qr[1]
            for ali in allAliases:
                mailsOfAllAliases += [ali.address]

        # Get sender dependent relayhost
        relayhost = sql_lib_general.get_sender_relayhost(conn=sql_wrap.conn,
                                                         sender='@' + self.domain)

        # Get sender/recipient throttle data from iRedAPD database.
        if session.get('enable_iredapd'):
            # Greylisting
            qr = iredapd_greylist.get_greylist_setting_and_whitelists(account='@' + self.domain)
            gl_setting = qr['setting']
            gl_whitelists = qr['whitelists']

            # Throttling
            lib_trot = iredapd_throttle.Throttle()

            # Get default inbound/outbound throttle
            inbound_throttle_setting = lib_trot.get_throttle_setting(account='@' + self.domain, inout_type='inbound')
            outbound_throttle_setting = lib_trot.get_throttle_setting(account='@' + self.domain, inout_type='outbound')

        spampolicy = {}
        global_spam_score = None
        if session.get('amavisd_enable_policy_lookup'):
            policy_lib = spampolicylib.SpamPolicy()
            qr = policy_lib.get_spam_policy(account='@' + self.domain)
            if not qr[0]:
                raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))
            spampolicy = qr[1]

            global_spam_score = policy_lib.get_global_spam_score()

        # Get per-domain white/blacklists
        whitelists = []
        blacklists = []
        outbound_whitelists = []
        outbound_blacklists = []

        wblist_lib = wblistlib.WBList()
        qr = wblist_lib.get_account_wblist(account='@'+self.domain)
        if qr[0]:
            whitelists = qr[1]['whitelist']
            blacklists = qr[1]['blacklist']
            outbound_whitelists = qr[1]['outbound_whitelist']
            outbound_blacklists = qr[1]['outbound_blacklist']

        return web.render(
            'sql/domain/profile.html',
            cur_domain=self.domain,
            profile_type=profile_type,
            profile=domain_profile,
            default_mta_transport=settings.default_mta_transport,
            domain_settings=sqlutils.account_settings_string_to_dict(domain_profile['settings']),
            aliasDomains=aliasDomains,
            allAliases=allAliases,
            mailsOfAllAliases=mailsOfAllAliases,
            relayhost=relayhost,
            timezones=TIMEZONES,
            # iRedAPD
            gl_setting=gl_setting,
            gl_whitelists=gl_whitelists,
            inbound_throttle_setting=inbound_throttle_setting,
            outbound_throttle_setting=outbound_throttle_setting,
            # Language
            languagemaps=get_language_maps(),
            # Spam policy, wblist
            spampolicy=spampolicy,
            global_spam_score=global_spam_score,
            whitelists=whitelists,
            blacklists=blacklists,
            outbound_whitelists=outbound_whitelists,
            outbound_blacklists=outbound_blacklists,
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, profile_type, domain):
        domain = str(domain).lower()

        form = web.input(domainAliasName=[],
                         domainAdmin=[],
                         defaultList=[],
                         enabledService=[],
                         disabledDomainProfile=[],
                         disabledUserProfile=[],
                         disabledUserPreference=[])

        sql_wrap = SQLWrap()
        result = sql_lib_domain.update(conn=sql_wrap.conn,
                                       profile_type=profile_type,
                                       domain=domain,
                                       form=form)

        if result[0] is True:
            raise web.seeother('/profile/domain/%s/%s?msg=UPDATED' % (profile_type, domain))
        else:
            raise web.seeother('/profile/domain/%s/%s?msg=%s' % (profile_type, domain, web.urlquote(result[1])))


class Create(object):
    @decorators.require_global_admin
    def GET(self):
        form = web.input()
        return web.render('sql/domain/create.html',
                          preferred_language=settings.default_language,
                          languagemaps=get_language_maps(),
                          msg=form.get('msg'))

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input()
        domain = form_utils.get_domain_name(form)

        sql_wrap = SQLWrap()
        result = sql_lib_domain.add(conn=sql_wrap.conn, form=form)

        if result[0] is True:
            raise web.seeother('/profile/domain/general/%s?msg=CREATED' % domain)
        else:
            raise web.seeother('/create/domain?msg=%s' % web.urlquote(result[1]))


class APIDomain(object):
    @decorators.api_require_global_admin
    def POST(self, domain):
        """Create a new domain.
        curl -X POST -i -b cookie.txt -d "defaultQuota=1024" https://<server>/api/domain/<new_domain>

        POST data:

        @cn (optional) - the short description of this domain name. e.g. company name.
        @quota (optional) - a digital number for mailbox quota (for whole domain)
        @preferredLanguage (optional) - default preferred language for new user.
                                        e.g. en_US for English, de_DE for Deutsch.
        @defaultQuota (optional) - default mailbox quota for new user.
        @maxUserQuota (optional) - Max mailbox quota of a single mail user
        @numberOfUsers (optional) - Max number of mail user accounts
        @numberOfAliases (optional) - Max number of mail alias accounts
        """
        form = web.input()
        form['domainName'] = domain
        form['domainQuota'] = form.get('quota')
        form['domainQuotaUnit'] = 'MB'

        sql_wrap = SQLWrap()
        result = sql_lib_domain.add(conn=sql_wrap.conn, form=form)

        return tuple_to_api_render(result)

    @decorators.api_require_global_admin
    def DELETE(self, domain):
        """Delete an existing mail domain.

        curl -X DELETE -i -b cookie.txt https://<server>/api/domain/<domain>
        """
        if not iredutils.is_domain(domain):
            return tuple_to_api_render((False, 'INVALID_DOMAIN_NAME'))

        sql_wrap = SQLWrap()
        result = sql_lib_domain.delete_domains(conn=sql_wrap.conn, domains=[domain])
        return tuple_to_api_render(result)

    @decorators.api_require_domain_access
    def PUT(self, domain):
        """Update domain profile.
        curl -X PUT -i -b cookie.txt -d "var=<value>" https://<server>/api/domain/<domain>
        curl -X PUT -i -b cookie.txt -d "var=<value>&var2=<value2>" https://<server>/api/domain/<domain>

        Optional PUT data:

        @name - the short company/orgnization name
        @accountStatus - enable or disable domain. possible value is: active, disabled.
        """
        # TODO  add function in libs/sqllib/domain.py, used to update single
        #       domain profile. e.g. account status, quota, sender bcc,
        #       recipient bcc.
        form = web.input()

        update = {}

        if 'cn' in form:
            cn = form_utils.get_single_value(form, input_name='cn')
            if cn:
                update['name'] = cn

        if 'accountStatus' in form:
            status = form_utils.get_account_status(form, to_integer=True)
            update['active'] = status

        if update:
            try:
                sql_wrap = SQLWrap()
                conn = sql_wrap.conn
                conn.update('domain',
                            vars=update,
                            where='domain=%s' % domain)

                return tuple_to_api_render((True, ))
            except Exception, e:
                return tuple_to_api_render((False, str(e)))
