# Author: Zhang Huangbin <zhb@iredmail.org>

import web

from controllers.utils import tuple_to_api_render

from libs import iredutils, form_utils
from libs.sqllib import SQLWrap, decorators
from libs.sqllib import alias as sql_lib_alias
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import utils as sql_lib_utils

session = web.config.get('_session')


class List(object):
    @decorators.require_domain_access
    def GET(self, domain, cur_page=1, disabled_only=False):
        domain = str(domain).lower()
        cur_page = int(cur_page) or 1

        web_input = web.input(_unicode=False)

        first_char = None
        if 'starts_with' in web_input:
            first_char = web_input.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        sql_wrap = SQLWrap()
        total = sql_lib_alias.num_aliases_under_domain(conn=sql_wrap.conn,
                                                       domain=domain,
                                                       disabled_only=disabled_only)

        records = []
        if total:
            columns = ['address', 'goto', 'domain', 'name', 'active']
            qr = sql_lib_alias.get_all_aliases(conn=sql_wrap.conn,
                                               domain=domain,
                                               columns=columns,
                                               page=cur_page,
                                               first_char=first_char,
                                               disabled_only=disabled_only)
            if qr[0]:
                records = qr[1]

        return web.render(
            'sql/alias/list.html',
            cur_domain=domain,
            cur_page=cur_page,
            total=total,
            aliases=records,
            first_char=first_char,
            msg=web_input.get('msg', None),
        )

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, domain):
        form = web.input(_unicode=False, mail=[])
        domain = str(domain).lower()

        accounts = form.get('mail', [])
        action = form.get('action', None)
        msg = form.get('msg', None)

        # Filter aliases not under the same domain.
        accounts = [str(v).lower()
                    for v in accounts
                    if iredutils.is_email(v) and str(v).endswith('@' + domain)]

        sql_wrap = SQLWrap()

        if action == 'delete':
            result = sql_lib_alias.delete_aliases(conn=sql_wrap.conn,
                                                  accounts=accounts)
            msg = 'DELETED'
        elif action == 'disable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=accounts,
                                                      account_type='alias',
                                                      enable_account=False)
            msg = 'DISABLED'
        elif action == 'enable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=accounts,
                                                      account_type='alias',
                                                      enable_account=True)
            msg = 'ENABLED'
        else:
            result = (False, 'INVALID_ACTION')

        if result[0] is True:
            raise web.seeother('/aliases/%s?msg=%s' % (domain, msg))
        else:
            raise web.seeother('/aliases/%s?msg=%s' % (domain, web.urlquote(result[1])))


class ListDisabled(object):
    @decorators.require_domain_access
    def GET(self, domain, cur_page=1):
        l = List()
        return l.GET(domain=domain, cur_page=cur_page, disabled_only=True)


class Create(object):
    @decorators.require_domain_access
    def GET(self, domain):
        domain = str(domain).lower()

        web_input = web.input()
        all_domains = []

        # Get all domains, select the first one.
        sql_wrap = SQLWrap()

        if session.get('is_global_admin'):
            qr = sql_lib_domain.get_all_domains(conn=sql_wrap.conn, name_only=True)
        else:
            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=session.get('username'),
                                                   domain_name_only=True)

        if qr[0] is True:
            all_domains = qr[1]

        # Get domain profile.
        qr_profile = sql_lib_domain.profile(conn=sql_wrap.conn, domain=domain)
        if qr_profile[0] is True:
            domain_profile = qr_profile[1]
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(qr_profile[1]))

        # Cet total number and allocated quota size of existing users under domain.
        num_aliases_under_domain = sql_lib_alias.num_aliases_under_domain(conn=sql_wrap.conn, domain=domain)

        return web.render(
            'sql/alias/create.html',
            cur_domain=domain,
            allDomains=all_domains,
            profile=domain_profile,
            numberOfExistAccounts=num_aliases_under_domain,
            numberOfAccounts=2,
            msg=web_input.get('msg'),
        )

    @decorators.require_domain_access
    @decorators.csrf_protected
    def POST(self, domain):
        domain = str(domain).lower()
        form = web.input()

        domain_in_form = form_utils.get_domain_name(form)

        if domain != domain_in_form:
            raise web.seeother('/domains?msg=PERMISSION_DENIED')

        listname = form_utils.get_single_value(form, input_name='listname', to_string=True)
        mail = listname + '@' + domain

        sql_wrap = SQLWrap()
        result = sql_lib_alias.add_alias_from_form(conn=sql_wrap.conn, domain=domain, form=form)

        if result[0] is True:
            raise web.seeother('/profile/alias/general/%s?msg=CREATED' % (mail))
        else:
            raise web.seeother('/create/alias/%s?msg=%s' % (domain, web.urlquote(result[1])))


class Profile(object):
    @decorators.require_domain_access
    def GET(self, profile_type, mail):
        if profile_type == 'rename':
            raise web.seeother('/profile/alias/general/' + mail)

        form = web.input()
        mail = web.safestr(mail).lower()
        domain = mail.split('@', 1)[-1]

        if not iredutils.is_email(mail):
            raise web.seeother('/domains?msg=INVALID_USER')

        sql_wrap = SQLWrap()
        qr = sql_lib_alias.profile(conn=sql_wrap.conn, domain=domain, mail=mail)
        if qr[0] is True:
            profile = qr[1]
        else:
            raise web.seeother('/aliases/%s?msg=%s' % (domain, web.urlquote(qr[1])))

        return web.render('sql/alias/profile.html',
                          cur_domain=domain,
                          mail=mail,
                          profile_type=profile_type,
                          profile=profile,
                          msg=form.get('msg'))

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, profile_type, mail):
        form = web.input(mailForwardingAddress=[], moderators=[])

        sql_wrap = SQLWrap()
        result = sql_lib_alias.update(conn=sql_wrap.conn,
                                      mail=mail,
                                      profile_type=profile_type,
                                      form=form)

        if profile_type == 'rename':
            profile_type = 'general'

        if result[0] is True:
            raise web.seeother('/profile/alias/%s/%s?msg=UPDATED' % (profile_type, mail))
        else:
            raise web.seeother('/profile/alias/%s/%s?msg=%s' % (profile_type, mail, web.urlquote(result[1])))


class APIAlias(object):
    @decorators.api_require_domain_access
    def POST(self, mail):
        """Create a new mail alias account.

        curl -X POST -i -b cookie.txt -d "..." https://<server>/api/alias/<email>

        Optional POST data:

        @cn - display name
        """
        mail = str(mail).lower()
        (listname, domain) = mail.split('@', 1)

        form = web.input()

        form['listname'] = listname
        form['domainName'] = domain

        sql_wrap = SQLWrap()
        result = sql_lib_alias.add_alias_from_form(conn=sql_wrap.conn, domain=domain, form=form)
        return tuple_to_api_render(result)

    # Delete aliases.
    @decorators.api_require_domain_access
    def DELETE(self, mail):
        """Delete a mail alias account.
        curl -X DELETE -i -b cookie.txt https://<server>/api/alias/<mail>
        """
        mail = str(mail).lower()

        sql_wrap = SQLWrap()
        result = sql_lib_alias.delete_aliases(conn=sql_wrap.conn,
                                              accounts=[mail])
        return tuple_to_api_render(result)

    @decorators.api_require_domain_access
    def PUT(self, mail):
        """Update alias profile.
        curl -X PUT -i -b cookie.txt -d "var=<value>" https://<server>/api/alias/<mail>
        curl -X PUT -i -b cookie.txt -d "var=<value>&var2=<value2>" https://<server>/api/user/<mail>

        Optional PUT data:

        @cn - comman name (or, display name)
        """
        mail = str(mail).lower()
        domain = mail.split('@', 1)[-1]

        form = web.input()

        update = {}

        if 'cn' in form:
            cn = form_utils.get_single_value(form, input_name='cn', default_value='')
            update['name'] = cn

        if update:
            try:
                sql_wrap = SQLWrap()
                sql_wrap.conn.update('alias',
                                     vars={'mail': mail},
                                     where='address=$mail',
                                     **update)

                web.logger(msg="[API] Update alias profile: %s -> %s" % (mail, ', '.join(update)),
                           admin=session.get('username'),
                           username=mail,
                           domain=domain,
                           event='update')

                return tuple_to_api_render((True, ))
            except Exception, e:
                return tuple_to_api_render((False, str(e)))
