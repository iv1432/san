# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings

from controllers.utils import tuple_to_api_render

from libs import iredutils, iredpwd, form_utils
from libs.languages import get_language_maps, TIMEZONES

from libs.sqllib import SQLWrap, sqlutils, decorators
from libs.sqllib import user as sql_lib_user
from libs.sqllib import alias as sql_lib_alias
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import utils as sql_lib_utils
from libs.sqllib import general as sql_lib_general

from libs.amavisd import spampolicy as spampolicylib, wblist as wblistlib

session = web.config.get('_session')

if session.get('enable_iredapd'):
    from libs.iredapd import throttle as iredapd_throttle
    from libs.iredapd import greylist as iredapd_greylist


class List(object):
    @decorators.require_domain_access
    def GET(self, domain, cur_page=1, disabled_only=False):
        domain = str(domain).lower()
        cur_page = int(cur_page) or 1

        web_input = web.input(_unicode=False)
        sort_by_quota = 'sort_by_quota' in web_input

        total = 0
        records = []

        # Real-time used quota.
        used_quota = {}

        # Forwardings and per-user alias addresses
        user_forwardings = {}
        user_alias_addresses = {}

        first_char = None
        if 'starts_with' in web_input:
            first_char = web_input.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        sql_wrap = SQLWrap()
        total = sql_lib_user.num_users_under_domains(conn=sql_wrap.conn,
                                                     domains=[domain],
                                                     disabled_only=disabled_only)

        if total:
            qr = sql_lib_user.get_paged_users(conn=sql_wrap.conn,
                                              domain=domain,
                                              cur_page=cur_page,
                                              sort_by_quota=sort_by_quota,
                                              first_char=first_char,
                                              disabled_only=disabled_only)

            if qr[0]:
                records = qr[1]
            else:
                raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))

            # Get list of email addresses
            mails = []
            for r in records:
                mails += [str(r.get('username'))]

            if mails:
                # Get real-time mailbox usage
                if settings.SHOW_USED_QUOTA:
                    try:
                        used_quota = sql_lib_utils.get_account_used_quota(conn=sql_wrap.conn,
                                                                          accounts=mails)
                    except Exception:
                        pass

                # Get user forwardings
                (_status, _result) = sql_lib_user.get_bulk_user_forwardings(conn=sql_wrap.conn, mails=mails)
                if _status:
                    user_forwardings = _result
                else:
                    raise web.seeother('/domains?msg=%s' % web.urlquote(_result))

                # Get user alias addresses
                (_status, _result) = sql_lib_user.get_bulk_user_alias_addresses(conn=sql_wrap.conn, mails=mails)
                if _status:
                    user_alias_addresses = _result
                else:
                    raise web.seeother('/domains?msg=%s' % web.urlquote(_result))

        return web.render('sql/user/list.html',
                          cur_domain=domain,
                          cur_page=cur_page,
                          total=total,
                          users=records,
                          user_forwardings=user_forwardings,
                          user_alias_addresses=user_alias_addresses,
                          accountUsedQuota=used_quota,
                          sort_by_quota=sort_by_quota,
                          first_char=first_char,
                          disabled_only=disabled_only,
                          msg=web_input.get('msg', None))

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, domain):
        form = web.input(_unicode=False, mail=[])

        domain = str(domain).lower()

        # Filter users not under the same domain.
        mails = [str(v)
                 for v in form.get('mail', [])
                 if iredutils.is_email(v)
                 and str(v).endswith('@' + domain)]

        action = form.get('action', None)
        msg = form.get('msg', None)

        redirect_to_admin_list = False
        if 'redirect_to_admin_list' in form:
            redirect_to_admin_list = True

        sql_wrap = SQLWrap()

        if action == 'delete':
            result = sql_lib_user.delete_users(conn=sql_wrap.conn, accounts=mails)
            msg = 'DELETED'
        elif action == 'disable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=mails,
                                                      account_type='user',
                                                      enable_account=False)
            msg = 'DISABLED'
        elif action == 'enable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=mails,
                                                      account_type='user',
                                                      enable_account=True)
            msg = 'ENABLED'
        elif action == 'markasadmin':
            result = sql_lib_user.mark_user_as_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     users=mails,
                                                     as_normal_admin=True)
            msg = 'MARKASADMIN'
        elif action == 'unmarkasadmin':
            result = sql_lib_user.mark_user_as_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     users=mails,
                                                     as_normal_admin=False)
            msg = 'UNMARKASADMIN'
        elif action == 'markasglobaladmin':
            result = sql_lib_user.mark_user_as_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     users=mails,
                                                     as_global_admin=True)
            msg = 'MARKASGLOBALADMIN'
        elif action == 'unmarkasglobaladmin':
            result = sql_lib_user.mark_user_as_admin(conn=sql_wrap.conn,
                                                     domain=domain,
                                                     users=mails,
                                                     as_global_admin=False)
            msg = 'UNMARKASGLOBALADMIN'
        else:
            result = (False, 'INVALID_ACTION')

        if result[0] is True:
            if redirect_to_admin_list:
                raise web.seeother('/admins/%s?msg=%s' % (domain, msg))
            else:
                raise web.seeother('/users/%s?msg=%s' % (domain, msg))
        else:
            if redirect_to_admin_list:
                raise web.seeother('/admins/%s?msg=%s' % (domain, web.urlquote(result[1])))
            else:
                raise web.seeother('/users/%s?msg=%s' % (domain, web.urlquote(result[1])))


class ListDisabled(object):
    @decorators.require_domain_access
    def GET(self, domain, cur_page=1):
        l = List()
        return l.GET(domain=domain, cur_page=cur_page, disabled_only=True)


class Profile(object):
    @decorators.require_domain_access
    def GET(self, profile_type, mail):
        if profile_type == 'rename':
            raise web.seeother('/profile/user/general/' + mail)

        web_input = web.input()
        self.mail = str(mail).lower()
        domain = self.mail.split('@', 1)[-1]

        # profile_type == 'general'
        accountUsedQuota = {}

        # profile_type == 'greylisting'
        # greylisting: iRedAPD
        gl_setting = {}
        gl_whitelists = []

        # profile_type == 'throttle'
        # throttle: iRedAPD
        inbound_throttle_setting = {}
        outbound_throttle_setting = {}

        # profile_type == 'advanced'
        disabled_user_profiles = []  # Per-domain disabled user profiles.

        if self.mail.startswith('@') and iredutils.is_domain(domain):
            # Catchall account.
            raise web.seeother('/profile/domain/catchall/%s' % domain)

        sql_wrap = SQLWrap()

        qr = sql_lib_user.profile(conn=sql_wrap.conn,
                                  domain=domain,
                                  mail=self.mail)
        if qr[0] is True:
            user_profile = qr[1]
        else:
            raise web.seeother('/users/%s?msg=%s' % (domain, web.urlquote(qr[1])))
        del qr

        # Get mailbox.allow_nets
        allow_nets = []
        _allow_nets = user_profile.get('allow_nets')
        if _allow_nets:
            allow_nets = _allow_nets.split(',')

        # Get per-user settings
        user_settings = {}
        qr = sql_lib_user.get_user_settings(conn=sql_wrap.conn,
                                            mail=self.mail,
                                            existing_settings=user_profile['settings'])
        if qr[0]:
            user_settings = qr[1]
        del qr

        # Get used quota.
        if settings.SHOW_USED_QUOTA:
            accountUsedQuota = sql_lib_utils.get_account_used_quota(conn=sql_wrap.conn,
                                                                    accounts=[self.mail])

        # Get all aliases under same domain.
        allAliases = []
        qr = sql_lib_alias.get_all_aliases(conn=sql_wrap.conn,
                                           domain=domain,
                                           columns=['name', 'address', 'goto'])
        if qr[0] is True:
            allAliases = qr[1]

        # Get per-user alias addresses.
        qr = sql_lib_user.get_user_alias_addresses(conn=sql_wrap.conn,
                                                   mail=self.mail)
        if qr[0] is True:
            user_alias_addresses = qr[1]

        # Get per-domain disabled user profiles.
        qr = sql_lib_domain.simple_profile(conn=sql_wrap.conn,
                                           domain=domain,
                                           columns=['settings'])

        if qr[0] is True:
            domain_profile = qr[1]
            domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings'])

            disabled_user_profiles = domain_settings.get('disabled_user_profiles', [])
            min_passwd_length = domain_settings.get('min_passwd_length', 0)
            max_passwd_length = domain_settings.get('max_passwd_length', 0)

            if min_passwd_length < settings.min_passwd_length:
                min_passwd_length = settings.min_passwd_length

            if max_passwd_length < settings.max_passwd_length:
                max_passwd_length = settings.max_passwd_length

        # Get sender dependent relayhost
        relayhost = sql_lib_general.get_sender_relayhost(conn=sql_wrap.conn,
                                                         sender=self.mail)

        if session.get('enable_iredapd'):
            # Greylisting
            qr = iredapd_greylist.get_greylist_setting_and_whitelists(account=self.mail)
            gl_setting = qr['setting']
            gl_whitelists = qr['whitelists']

            # Throttle
            lib_trot = iredapd_throttle.Throttle()

            # Get default inbound throttle
            inbound_throttle_setting = lib_trot.get_throttle_setting(account=self.mail, inout_type='inbound')

            # Get default outbound throttle
            outbound_throttle_setting = lib_trot.get_throttle_setting(account=self.mail, inout_type='outbound')

        # Get managed domains and all domains under control.
        managed_domains = []
        all_domains = []

        if session.get('is_global_admin') or session.get('allowed_to_grant_admin'):
            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=self.mail,
                                                   domain_name_only=True,
                                                   listed_only=True)
            if qr[0]:
                managed_domains += qr[1]
            del qr

            qr = sql_lib_domain.get_all_domains(conn=sql_wrap.conn,
                                                columns=['domain', 'description'])
            if qr[0]:
                all_domains = qr[1]

        # Get spam policy
        spampolicy = {}
        global_spam_score = None
        if session.get('amavisd_enable_policy_lookup'):
            policy_lib = spampolicylib.SpamPolicy()
            qr = policy_lib.get_spam_policy(account=self.mail)
            if not qr[0]:
                raise web.seeother('/domains?msg=%s' % web.urlquote(qr[1]))
            else:
                spampolicy = qr[1]

            global_spam_score = policy_lib.get_global_spam_score()

        # Get per-user white/blacklists
        whitelists = []
        blacklists = []
        outbound_whitelists = []
        outbound_blacklists = []

        wblist_lib = wblistlib.WBList()
        qr = wblist_lib.get_account_wblist(account=mail)
        if qr[0]:
            whitelists = qr[1]['whitelist']
            blacklists = qr[1]['blacklist']
            outbound_whitelists = qr[1]['outbound_whitelist']
            outbound_blacklists = qr[1]['outbound_blacklist']

        return web.render(
            'sql/user/profile.html',
            cur_domain=domain,
            mail=self.mail,
            profile_type=profile_type,
            profile=user_profile,
            timezones=TIMEZONES,
            min_passwd_length=min_passwd_length,
            max_passwd_length=max_passwd_length,
            store_password_in_plain_text=settings.STORE_PASSWORD_IN_PLAIN_TEXT,
            password_policies=iredutils.get_password_policies(),
            user_settings=user_settings,
            accountUsedQuota=accountUsedQuota,
            allAliases=allAliases,
            user_alias_addresses=user_alias_addresses,
            user_alias_cross_all_domains=settings.USER_ALIAS_CROSS_ALL_DOMAINS,
            disabled_user_profiles=disabled_user_profiles,
            allow_nets=allow_nets,
            managed_domains=managed_domains,
            all_domains=all_domains,
            relayhost=relayhost,
            # iRedAPD
            gl_setting=gl_setting,
            gl_whitelists=gl_whitelists,
            # iRedAPD
            inbound_throttle_setting=inbound_throttle_setting,
            outbound_throttle_setting=outbound_throttle_setting,
            # spam policy, wblist, throttling
            spampolicy=spampolicy,
            global_spam_score=global_spam_score,
            whitelists=whitelists,
            blacklists=blacklists,
            outbound_whitelists=outbound_whitelists,
            outbound_blacklists=outbound_blacklists,
            languagemaps=get_language_maps(),
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, profile_type, mail):
        form = web.input(enabledService=[],
                         shadowAddress=[],
                         telephoneNumber=[],
                         memberOfGroup=[],
                         oldMemberOfAlias=[],
                         memberOfAlias=[],
                         domainName=[])  # Managed domains

        mail = str(mail).lower()

        sql_wrap = SQLWrap()
        result = sql_lib_user.update(conn=sql_wrap.conn,
                                     mail=mail,
                                     profile_type=profile_type,
                                     form=form)

        if profile_type == 'rename':
            profile_type = 'general'

        if result[0] is True:
            raise web.seeother('/profile/user/%s/%s?msg=UPDATED' % (profile_type, mail))
        else:
            raise web.seeother('/profile/user/%s/%s?msg=%s' % (profile_type, mail, web.urlquote(result[1])))


class Create(object):
    @decorators.require_domain_access
    def GET(self, domain):
        domain = str(domain).lower()

        web_input = web.input()

        # Get all managed domains.
        sql_wrap = SQLWrap()

        if session.get('is_global_admin'):
            qr = sql_lib_domain.get_all_domains(conn=sql_wrap.conn, name_only=True)
        else:
            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=session.get('username'),
                                                   domain_name_only=True)

        if qr[0] is True:
            all_domains = qr[1]
        else:
            raise web.seeother('/domains?msg=' + web.urlquote(qr[1]))

        # Get domain profile.
        qr_profile = sql_lib_domain.profile(conn=sql_wrap.conn, domain=domain)
        if qr_profile[0] is True:
            domain_profile = qr_profile[1]
            domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings'])
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(qr_profile[1]))

        # Cet total number and allocated quota size of existing users under domain.
        num_users_under_domain = sql_lib_domain.num_users_under_domain(conn=sql_wrap.conn, domain=domain)
        used_quota_size = sql_lib_domain.sum_allocated_domain_quota(conn=sql_wrap.conn, domain=domain)

        min_passwd_length = domain_settings.get('min_passwd_length', 0)
        max_passwd_length = domain_settings.get('max_passwd_length', 0)

        if min_passwd_length < settings.min_passwd_length:
            min_passwd_length = settings.min_passwd_length

        if max_passwd_length < settings.max_passwd_length:
            max_passwd_length = settings.max_passwd_length

        return web.render(
            'sql/user/create.html',
            cur_domain=domain,
            allDomains=all_domains,
            profile=domain_profile,
            domain_settings=domain_settings,
            min_passwd_length=min_passwd_length,
            max_passwd_length=max_passwd_length,
            store_password_in_plain_text=settings.STORE_PASSWORD_IN_PLAIN_TEXT,
            numberOfExistAccounts=num_users_under_domain,
            usedQuotaSize=used_quota_size,
            languagemaps=get_language_maps(),
            password_policies=iredutils.get_password_policies(),
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, domain):
        domain = str(domain).lower()
        form = web.input()

        domain_in_form = form_utils.get_domain_name(form)
        if domain != domain_in_form:
            raise web.seeother('/domains?msg=PERMISSION_DENIED')

        # Get domain name, username, cn.
        username = form_utils.get_single_value(form,
                                               input_name='username',
                                               to_string=True)

        sql_wrap = SQLWrap()
        result = sql_lib_user.add_user_from_form(conn=sql_wrap.conn,
                                                 domain=domain,
                                                 form=form)

        if result[0] is True:
            raise web.seeother('/profile/user/general/%s@%s?msg=CREATED' % (username, domain))
        else:
            raise web.seeother('/create/user/%s?msg=%s' % (domain, web.urlquote(result[1])))


# Internal domain admins
class Admin(object):
    @decorators.require_domain_access
    def GET(self, domain, cur_page=1):
        domain = str(domain).lower()
        cur_page = int(cur_page) or 1

        web_input = web.input(_unicode=False)

        # Forwardings and per-user alias addresses
        user_forwardings = {}
        user_alias_addresses = {}

        first_char = None
        if 'starts_with' in web_input:
            first_char = web_input.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        sql_wrap = SQLWrap()
        result = sql_lib_admin.get_paged_domain_admins(conn=sql_wrap.conn,
                                                       domain=domain,
                                                       current_page=cur_page,
                                                       first_char=first_char)

        if result[0] is True:
            total = result[1]['total']
            records = result[1]['records']

            # Get list of email addresses
            mails = []
            for r in records:
                mails += [str(r.get('username'))]

            # Get real-time used quota.
            accountUsedQuota = {}

            if settings.SHOW_USED_QUOTA:
                if mails:
                    try:
                        accountUsedQuota = sql_lib_utils.get_account_used_quota(conn=sql_wrap.conn,
                                                                                accounts=mails)
                    except Exception:
                        pass

            # Get user forwardings
            (_status, _result) = sql_lib_user.get_bulk_user_forwardings(conn=sql_wrap.conn, mails=mails)
            if _status:
                user_forwardings = _result
            else:
                raise web.seeother('/domains?msg=%s' % web.urlquote(_result))

            # Get user alias addresses
            (_status, _result) = sql_lib_user.get_bulk_user_alias_addresses(conn=sql_wrap.conn, mails=mails)
            if _status:
                user_alias_addresses = _result
            else:
                raise web.seeother('/domains?msg=%s' % web.urlquote(_result))

            return web.render(
                'sql/user/list.html',
                cur_domain=domain,
                cur_page=cur_page,
                total=total,
                users=records,
                user_forwardings=user_forwardings,
                user_alias_addresses=user_alias_addresses,
                accountUsedQuota=accountUsedQuota,
                first_char=first_char,
                msg=web.input().get('msg', None),
                all_are_admins=True,
            )
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(result[1]))


# Preferences allowed to be updated by user
class Preferences(object):
    @decorators.require_user_login
    def GET(self, profile_type='general'):
        web_input = web.input()
        mail = session['username']
        domain = mail.split('@', 1)[-1]

        sql_wrap = SQLWrap()

        qr = sql_lib_user.profile(conn=sql_wrap.conn,
                                  domain=domain,
                                  mail=mail)
        user_profile = qr[1]
        del qr

        # Get per-user settings
        user_settings = {}
        qr = sql_lib_user.get_user_settings(conn=sql_wrap.conn,
                                            mail=mail,
                                            existing_settings=user_profile['settings'])
        if qr[0]:
            user_settings = qr[1]
        del qr

        # Get used quota
        used_quota_bytes = 0
        if settings.SHOW_USED_QUOTA:
            used_quota = sql_lib_utils.get_account_used_quota(conn=sql_wrap.conn,
                                                              accounts=[mail])

            used_quota_bytes = used_quota.get(mail, {}).get('bytes', 0)

        # Get per-domain disabled user preferences.
        qr = sql_lib_domain.simple_profile(conn=sql_wrap.conn,
                                           domain=domain,
                                           columns=['settings'])

        if qr[0] is True:
            domain_profile = qr[1]
            domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings'])

            disabled_user_preferences = domain_settings.get('disabled_user_preferences', [])
            session['disabled_user_preferences'] = disabled_user_preferences

            min_passwd_length = domain_settings.get('min_passwd_length', 0)
            max_passwd_length = domain_settings.get('max_passwd_length', 0)

            if min_passwd_length < settings.min_passwd_length:
                min_passwd_length = settings.min_passwd_length

            if max_passwd_length < settings.max_passwd_length:
                max_passwd_length = settings.max_passwd_length

        return web.render(
            'sql/user/preferences.html',
            cur_domain=domain,
            mail=mail,
            profile=user_profile,
            user_settings=user_settings,
            used_quota_bytes=used_quota_bytes,
            disabled_user_preferences=disabled_user_preferences,
            languagemaps=get_language_maps(),
            timezones=TIMEZONES,
            min_passwd_length=min_passwd_length,
            max_passwd_length=max_passwd_length,
            store_password_in_plain_text=settings.STORE_PASSWORD_IN_PLAIN_TEXT,
            password_policies=iredutils.get_password_policies(),
            msg=web_input.get('msg'),
        )

    @decorators.csrf_protected
    @decorators.require_user_login
    def POST(self, profile_type='general'):
        mail = session['username']

        form = web.input(telephoneNumber=[])

        sql_wrap = SQLWrap()
        result = sql_lib_user.update_preferences(conn=sql_wrap.conn,
                                                 mail=mail,
                                                 form=form,
                                                 profile_type=profile_type)

        if result[0] is True:
            raise web.seeother('/preferences?msg=UPDATED')
        else:
            raise web.seeother('/preferences?msg=%s' % web.urlquote(result[1]))


class APIUser(object):
    @decorators.api_require_domain_access
    def POST(self, mail):
        """Create a new mail user.

        curl -X POST -i -b cookie.txt -d "var=value1&var2=value2&..." https://<server>/api/user/<mail>

        Required POST data:

        @password - password for this user

        Optional POST data:

        @cn - comman name (or, display name)
        @preferredLanguage - default preferred language for new user. e.g.
                             en_US for English, de_DE for Deutsch.
        @mailQuota - mailbox quota for this user (in MB). Defaults to
                     per-domain quota setting or unlimited.
        """
        mail = str(mail).lower()
        (username, domain) = mail.split('@', 1)

        form = web.input()

        form['username'] = username
        form['domainName'] = domain

        password = form.get('password', '')
        form['newpw'] = password
        form['confirmpw'] = password

        sql_wrap = SQLWrap()
        result = sql_lib_user.add_user_from_form(conn=sql_wrap.conn,
                                                 domain=domain,
                                                 form=form)

        return tuple_to_api_render(result)

    @decorators.api_require_domain_access
    def DELETE(self, mail):
        """Delete a mail user.
        curl -X DELETE -i -b cookie.txt https://<server>/api/user/<mail>
        """
        mail = str(mail).lower()

        sql_wrap = SQLWrap()
        result = sql_lib_user.delete_users(conn=sql_wrap.conn, accounts=[mail])

        return tuple_to_api_render(result)

    @decorators.api_require_domain_access
    def PUT(self, mail):
        """Update user profile.
        curl -X PUT -i -b cookie.txt -d "var=<value>" https://<server>/api/user/<mail>
        curl -X PUT -i -b cookie.txt -d "var=<value>&var2=<value2>" https://<server>/api/user/<mail>

        Optional PUT data:

        @cn - comman name (or, display name)
        @accountStatus - enable or disable user. possible value is: active, disabled.
        @password - set new password for user
        @quota - set mailbox quota (in MB)
        @language - set preferred language of web UI
        @transport - set per-user transport
        """
        mail = str(mail).lower()
        domain = mail.split('@', 1)[-1]

        form = web.input()

        update = {}

        if 'cn' in form:
            cn = form_utils.get_single_value(form, input_name='cn', default_value='')
            update['name'] = cn

        if 'accountStatus' in form:
            status = form_utils.get_account_status(form, to_integer=True)
            update['active'] = status

        if 'password' in form:
            pw = form_utils.get_single_value(form,
                                             input_name='password',
                                             to_string=True)
            if pw:
                # Get min/max password length from domain profile
                sql_wrap = SQLWrap()
                qr = sql_lib_domain.get_domain_settings(conn=sql_wrap.conn,
                                                        domain=domain)
                if not (qr[0] is True):
                    return tuple_to_api_render(qr)

                domain_settings = qr[1]
                min_passwd_length = domain_settings.get('min_passwd_length')
                max_passwd_length = domain_settings.get('max_passwd_length')

                qr = iredpwd.verify_new_password(newpw=pw,
                                                 confirmpw=pw,
                                                 min_passwd_length=min_passwd_length,
                                                 max_passwd_length=max_passwd_length)
                if not qr[0] is True:
                    return tuple_to_api_render(qr)

                pw = iredpwd.generate_password_hash(pw)
                update['password'] = pw

        # TODO check domain quota limit first
        #if 'quota' in form:
        #    quota = form_utils.get_quota(form, input_name='quota')
        #    update['quota'] = quota

        if 'language' in form:
            lang = form_utils.get_language(form, input_name='language')
            update['language'] = lang

        if 'transport' in form:
            t = form_utils.get_single_value(form, input_name='transport', to_string=True)
            update['transport'] = t

        if update:
            try:
                sql_wrap = SQLWrap()
                conn = sql_wrap.conn
                conn.update('mailbox',
                            vars={'mail': mail},
                            where='username=$mail',
                            **update)

                web.logger(msg="[API] Update user profile: %s -> %s" % (mail, ', '.join(update)),
                           admin=session.get('username'),
                           username=mail,
                           domain=domain,
                           event='update')

                return tuple_to_api_render((True, ))
            except Exception, e:
                return tuple_to_api_render((False, str(e)))
