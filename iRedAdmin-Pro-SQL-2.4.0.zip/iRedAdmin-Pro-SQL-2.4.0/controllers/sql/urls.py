# Author: Zhang Huangbin <zhb@iredmail.org>

import settings
from libs.regxes import email as regx_email, domain as regx_domain

urls = [
    # Make url ending with or without '/' going to the same class.
    '/(.*)/',                   'controllers.utils.redirect',

    # used to display jpegPhoto.
    '/img/(.*)',                'controllers.utils.img',

    '/',                        'controllers.sql.basic.Login',
    '/login',                   'controllers.sql.basic.Login',
    '/logout',                  'controllers.sql.basic.Logout',
    '/dashboard',               'controllers.sql.basic.Dashboard',
    '/dashboard/(checknew)',    'controllers.sql.basic.Dashboard',

    # Search.
    '/search',                  'controllers.sql.basic.Search',

    # Perform some operations from search page.
    '/action/(user)',           'controllers.sql.basic.OperationsFromSearchPage',
    '/action/(alias)',          'controllers.sql.basic.OperationsFromSearchPage',

    # Domain related.
    '/domains',                                         'controllers.sql.domain.List',
    '/domains/page/(\d+)',                              'controllers.sql.domain.List',
    # List disabled accounts.
    '/domains/disabled',                                'controllers.sql.domain.ListDisabled',
    '/domains/disabled/page/(\d+)',                     'controllers.sql.domain.ListDisabled',
    # Domain profiles
    '/profile/domain/(general)/(%s$)' % regx_domain,    'controllers.sql.domain.Profile',
    '/profile/domain/(aliases)/(%s$)' % regx_domain,    'controllers.sql.domain.Profile',
    '/profile/domain/(relay)/(%s$)' % regx_domain,      'controllers.sql.domain.Profile',
    '/profile/domain/(backupmx)/(%s$)' % regx_domain,   'controllers.sql.domain.Profile',
    '/profile/domain/(bcc)/(%s$)' % regx_domain,        'controllers.sql.domain.Profile',
    '/profile/domain/(catchall)/(%s$)' % regx_domain,   'controllers.sql.domain.Profile',
    '/profile/domain/(throttle)/(%s$)' % regx_domain,   'controllers.sql.domain.Profile',
    '/profile/domain/(greylisting)/(%s$)' % regx_domain,   'controllers.sql.domain.Profile',
    '/profile/domain/(wblist)/(%s$)' % regx_domain,     'controllers.sql.domain.Profile',
    '/profile/domain/(spampolicy)/(%s$)' % regx_domain, 'controllers.sql.domain.Profile',
    '/profile/domain/(advanced)/(%s$)' % regx_domain,   'controllers.sql.domain.Profile',
    '/profile/domain/(%s)' % regx_domain,               'controllers.sql.domain.Profile',
    '/create/domain',                                   'controllers.sql.domain.Create',

    # Admin related.
    '/admins',                                      'controllers.sql.admin.List',
    '/admins/page/(\d+)',                           'controllers.sql.admin.List',
    '/profile/admin/(general)/(%s$)' % regx_email,  'controllers.sql.admin.Profile',
    '/profile/admin/(password)/(%s$)' % regx_email, 'controllers.sql.admin.Profile',
    '/create/admin',                                'controllers.sql.admin.Create',

    # User related.
    # /domain.ltd/users
    '/users',                               'controllers.sql.user.List',
    '/users/(%s$)' % regx_domain,           'controllers.sql.user.List',
    '/users/(%s)/page/(\d+)' % regx_domain, 'controllers.sql.user.List',
    # List disabled accounts.
    '/users/(%s)/disabled' % regx_domain,              'controllers.sql.user.ListDisabled',
    '/users/(%s)/disabled/page/(\d+)' % regx_domain,    'controllers.sql.user.ListDisabled',
    # Create user.
    '/create/user/(%s$)' % regx_domain,     'controllers.sql.user.Create',
    '/create/(user)',                       'controllers.sql.utils.CreateDispatcher',
    # Profile pages.
    '/profile/user/(general)/(%s$)' % regx_email,       'controllers.sql.user.Profile',
    '/profile/user/(forwarding)/(%s$)' % regx_email,    'controllers.sql.user.Profile',
    '/profile/user/(bcc)/(%s$)' % regx_email,           'controllers.sql.user.Profile',
    '/profile/user/(relay)/(%s$)' % regx_email,         'controllers.sql.user.Profile',
    '/profile/user/(aliases)/(%s$)' % regx_email,       'controllers.sql.user.Profile',
    '/profile/user/(wblist)/(%s$)' % regx_email,        'controllers.sql.user.Profile',
    '/profile/user/(spampolicy)/(%s$)' % regx_email,    'controllers.sql.user.Profile',
    '/profile/user/(password)/(%s$)' % regx_email,      'controllers.sql.user.Profile',
    '/profile/user/(throttle)/(%s$)' % regx_email,      'controllers.sql.user.Profile',
    '/profile/user/(greylisting)/(%s$)' % regx_email,   'controllers.sql.user.Profile',
    '/profile/user/(advanced)/(%s$)' % regx_email,      'controllers.sql.user.Profile',
    '/profile/user/(rename)/(%s$)' % regx_email,        'controllers.sql.user.Profile',

    # Alias related.
    '/aliases',                                     'controllers.sql.alias.List',
    '/aliases/(%s$)' % regx_domain,                 'controllers.sql.alias.List',
    '/aliases/(%s)/page/(\d+)' % regx_domain,       'controllers.sql.alias.List',
    # List disabled accounts.
    '/aliases/(%s)/disabled' % regx_domain,              'controllers.sql.alias.ListDisabled',
    '/aliases/(%s)/disabled/page/(\d+)' % regx_domain,   'controllers.sql.alias.ListDisabled',
    '/profile/alias/(general)/(%s$)' % regx_email,  'controllers.sql.alias.Profile',
    '/profile/alias/(members)/(%s$)' % regx_email,  'controllers.sql.alias.Profile',
    '/profile/alias/(rename)/(%s$)' % regx_email,   'controllers.sql.alias.Profile',
    '/create/alias/(%s$)' % regx_domain,            'controllers.sql.alias.Create',
    '/create/(alias)',                              'controllers.sql.utils.CreateDispatcher',

    # User admins
    '/admins/(%s$)' % regx_domain,              'controllers.sql.user.Admin',
    '/admins/(%s)/page/(\d+)' % regx_domain,    'controllers.sql.user.Admin',

    # Self-service
    '/preferences',                 'controllers.sql.user.Preferences',
    '/preferences/(general)$',      'controllers.sql.user.Preferences',
    '/preferences/(forwarding)$',   'controllers.sql.user.Preferences',
    '/preferences/(password)$',     'controllers.sql.user.Preferences',
    ]


# API Interfaces
if settings.ENABLE_RESTFUL_API:
    urls += [
        # API Interfaces
        '/api/login',                                       'controllers.sql.basic.APILogin',
        '/api/domain/(%s$)' % regx_domain,                  'controllers.sql.domain.APIDomain',
        '/api/user/(%s$)' % regx_email,                     'controllers.sql.user.APIUser',
        '/api/alias/(%s$)' % regx_email,                    'controllers.sql.alias.APIAlias',
    ]
