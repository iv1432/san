# Author: Zhang Huangbin <zhb@iredmail.org>

import web
import settings
from libs import iredutils, languages

from libs.sqllib import SQLWrap, decorators
from libs.sqllib import user as sql_lib_user
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import utils as sql_lib_utils

session = web.config.get('_session')


class List(object):
    @decorators.require_global_admin
    def GET(self, cur_page=1):
        web_input = web.input()
        cur_page = int(cur_page)

        if cur_page == 0:
            cur_page == 1

        sql_wrap = SQLWrap()
        result = sql_lib_admin.get_paged_admins(conn=sql_wrap.conn,
                                                cur_page=cur_page)

        if result[0] is True:
            (total, records) = (result[1]['total'], result[1]['records'])

            # Get list of global admins.
            allGlobalAdmins = []
            qr = sql_lib_admin.get_all_global_admins(conn=sql_wrap.conn)
            if qr[0]:
                allGlobalAdmins = qr[1]

            return web.render(
                'sql/admin/list.html',
                cur_page=cur_page,
                total=total,
                admins=records,
                allGlobalAdmins=allGlobalAdmins,
                msg=web_input.get('msg', None),
            )
        else:
            raise web.seeother('/domains?msg=%s' % web.urlquote(result[1]))

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input(_unicode=False, mail=[])

        accounts = form.get('mail', [])
        action = form.get('action', None)
        msg = form.get('msg', None)

        sql_wrap = SQLWrap()

        if action == 'delete':
            result = sql_lib_admin.delete_admins(conn=sql_wrap.conn, accounts=accounts)
            msg = 'DELETED'
        elif action == 'disable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=accounts,
                                                      account_type='admin',
                                                      enable_account=False)
            msg = 'DISABLED'
        elif action == 'enable':
            result = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                      accounts=accounts,
                                                      account_type='admin',
                                                      enable_account=True)
            msg = 'ENABLED'
        else:
            result = (False, 'INVALID_ACTION')

        if result[0] is True:
            raise web.seeother('/admins?msg=%s' % msg)
        else:
            raise web.seeother('/admins?msg=?' + web.urlquote(result[1]))


class Profile(object):
    @decorators.require_admin_login
    def GET(self, profile_type, mail):
        mail = str(mail).lower()
        web_input = web.input()

        if not (session.get('is_global_admin') or session.get('username') == mail):
            # Don't allow to view/update others' profile.
            raise web.seeother('/profile/admin/general/%s?msg=PERMISSION_DENIED' % session.get('username'))

        sql_wrap = SQLWrap()
        is_global_admin = sql_lib_admin.is_global_admin(conn=sql_wrap.conn, admin=mail)
        result = sql_lib_admin.profile(conn=sql_wrap.conn, mail=mail)

        if result[0] is True:
            profile = result[1]

            # Get all domains.
            all_domains = []

            qr_all_domains = sql_lib_domain.get_all_domains(conn=sql_wrap.conn)
            if qr_all_domains[0] is True:
                all_domains = qr_all_domains[1]

            # Get managed domains.
            managed_domains = []

            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=mail,
                                                   domain_name_only=True,
                                                   listed_only=True)
            if qr[0] is True:
                managed_domains += qr[1]

            return web.render(
                'sql/admin/profile.html',
                mail=mail,
                profile_type=profile_type,
                is_global_admin=is_global_admin,
                profile=profile,
                languagemaps=languages.get_language_maps(),
                allDomains=all_domains,
                managedDomains=managed_domains,
                min_passwd_length=settings.min_passwd_length,
                max_passwd_length=settings.max_passwd_length,
                store_password_in_plain_text=settings.STORE_PASSWORD_IN_PLAIN_TEXT,
                password_policies=iredutils.get_password_policies(),
                msg=web_input.get('msg'),
            )
        else:
            # Return to user profile page if admin is a mail user.
            qr = sql_lib_user.simple_profile(conn=sql_wrap.conn,
                                             mail=mail,
                                             columns=['username'])

            if qr[0]:
                raise web.seeother('/profile/user/general/' + mail)
            else:
                raise web.seeother('/admins?msg=' + web.urlquote(result[1]))

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self, profile_type, mail):
        mail = str(mail).lower()
        form = web.input(domainName=[])

        if not (session.get('is_global_admin') or session.get('username') == mail):
            # Don't allow to view/update others' profile.
            raise web.seeother('/profile/admin/general/%s?msg=PERMISSION_DENIED' % session.get('username'))

        sql_wrap = SQLWrap()
        result = sql_lib_admin.update(conn=sql_wrap.conn,
                                      mail=mail,
                                      profile_type=profile_type,
                                      form=form)

        if result[0]:
            raise web.seeother('/profile/admin/%s/%s?msg=UPDATED' % (profile_type, mail))
        else:
            raise web.seeother('/profile/admin/%s/%s?msg=%s' % (profile_type, mail, web.urlquote(result[1])))


class Create(object):
    @decorators.require_global_admin
    def GET(self):
        web_input = web.input()
        return web.render(
            'sql/admin/create.html',
            languagemaps=languages.get_language_maps(),
            default_language=settings.default_language,
            min_passwd_length=settings.min_passwd_length,
            max_passwd_length=settings.max_passwd_length,
            password_policies=iredutils.get_password_policies(),
            msg=web_input.get('msg'),
        )

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input()
        mail = web.safestr(form.get('mail')).lower()

        sql_wrap = SQLWrap()
        result = sql_lib_admin.add_admin_from_form(conn=sql_wrap.conn, form=form)

        if result[0] is True:
            # Redirect to assign domains.
            raise web.seeother('/profile/admin/general/%s?msg=CREATED' % mail)
        else:
            raise web.seeother('/create/admin?msg=' + web.urlquote(result[1]))
