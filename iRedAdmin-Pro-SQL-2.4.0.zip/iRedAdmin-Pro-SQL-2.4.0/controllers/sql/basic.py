# Author: Zhang Huangbin <zhb@iredmail.org>

import time
from socket import getfqdn
from urllib import urlencode

import web
import settings

from controllers.utils import tuple_to_api_render

from libs import __no__, __id__
from libs import __url_latest_sql__ as __url_latest__
from libs import __version_sql__ as __version__

from libs import iredutils, sys_info
from libs.languages import get_language_maps

from libs.sqllib import SQLWrap, auth, decorators
from libs.sqllib import admin as sql_lib_admin
from libs.sqllib import domain as sql_lib_domain
from libs.sqllib import utils as sql_lib_utils

from libs.panel import get_latest_release_info

session = web.config.get('_session')


if settings.amavisd_enable_quarantine or settings.amavisd_enable_logging:
    from libs.amavisd import quarantine, log as amavisdlog


class Login(object):
    def GET(self):
        if session.get('logged') is False:
            web_input = web.input(_unicode=False)

            # Show login page.
            return web.render('login.html',
                              languagemaps=get_language_maps(),
                              msg=web_input.get('msg'))
        else:
            if session.get('account_is_mail_user'):
                iredutils.self_service_login_redirect(session['username'])
            else:
                if settings.REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN:
                    raise web.seeother('/domains')
                else:
                    raise web.seeother('/dashboard')

    def POST(self):
        # Get username, password.
        form = web.input(_unicode=False)

        username = web.safestr(form.get('username').strip()).lower()
        domain = username.split('@', 1)[-1]
        password = str(form.get('password').strip())
        save_pass = web.safestr(form.get('save_pass', 'no').strip())

        # Auth as domain admin
        sql_wrap = SQLWrap()
        auth_result = auth.auth(conn=sql_wrap.conn,
                                username=username,
                                password=password,
                                account_type='admin')

        if auth_result[0] is True:
            if save_pass == 'yes':
                # Session timeout (in seconds). 86400 - 24 hours.
                web.config.session_parameters['timeout'] = 86400

            web.logger(msg="Admin login success", event='login')

            # Save selected language
            selected_language = str(form.get('lang', '')).strip()
            if selected_language != web.ctx.lang and \
               selected_language in get_language_maps():
                session['lang'] = selected_language

            if settings.REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN:
                raise web.seeother('/domains')
            else:
                raise web.seeother('/dashboard/checknew')
        else:
            #
            # User login for self-service
            #
            # Check enabled services.
            qr = sql_lib_domain.get_domain_enabled_services(conn=sql_wrap.conn, domain=domain)
            if qr[0] is True:
                enabled_services = qr[1]
                if not 'self-service' in enabled_services:
                    # domain doesn't allow self-service
                    raise web.seeother('/login?msg=INVALID_CREDENTIALS')
            else:
                raise web.seeother('/login?msg=%s' % web.urlquote(qr[1]))

            user_auth_result = auth.auth(conn=sql_wrap.conn,
                                         username=username,
                                         password=password,
                                         account_type='user')

            if user_auth_result[0] is True:
                web.logger(msg="User login success", event='user_login')
                iredutils.self_service_login_redirect(session['username'])
            else:
                session['failed_times'] += 1
                web.logger(msg="Login failed.", admin=username, event='login', loglevel='error')
                raise web.seeother('/login?msg=%s' % web.urlquote(auth_result[1]))


class Logout(object):
    def GET(self):
        try:
            session.kill()
        except:
            pass

        raise web.seeother('/login')


class Dashboard(object):
    @decorators.require_admin_login
    def GET(self, checknew=False):
        # Check new version.
        if session.get('is_global_admin') is True and checknew:
            try:
                curdate = time.strftime('%Y-%m-%d')
                vars = dict(date=curdate)

                r = web.admindb.select('updatelog', vars=vars, where='date >= $date', limit=1)
                if len(r) == 0:
                    urlInfo = {
                        'v': __version__,
                        'o': __no__,
                        'f': __id__,
                        'lang': settings.default_language,
                        'host': getfqdn(),
                        'backend': settings.backend,
                    }

                    url = __url_latest__ + '?' + urlencode(urlInfo)
                    newVersionInfo = get_latest_release_info(url)

                    # Always remove all old records, just keep the last one.
                    web.admindb.delete('updatelog', vars=vars, where='date < $date')

                    if newVersionInfo[0] is True:
                        if __version__ >= newVersionInfo[1]['version']:
                            # Insert updating date if no new version available.
                            web.admindb.insert('updatelog', date=curdate)
                        else:
                            # Store basic new version info in session, used to
                            # show notification in Dashboard page.
                            session['new_version_available'] = True
                            session['new_version'] = newVersionInfo[1]['version']
            except Exception, e:
                session['new_version_available'] = False
                session['new_version_check_error'] = str(e)

        # Get numbers of domains, users, aliases.
        numberOfDomains = 0
        numberOfUsers = 0
        numberOfAliases = 0

        sql_wrap = SQLWrap()

        try:
            numberOfDomains = sql_lib_admin.num_managed_domains(conn=sql_wrap.conn)
            numberOfUsers = sql_lib_admin.num_managed_users(conn=sql_wrap.conn)
            numberOfAliases = sql_lib_admin.num_managed_aliases(conn=sql_wrap.conn)
        except:
            pass

        # Get numbers of existing messages and quota bytes.
        # Set None as default, so that it's easy to detect them in Jinja2 template.
        totalMessages = None
        totalBytes = None
        if session.get('is_global_admin'):
            if settings.SHOW_USED_QUOTA:
                try:
                    (totalMessages, totalBytes) = sql_lib_admin.sum_all_used_quota(conn=sql_wrap.conn)
                except:
                    pass

        # Get records of quarantined mails.
        amavisdQuarantineCount = 0
        amavisdQuarantineRecords = []
        if settings.amavisd_enable_quarantine or settings.amavisd_enable_logging:
            quarantineLib = quarantine.Quarantine()

            # Show only 10 records in Dashboard.
            qr = quarantineLib.get_quarantined_mails(sizelimit=10, countOnly=True)
            if qr[0] is True:
                (amavisdQuarantineCount, amavisdQuarantineRecords) = qr[1]

        # Get number of incoming/outgoing emails in latest 24 hours.
        numberOfIncomingMails = 0
        numberOfOutgoingMails = 0
        numberOfVirusMails = 0
        topSenders = []
        topRecipients = []

        if settings.amavisd_enable_logging:
            allReversedDomainNames = []

            amavisdLogLib = amavisdlog.Log()

            # Get all managed domain names and reversed names.
            allDomains = []
            result_all_domains = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                                   admin=session.get('username'),
                                                                   domain_name_only=True)
            if result_all_domains[0] is True:
                allDomains += result_all_domains[1]

            allReversedDomainNames = iredutils.reverse_amavisd_domain_names(allDomains)
            numberOfIncomingMails = amavisdLogLib.count_incoming_mails(allReversedDomainNames, 86400)
            numberOfOutgoingMails = amavisdLogLib.count_outgoing_mails(allReversedDomainNames, 86400)
            numberOfVirusMails = amavisdLogLib.count_virus_mails(allReversedDomainNames, 86400)
            topSenders = amavisdLogLib.get_top_users(
                reversedDomainNames=allReversedDomainNames,
                logType='sent',
                timeLength=86400,
                number=10,
            )
            topRecipients = amavisdLogLib.get_top_users(
                reversedDomainNames=allReversedDomainNames,
                logType='received',
                timeLength=86400,
                number=10,
            )

        return web.render(
            'dashboard.html',
            version=__version__,
            iredmail_version=iredutils.get_iredmail_version(),
            hostname=getfqdn(),
            uptime=sys_info.get_server_uptime(),
            loadavg=sys_info.get_system_load_average(),
            netif_data=sys_info.get_nic_info(),
            amavisdQuarantineCount=amavisdQuarantineCount,
            #amavisdQuarantineRecords=amavisdQuarantineRecords,
            numberOfDomains=numberOfDomains,
            numberOfUsers=numberOfUsers,
            numberOfAliases=numberOfAliases,
            totalMessages=totalMessages,
            totalBytes=totalBytes,
            numberOfIncomingMails=numberOfIncomingMails,
            numberOfOutgoingMails=numberOfOutgoingMails,
            numberOfVirusMails=numberOfVirusMails,
            topSenders=topSenders,
            topRecipients=topRecipients,
            removeQuarantinedInDays=settings.AMAVISD_REMOVE_QUARANTINED_IN_DAYS,
        )


class Search(object):
    @decorators.require_admin_login
    def GET(self):
        web_input = web.input()
        return web.render('sql/search.html', msg=web_input.get('msg'))

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self):
        form = web.input(accountType=[], accountStatus=[])
        search_string = form.get('searchString', '')
        if not search_string:
            raise web.seeother('/search?msg=EMPTY_STRING')

        account_type = form.get('accountType', [])
        account_status = form.get('accountStatus', [])

        try:
            sql_wrap = SQLWrap()
            qr = sql_lib_utils.search(conn=sql_wrap.conn,
                                      search_string=search_string,
                                      account_type=account_type,
                                      account_status=account_status)
            if qr[0] is False:
                return web.render(
                    'sql/search.html',
                    msg=qr[1],
                    searchString=search_string,
                )
        except Exception, e:
            return web.render(
                'sql/search.html',
                msg=str(e),
                searchString=search_string,
            )

        # Group account types.
        domains = qr[1].get('domain', [])
        admins = qr[1].get('admin', [])
        users = qr[1].get('user', [])
        aliases = qr[1].get('alias', [])
        allGlobalAdmins = qr[1].get('allGlobalAdmins', [])
        totalResults = len(domains) + len(admins) + len(users) + len(aliases)

        return web.render(
            'sql/search.html',
            searchString=search_string,
            totalResults=totalResults,
            domains=domains,
            admins=admins,
            users=users,
            aliases=aliases,
            allGlobalAdmins=allGlobalAdmins,
            msg=form.get('msg'),
        )


class OperationsFromSearchPage(object):
    @decorators.require_admin_login
    def GET(self, *args, **kw):
        raise web.seeother('/search')

    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self, accountType):
        accountType = web.safestr(accountType)  # user, alias
        form = web.input(_unicode=False, mail=[])

        # Get action.
        action = form.get('action', None)
        if action not in ['enable', 'disable', 'delete']:
            raise web.seeother('/search?msg=INVALID_ACTION')

        # Get list of accounts which has valid format.
        accounts = [web.safestr(v).lower()
                    for v in form.get('mail', [])
                    if iredutils.is_email(web.safestr(v))]

        # Raise earlier to avoid SQL query.
        if not accounts:
            raise web.seeother('/search?msg=INVALID_MAIL')

        domains = set([v.split('@', 1)[-1] for v in accounts])

        sql_wrap = SQLWrap()

        # Get managed accounts.
        if not session.get('is_global_admin'):
            # Get list of managed domains.
            qr = sql_lib_admin.get_managed_domains(conn=sql_wrap.conn,
                                                   admin=session.get('username'),
                                                   domain_name_only=True,
                                                   listed_only=True)
            if qr[0] is True:
                domains = [d for d in domains if d in qr[1]]
                accounts = [v for v in accounts if v.split('@', 1)[-1] in domains]
            else:
                raise web.seeother('/search?msg=%s' % web.urlquote(qr[1]))

        if not accounts:
            raise web.seeother('/search?msg=INVALID_MAIL')

        if action in ['enable']:
            qr = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                  accounts=accounts,
                                                  account_type=accountType,
                                                  enable_account=True)
        elif action in ['disable']:
            qr = sql_lib_utils.set_account_status(conn=sql_wrap.conn,
                                                  accounts=accounts,
                                                  account_type=accountType,
                                                  enable_account=False)
        elif action in ['delete']:
            qr = sql_lib_utils.delete_accounts(conn=sql_wrap.conn,
                                               accounts=accounts,
                                               account_type=accountType)

        if qr[0] is True:
            raise web.seeother('/search?msg=SUCCESS')
        else:
            raise web.seeother('/search?msg=%s' % str(qr[1]))


class APILogin(object):
    def POST(self):
        """Login.
        curl -X POST -c cookie.txt -d "username=<username>&password=<password>" https://<server>/api/login
        
        Required POST data:

        @username - valid email address of domain admin
        @password - password of username
        """
        if not iredutils.is_allowed_api_client(web.ctx.ip):
            return tuple_to_api_render((False, 'NOT_AUTHORIZED'))

        # Get username, password.
        form = web.input(_unicode=False)

        username = web.safestr(form.get('username').strip()).lower()
        password = str(form.get('password').strip())

        # Auth as domain admin
        sql_wrap = SQLWrap()
        auth_result = auth.auth(conn=sql_wrap.conn,
                                username=username,
                                password=password,
                                account_type='admin')

        if auth_result[0] is True:
            web.logger(msg="[API] Admin login success", event='login')

            return tuple_to_api_render((True, ))
        else:
            session['failed_times'] += 1
            web.logger(msg="[API] Admin login failed.", admin=username, event='login', loglevel='error')
            return tuple_to_api_render(auth_result)
